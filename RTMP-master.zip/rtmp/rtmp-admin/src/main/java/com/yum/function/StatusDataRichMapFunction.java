package com.yum.function;

import com.yum.common.model.OrderEvent;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import scala.Tuple2;
@Slf4j
public class StatusDataRichMapFunction extends RichMapFunction<OrderEvent, Object> {
    private ValueState<Long> pvState;
    private long pv = 0;
    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        // 初始化状态
        pvState = getRuntimeContext().getState(
                new ValueStateDescriptor<>("pvStat",
                        TypeInformation.of(new TypeHint<Long>() {
                        })));
    }
    @Override
    public Object map(OrderEvent orderEvent) throws Exception {
        // 从状态中获取该 app 的pv值，+1后，update 到状态中
        if (null == pvState.value()) {
            log.info("{} is new, pv is 1", orderEvent.getPackType());
            pv = 1;
        } else {
            pv = pvState.value();
            pv += 1;
            log.info("{} is old , pv is {}", orderEvent.getPackType(), pv);
        }
        pvState.update(pv);
        return new Tuple2<>(orderEvent.getStoreCode(), pv);
    }
}
