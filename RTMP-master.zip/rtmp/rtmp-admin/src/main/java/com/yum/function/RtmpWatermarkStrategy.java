package com.yum.function;

import com.yum.common.model.OrderEvent;
import org.apache.flink.api.common.eventtime.*;

public class RtmpWatermarkStrategy<T> implements WatermarkStrategy<OrderEvent> {
    // 允许乱序数据的最大限度为3s
    private  long maxOutOfOrderness = 10000L;
    public RtmpWatermarkStrategy() {
    }
    public RtmpWatermarkStrategy(long maxOutOfOrderness) {
        this.maxOutOfOrderness = maxOutOfOrderness;
    }
    @Override
    public WatermarkGenerator<OrderEvent> createWatermarkGenerator(WatermarkGeneratorSupplier.Context context) {
        return new WatermarkGenerator<OrderEvent>(){
            private long maxTimesStamp = Long.MIN_VALUE;
            @Override
            public void onEvent(OrderEvent orderEvent, long l, WatermarkOutput watermarkOutput) {
                maxTimesStamp = Math.max(orderEvent.getOrderDate(), maxTimesStamp);
            }

            @Override
            public void onPeriodicEmit(WatermarkOutput watermarkOutput) {
                watermarkOutput.emitWatermark(new Watermark(maxTimesStamp - maxOutOfOrderness));
            }
        };
    }
}
