package com.yum;

import com.ctrip.framework.apollo.spring.annotation.EnableApolloConfig;
import com.yum.common.model.OrderCheckRes;
import com.yum.common.model.OrderEvent;
import com.yum.common.schemas.RuleResSchema;
import com.yum.common.utils.ESSinkUtil;
import com.yum.common.utils.ExecutionEnvUtil;
import com.yum.common.utils.GsonUtil;
import com.yum.common.utils.KafkaConfigUtil;
import com.yum.configure.SystemEnvConfig;
import com.yum.function.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.*;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;
import org.apache.http.HttpHost;
import org.elasticsearch.client.Requests;
import org.elasticsearch.common.xcontent.XContentType;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.yum.common.constant.PropertiesConstants.*;

@Slf4j
@EnableApolloConfig
public class RtmpApp {
    private static final OutputTag<OrderEvent> alarmTag = new OutputTag<OrderEvent>("alarm") {};
    private static final OutputTag<OrderEvent> esShowTag = new OutputTag<OrderEvent>("esShow") {};
    private static final OutputTag<OrderEvent> statisticalIndicatorsTag = new OutputTag<OrderEvent>("statisticalIndicators") {};


    final static MapStateDescriptor<String, String> RULES = new MapStateDescriptor<>(
            "mysql_rules",
            BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO);

    final static MapStateDescriptor<String, String> REDIS_RULES = new MapStateDescriptor<>(
            "redis_rules",
            BasicTypeInfo.STRING_TYPE_INFO,
            BasicTypeInfo.STRING_TYPE_INFO);


    public static void main(String[] args) throws Exception {
        final ParameterTool parameterTool = ExecutionEnvUtil.createParameterTool(args);
        StreamExecutionEnvironment env = ExecutionEnvUtil.prepare(parameterTool);
        //  设置流处理环境变量
        SystemEnvConfig.SetEnvConf(env, parameterTool);

        // 设置checkpoint
        CheckpointConfig checkpointConf = env.getCheckpointConfig();
        SystemEnvConfig.SetCheckpointConf(checkpointConf);

        // 規則匹配数据流,数据流定时从redis中查出来数据
        DataStreamSource<Map<String, String>> redisRuleDataStream = env.addSource(new RedisRuleDataSource()).setParallelism(1);
        // test for get data from MySQL
        // ruleDataStream.print();

        // 从kafka中获取的数据可以提前解析过滤
        SingleOutputStreamOperator<OrderEvent> data = KafkaConfigUtil.buildOrderSource(env)
                                    // 有状态算子一定要配置 uid
                                    .uid("order_topic_name")
                                    // 过滤掉 null
                                    .filter(Objects::nonNull)
                                    .flatMap(new FlatMapFunction<OrderEvent, OrderEvent>() {
                                        @Override
                                        public void flatMap(OrderEvent orderEvent, Collector<OrderEvent> collector) throws Exception {
                                            // System.out.println("id: " + orderEvent.getId());
                                            collector.collect(orderEvent);
                                        }
                                    }).setParallelism(1);

        // 分流，一部分数据作为报警check，一部分数据处理后放入es中
        SingleOutputStreamOperator<OrderEvent> sideOutputData = data.process(new ProcessFunction<OrderEvent, OrderEvent>() {
            @Override
            public void processElement(OrderEvent orderEvent, Context context, Collector<OrderEvent> collector) throws Exception {
                String orderId = orderEvent.getUserId();
                context.output(alarmTag, orderEvent);
                context.output(esShowTag, orderEvent);
                context.output(statisticalIndicatorsTag, orderEvent);
            }
        });

        // 获取报警分流数据,广播到所有的算子
        DataStream<OrderEvent> alarmDataStream = sideOutputData.getSideOutput(alarmTag);

        // kafka数据和来自redis的规则数据流合并
        SingleOutputStreamOperator<OrderCheckRes> kafkaRedisMerge = alarmDataStream
                .connect(redisRuleDataStream.broadcast(REDIS_RULES))
                .process(new RedisRuleBroadcastProcessFunction(REDIS_RULES));
        kafkaRedisMerge.uid("kafka redis rule");
        SingleOutputStreamOperator filterRuleData = kafkaRedisMerge.filter(new FilterFunction<OrderCheckRes>() {
            @Override
            public boolean filter(OrderCheckRes ruleRes) throws Exception {
                OrderCheckRes orderCheckRes = ruleRes;
                if (orderCheckRes.getIsPass() == 0) {
                    return true;
                }
                return  false;
            }
        });
        filterRuleData.print();
        // sink到kafka中
        filterRuleData.addSink(new FlinkKafkaProducer<>(
                parameterTool.get("kafka.sink.brokers"),
                parameterTool.get("kafka.sink.topic"),
                new RuleResSchema()
        )).name("flink-connectors-kafka")
                .setParallelism(1); //(parameterTool.getInt("stream.sink.parallelism"));

        List<HttpHost> esAddresses = ESSinkUtil.getEsAddresses(parameterTool.get(ELASTICSEARCH_HOSTS));
        int bulkSize = parameterTool.getInt(ELASTICSEARCH_BULK_FLUSH_MAX_ACTIONS, 40);
        int sinkParallelism = parameterTool.getInt(STREAM_SINK_PARALLELISM, 2);

        log.info("-----esAddresses = {}, parameterTool = {}, ", esAddresses, parameterTool);

        // 分流后给es使用
        DataStream<OrderEvent> esShowDataStream = sideOutputData.getSideOutput(esShowTag);

        // sink到es中
        ESSinkUtil.addOrderSink(esAddresses, bulkSize, sinkParallelism, kafkaRedisMerge,
                (OrderCheckRes OrderValidateResult, RuntimeContext runtimeContext, RequestIndexer requestIndexer) -> {
                    if(OrderValidateResult.getIsPass()!=null && OrderValidateResult.getIsPass()!=1){
                        requestIndexer.add(Requests.indexRequest()
                                .index(RTMP)
                                .type("_doc")
                                .source(GsonUtil.toJSONBytes(OrderValidateResult), XContentType.JSON));
                    }
                },
                parameterTool);
        env.execute("Yum Runtime monitor platform");
    }
}
