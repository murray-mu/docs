package com.yum.function;

import com.yum.common.utils.MySQLUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.exceptions.JedisConnectionException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import static com.yum.common.constant.PropertiesConstants.*;

@Slf4j
public class RedisRuleDataSource extends RichSourceFunction<Map<String, String>> {

    private Connection connection = null;
    private PreparedStatement ps = null;
    private volatile boolean isRunning = true;
    private ParameterTool parameterTool;
    Jedis jedis = null;
    String host = null;
    int port = 0;
    final long SLEEP_MILLION = 20000;
    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        parameterTool = (ParameterTool) (getRuntimeContext().getExecutionConfig().getGlobalJobParameters());

        //String database = parameterTool.get(MYSQL_DATABASE);
        host = parameterTool.get(REDIS_HOST);
        String password = parameterTool.get(REDIS_PASSWORD);
        port = Integer.parseInt(parameterTool.get(REDIS_PORT));
        String username = parameterTool.get(REDIS_USERNAME);
        this.jedis = new Jedis(host, port);
    }

    public void run_test(SourceContext<Map<String, String>> ctx) throws Exception {
        HashMap<String, String> kVMap = new HashMap<String, String>();
        while(isRunning){
            try{
                kVMap.clear();
                Map<String, String> areas = jedis.hgetAll("data_version:DV_1_ALL_STORE");
                for (Map.Entry<String,String> entry:areas.entrySet()) {
                    String key = entry.getKey();
                    String value = entry.getValue();
                    String[] splits = value.split(",");
                    System.out.println("key:"+key+"，--value："+value);
                    for (String split:splits){
                        kVMap.put(split, key);
                    }
                }
                if(kVMap.size() > 0) {
                    Map<String, String> mapData = new HashMap<>();
                    mapData.put("redis_rules", kVMap.toString());
                    ctx.collect(mapData);
                    kVMap.clear();
                    mapData.clear();
                }else {
                    log.warn("从redis中获取的数据为空");
                }
                Thread.sleep(SLEEP_MILLION);

            }catch (JedisConnectionException e){
                log.warn("redis连接异常，需要重新连接", e.getCause());
                this.jedis = new Jedis(host, port);
            }catch (Exception e) {
                log.warn(" source 数据源异常",e.getCause());
            }
        }
    }

    @Override
    public void run(SourceContext<Map<String, String>> ctx) throws Exception {
        while(isRunning){
            try{
                String ruleData = jedis.get("rtmp.rule.data");

                if(ruleData != null && ruleData.length() != 0) {
                    Map<String, String> mapData = new HashMap<>();
                    mapData.put("redis_rules", ruleData);
                    ctx.collect(mapData);
                    mapData.clear();
                }else {
                    log.warn("从redis中获取的数据为空");
                }
                Thread.sleep(SLEEP_MILLION);

            }catch (JedisConnectionException e){
                log.warn("redis连接异常，需要重新连接", e.getCause());
                this.jedis = new Jedis(host, port);
            }catch (Exception e) {
                log.warn(" source 数据源异常",e.getCause());
            }
        }
    }

    @Override
    public void cancel() {
        isRunning = false;
    }
}
