package com.yum.function;

import com.alibaba.fastjson.JSON;
import com.yum.common.model.OrderCheckRes;
import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.RuleRes;
import com.yum.rule.service.ProcessDispatch;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.map.HashedMap;
import org.apache.flink.api.common.state.BroadcastState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.state.ReadOnlyBroadcastState;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
public class RedisRuleBroadcastProcessFunction extends BroadcastProcessFunction<OrderEvent, Map<String, String>, OrderCheckRes> {

    private MapStateDescriptor<String, String> alarmRulesMapStateDescriptor;
    // 规则匹配引擎
    private static ProcessDispatch processDispatch = new ProcessDispatch();
    public RedisRuleBroadcastProcessFunction(MapStateDescriptor<String, String> alarmRulesMapStateDescriptor) {
        this.alarmRulesMapStateDescriptor = alarmRulesMapStateDescriptor;
    }

    @Override
    public void processElement(OrderEvent orderEvent, ReadOnlyContext readOnlyContext, Collector<OrderCheckRes> collector) throws Exception {
        ReadOnlyBroadcastState<String, String> broadcastState = readOnlyContext.getBroadcastState(alarmRulesMapStateDescriptor);
        Object items = orderEvent.getItems();
        Map<String, Object> map = new HashedMap();
        String ruleData = broadcastState.get("redis_rules");
        List<RuleRes> listRuleRes =  processDispatch.execute(ruleData, orderEvent);

        if (listRuleRes != null && listRuleRes.size() != 0) {
            for ( RuleRes ruleRes:listRuleRes ) {
                OrderCheckRes orderValidateResultA = new OrderCheckRes();
                // result A
                orderValidateResultA.setResId(0);
                orderValidateResultA.setRuleId(ruleRes.getResultA().ruleId);
                byte ispass = (byte) (ruleRes.getResultA().testResult?1:0);
                orderValidateResultA.setIsPass(Byte.valueOf(ispass));
                orderValidateResultA.setRuleName(ruleRes.getResultA().getRuleName());
                orderValidateResultA.setResInfo(ruleRes.getResultA().getFailedReason());
                orderValidateResultA.setRuleCode(ruleRes.getResultA().getPromtionCode());
                orderValidateResultA.setOrderId(orderEvent.getId());
                orderValidateResultA.setUserPhone(orderEvent.getLoginPhone());
                orderValidateResultA.setPhone(orderEvent.getPhone());
                orderValidateResultA.setStoreCode(orderEvent.getStoreCode());
                orderValidateResultA.setCity(orderEvent.getCityName());
                orderValidateResultA.setMarket(orderEvent.getMarketCode());
                orderValidateResultA.setOrder(JSON.toJSONString(orderEvent));
                orderValidateResultA.setCheckTime(System.currentTimeMillis());
                orderValidateResultA.setOrderTime(orderEvent.getOrderDate());
                orderValidateResultA.setChannelId(orderEvent.getChannelId());
                collector.collect(orderValidateResultA);

                // Result B
                OrderCheckRes orderValidateResultB = new OrderCheckRes();
                orderValidateResultB.setResId(0);
                orderValidateResultB.setRuleId(ruleRes.getResultB().ruleId);
                byte isPassB = (byte) (ruleRes.getResultB().testResult?1:0);
                orderValidateResultB.setIsPass(Byte.valueOf(isPassB));
                orderValidateResultB.setRuleName(ruleRes.getResultB().getRuleName());
                orderValidateResultB.setResInfo(ruleRes.getResultB().getFailedReason());
                orderValidateResultB.setRuleCode(ruleRes.getResultB().getPromtionCode());
                orderValidateResultB.setOrderId(orderEvent.getId());
                orderValidateResultB.setUserPhone(orderEvent.getLoginPhone());
                orderValidateResultB.setPhone(orderEvent.getPhone());
                orderValidateResultB.setStoreCode(orderEvent.getStoreCode());
                orderValidateResultB.setCity(orderEvent.getCityName());
                orderValidateResultB.setMarket(orderEvent.getMarketCode());
                orderValidateResultB.setOrder(JSON.toJSONString(orderEvent));
                orderValidateResultB.setCheckTime(System.currentTimeMillis());
                orderValidateResultB.setOrderTime(orderEvent.getOrderDate());
                orderValidateResultB.setChannelId(orderEvent.getChannelId());
                collector.collect(orderValidateResultB);
            }
        } else {
            log.info("-----listRuleRes = {null} ");
        }
    }

    @Override
    public void processBroadcastElement(Map<String, String> value, Context context, Collector<OrderCheckRes> collector) throws Exception {
        if (value != null) {
            BroadcastState<String, String> broadcastState = context.getBroadcastState(alarmRulesMapStateDescriptor);
            for (Map.Entry<String, String> entry : value.entrySet()) {
                broadcastState.put(entry.getKey(), entry.getValue());
            }
        }
    }
}
