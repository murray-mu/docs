package com.yum.function;

import com.yum.common.model.OrderEvent;
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
import org.apache.flink.streaming.api.functions.AssignerWithPunctuatedWatermarks;
import org.apache.flink.streaming.api.watermark.Watermark;

import javax.annotation.Nullable;

public class RtmpAssignerWithPeriodicWatermarks<T> implements AssignerWithPeriodicWatermarks<OrderEvent> {
    private long currentTimestamp = Long.MIN_VALUE;
    private long maxTimeLag = 10000;

    public RtmpAssignerWithPeriodicWatermarks(long currentTimestamp, long maxTimeLag) {
        this.currentTimestamp = currentTimestamp;
        this.maxTimeLag = maxTimeLag;
    }

    public RtmpAssignerWithPeriodicWatermarks() {

    }

    @Nullable
    @Override
    public Watermark getCurrentWatermark() {
        return new Watermark(currentTimestamp == Long.MIN_VALUE ? Long.MIN_VALUE : currentTimestamp - maxTimeLag);
    }

    @Override
    public long extractTimestamp(OrderEvent orderEvent, long l) {
        long timestamp = orderEvent.getOrderDate();
        currentTimestamp = Math.max(timestamp, currentTimestamp);
        return timestamp;
    }
}
