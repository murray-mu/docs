package com.yum.configure;

import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.contrib.streaming.state.RocksDBStateBackend;
import org.apache.flink.runtime.state.StateBackend;
import org.apache.flink.runtime.state.memory.MemoryStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

import java.io.IOException;

import static com.yum.common.constant.PropertiesConstants.STREAM_CHECKPOINT_INTERVAL;

public class SystemEnvConfig {
    public  static void SetCheckpointConf(CheckpointConfig checkpointConf) {
        // 高级设置（这些配置也建议写成配置文件中去读取，优先环境变量）
        // 设置 exactly-once 模式
        checkpointConf.setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);

        // DELETE_ON_CANCELLATION：仅当作业失败时，作业的 Checkpoint 才会被保留用于任务恢复。
        // 当作业取消时，Checkpoint 状态信息会被删除，因此取消任务后，不能从 Checkpoint 位置进行恢复任务。
        //
        // RETAIN_ON_CANCELLATION：当作业手动取消时，将会保留作业的 Checkpoint 状态信息。
        // 注意，这种情况下，需要手动清除该作业保留的 Checkpoint 状态信息，否则这些状态信息将永远保留在外部的持久化存储中
        checkpointConf.enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);

        // 设置 checkpoint 最小间隔 50000 ms
        checkpointConf.setMinPauseBetweenCheckpoints(50000);
        // 设置 checkpoint 必须在1分钟内完成，否则会被丢弃
        checkpointConf.setCheckpointTimeout(60000);
        // 设置 checkpoint 失败时，任务不会 fail，该 checkpoint 会被丢弃
        checkpointConf.setFailOnCheckpointingErrors(false);
        // 设置 checkpoint 的并发度为 1
        checkpointConf.setMaxConcurrentCheckpoints(1);

    }
    public  static void SetEnvConf(StreamExecutionEnvironment env, ParameterTool parameterTool) throws IOException {
        env.setParallelism(2);
        // 每隔 10s 重启一次，如果两分钟内重启过三次则停止 Job
        // env.setRestartStrategy(RestartStrategies.failureRateRestart(3, org.apache.flink.api.common.time.Time.minutes(2), org.apache.flink.api.common.time.Time.seconds(10)));

        // 生产环境中建议使用rocksdb
        // StateBackend stateBackend = new RocksDBStateBackend("hdfs://10.67.31.111:8020/flink/checkpoint/rtmp");
        StateBackend stateBackend = new MemoryStateBackend(5 * 1024 * 1024 * 100);
        env.setStateBackend(stateBackend);
        // 每隔 5s 重启一次，尝试三次如果 Job 还没有起来则停止
        env.setRestartStrategy(RestartStrategies.fixedDelayRestart(3, 5000));
        // 设置 checkpoint 周期时间
        env.enableCheckpointing(parameterTool.getLong(STREAM_CHECKPOINT_INTERVAL, 60000));
    }
}
