package com.yum.function;

import com.yum.common.model.OrderEvent;
import org.apache.flink.api.common.state.BroadcastState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.state.ReadOnlyBroadcastState;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;

import java.util.Map;

public class RuleBroadcastProcessFunction extends BroadcastProcessFunction<OrderEvent, Map<String, String>, OrderEvent> {

    private MapStateDescriptor<String, String> alarmRulesMapStateDescriptor;

    public RuleBroadcastProcessFunction(MapStateDescriptor<String, String> alarmRulesMapStateDescriptor) {
        this.alarmRulesMapStateDescriptor = alarmRulesMapStateDescriptor;
    }

    @Override
    public void processElement(OrderEvent orderEvent, ReadOnlyContext readOnlyContext, Collector<OrderEvent> collector) throws Exception {
        ReadOnlyBroadcastState<String, String> broadcastState = readOnlyContext.getBroadcastState(alarmRulesMapStateDescriptor);
        Object items = orderEvent.getItems();
//        if (!items.containsKey("type") && !tags.containsKey("target_id")) {
//            return;
//        }
        String ruleData = broadcastState.get("mysql_rules");
//        if (ruleData != null) {
//            // 规则匹配后，保存到
//            orderEvent.getTags().put("target_id", targetId);
//            collector.collect(orderEvent);
//        }
        collector.collect(orderEvent);
    }

    @Override
    public void processBroadcastElement(Map<String, String> value, Context context, Collector<OrderEvent> collector) throws Exception {
        if (value != null) {
            BroadcastState<String, String> broadcastState = context.getBroadcastState(alarmRulesMapStateDescriptor);
            for (Map.Entry<String, String> entry : value.entrySet()) {
                broadcastState.put(entry.getKey(), entry.getValue());
            }
        }
    }
}
