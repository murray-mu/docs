# 启动flink应用
```$xslt
    规则业务处理:
    处理函数：RuleBroadcastProcessFunction.java 中的processElement
        1：获取规则
            broadcastState.get("ruleData") 从redis或者mysql获取规则
        2：规则匹配
            从流数据中orderEvent.getItems() 得到数据，匹配规则，如果有不符合的规则
        发送到下游算子进行统计
```