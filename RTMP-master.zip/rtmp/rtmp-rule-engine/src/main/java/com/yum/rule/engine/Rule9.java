package com.yum.rule.engine;

import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;
import org.apache.commons.collections4.CollectionUtils;
import org.eclipse.core.runtime.Assert;

//买X份A产品，外送费减免
public class Rule9 extends BaseRule {

    public Rule9(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    //初始化后校验
    @Override
    public void CheckRule(){
        super.CheckRule();
        Assert.isTrue(getRuleCondition().getaCount()!=null,getDesc()+" X没有初始化");
        Assert.isTrue(CollectionUtils.isNotEmpty(getRuleCondition().getaProduct()),getDesc()+" A产品列表为空");
    }

    @Override
    String getDesc() {
        return "买X份A产品，外送费减免";
    }

    @Override
    int getRuleId() {
        return 9;
    }

    /**
     * 买了X份A产品，没有免外
     */
    @Override
    public void matchAFlag(OrderEvent order) throws RuleException {
        //订单存在互斥的优惠 执行成功
        if(existConflictRule(order)){
            return ;
        }
        //买了X份A
        int matchedCount = matchedCount(order,getRuleCondition());
        if(matchedCount >= 0){
            if(!existDeliveryFree(order)){
                throw new RuleException(-2);
            };
        }
    }

    //享受了这个优惠，但是订单没有满XX元
    @Override
    public void matchBFlag(OrderEvent order)throws RuleException {
        //订单存在与这个优惠互斥的优惠的话 这个就不需要执行了
        if(existConflictRule(order)){
            return ;
        }
        //存在B元的补贴项
        boolean condition2 = existDeliveryFree(order);
        if(condition2){
            int matchedCount = matchedCount(order,getRuleCondition());
            if(matchedCount<=0){
                throw new RuleException(-3);
            }
        }
    }
}
