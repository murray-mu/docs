package com.yum.rule.engine;


import com.yum.common.model.IOrderItem;
import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.BaseCondition;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;
import org.apache.commons.collections4.CollectionUtils;
import org.eclipse.core.runtime.Assert;

import java.util.List;
import java.util.Map;

//产品互斥
public class Rule17 extends BaseRule{

    public Rule17(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    @Override
    public void CheckRule(){
        Assert.isTrue(getRuleCondition().getConflictProuduct()!=null,getDesc()+" 互斥产品未初始化");
    }

    @Override
    String getDesc() {
        return "产品互斥";
    }

    @Override
    int getRuleId() {
        return 17;
    }

    @Override
    public void matchAFlag(OrderEvent order) {

    }

    @Override
    public void matchBFlag(OrderEvent order) throws RuleException {
        if(CollectionUtils.isNotEmpty(order.getItems())){
            for (IOrderItem item : order.getItems()){
                if(getRuleCondition().getConflictProuduct()!=null && getRuleCondition().getConflictProuduct().size()>0){
                    for(Map.Entry<String, List<String>> entry : getRuleCondition().getConflictProuduct().entrySet()){
                        String keyId = entry.getKey();
                        List<String> conflictKeyIds = entry.getValue();
                        if(keyId.equalsIgnoreCase(String.valueOf(item.getLinkId()==null?"":item.getLinkId()))){
                            if(existPmIdInOrder(order,conflictKeyIds)){
                                throw new RuleException(-1,"存在互斥产品");
                            }
                        }
                    }
                }
            }
        }
    }

    private boolean existPmIdInOrder(OrderEvent order, List<String> conflictKeyIds) {
        for (IOrderItem item : order.getItems()){
            for(String str : conflictKeyIds){
                if(str.equalsIgnoreCase(String.valueOf(item.getLinkId()==null?"":item.getLinkId()))){
                    return true;
                }
            }
        }
        return false;
    }

}
