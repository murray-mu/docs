package com.yum.rule.engine;


import com.yum.common.constant.OrderConstants;
import com.yum.common.model.IOrderItem;
import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.BaseCondition;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;

//买prime卡 随卡使用权益(如果有prime卡存在不是免外权益 会出现问题)
public class Rule21 extends BaseRule {

    public Rule21(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    @Override
    String getDesc() {
        return "随卡使用权益";
    }

    @Override
    int getRuleId() {
        return 21;
    }

    //买了卡 没有减免的权益
    @Override
    public void matchAFlag(OrderEvent order) throws RuleException {
        boolean existBuyCard = false;
        for(IOrderItem item : order.getItems()){
            byte type = item.getType();
            if(type == OrderConstants.OrderItemType.PRIME_CARD){
                existBuyCard = true;
            }
        }
        if(existBuyCard){
            for(IOrderItem item : order.getItems()){
                byte type = item.getType();
                if(type == OrderConstants.OrderItemType.FREE_DELIVERY){
                    return;
                }
            }
            throw new RuleException(-2);
        }
    }

    @Override
    public void matchBFlag(OrderEvent order){

    }
}
