package com.yum.rule.engine;

import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.BaseCondition;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;
import org.eclipse.core.runtime.Assert;

//整单满XX元，外送费减
public class Rule7 extends BaseRule {

    public Rule7(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    //初始化后校验
    @Override
    public void CheckRule(){
        Assert.isTrue(getRuleCondition().getFullMoney()!=null,getDesc()+" XX没有初始化");
    }

    @Override
    String getDesc() {
        return "整单满XX元，外送费减";
    }

    @Override
    int getRuleId() {
        return 7;
    }

    /**
     * 满了XX元，没有免外
     */
    @Override
    public void matchAFlag(OrderEvent order) throws RuleException {
        //订单存在互斥的优惠 执行成功
        if(existConflictRule(order)){
            return ;
        }
        //整单金额
        long price = getToTal(order,getRuleCondition());
        boolean condition1 = price >= getRuleCondition().getFullMoney();
        if(condition1){
            //存在B元的补贴项 -- 优惠code是这个优惠的code
            if(!existDeliveryFree(order)){
              throw new RuleException(-2);
            }

        }

    }

    //免外了，但是订单金额没有满
    @Override
    public void matchBFlag(OrderEvent order) throws RuleException{
        //订单存在与这个优惠互斥的优惠的话 这个就不需要执行了
        if(existConflictRule(order)){
            return ;
        }
        //存在B元的补贴项
        boolean condition2 = existDeliveryFree(order);
        if(condition2){
            long price = getToTal(order,getRuleCondition());
            if(price < getRuleCondition().getFullMoney()){
                throw new RuleException(-3);
            }
        }
    }






}
