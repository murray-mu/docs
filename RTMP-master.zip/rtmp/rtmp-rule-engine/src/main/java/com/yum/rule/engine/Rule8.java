package com.yum.rule.engine;


import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.BaseCondition;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;

//买X份A产品,第二份半价
public class Rule8 extends BaseRule{


    public Rule8(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    @Override
    String getDesc() {
        return "买X份A产品,第二份半价";
    }

    @Override
    int getRuleId() {
        return 8;
    }

    @Override
    void matchAFlag(OrderEvent order) throws RuleException {

    }

    @Override
    void matchBFlag(OrderEvent order) throws RuleException {

    }


}
