package com.yum.rule.engine;

import com.yum.common.constant.OrderConstants;
import com.yum.common.model.IOrderItem;
import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.core.runtime.Assert;

//整单满A元，以折扣百分比购买Y份B产品
public class Rule16 extends BaseRule {

    public Rule16(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    @Override
    String getDesc() {
        return "整单满A元，以折扣百分比购买Y份B产品";
    }

    @Override
    int getRuleId() {
        return 16;
    }

    @Override
    public void CheckRule(){
        super.CheckRule();
        Assert.isTrue(getRuleCondition().getFullMoney()!=null,getDesc()+" A没有初始化");
        Assert.isTrue(getRuleCondition().getbCount()!=null,getDesc()+ " Y未初始化");
        Assert.isTrue(CollectionUtils.isNotEmpty(getRuleCondition().getbProduct()),getDesc()+ " B产品列表为空");
        Assert.isTrue(getRuleCondition().getcDiscount()!=null,getDesc()+ " 折扣百分比未空");
    }

    @Override
    public void matchAFlag(OrderEvent order) throws RuleException {
        if(existConflictRule(order)){
            return ;
        }
        //整单金额
        long totalPrice = getToTal(order,getRuleCondition());
        boolean condition1 = totalPrice >= getRuleCondition().getFullMoney();
        if(condition1 ){
            int matchCount = 0;
            if(getRuleCondition().isMultiUse()){
                if(getRuleCondition().getFullMoney() == 0){
                    matchCount = 999;
                }else{
                    matchCount = (int)(totalPrice/getRuleCondition().getFullMoney());
                }
            }else{
                matchCount = 1;
            }
            if(!existAmountTypeRuleId(order,matchCount)){
                throw new RuleException(-2);
            }
        }
    }

    /**
     * 享受了这个优惠（订单里面有相关优惠code），但是没有买X份A产品
     * @param order
     * @return
     */
    @Override
    public void matchBFlag(OrderEvent order) throws RuleException {
        //订单存在与这个优惠互斥的优惠的话 这个就不需要执行了
        if(existConflictRule(order)){
            return ;
        }
        int matchCount = existAmountTypeRuleId(order);
        if(matchCount>0){
            long price = getToTal(order,getRuleCondition());
            if(getRuleCondition().isMultiUse()){
                if(price <  getRuleCondition().getFullMoney() * matchCount){
                    throw new RuleException(-3);
                }
            }else if(!(price >= getRuleCondition().getFullMoney() && matchCount == 1)){
                throw new RuleException(-3);
            }
        }
    }

    @Override
    public boolean existAmountTypeRuleId(OrderEvent order , int matchCount) throws RuleException {
        boolean flag = false;
        //折扣率
        long discount = 0;
        long realTotal = 0;
        //折扣数量
        int count = 0;
        int matchedCount = 0;
        if(CollectionUtils.isNotEmpty(order.getItems())){
            for(IOrderItem item : order.getItems()){
                //整单减的时候
                if(getRuleCondition().getcDiscount()!=null){
                    if(StringUtils.isNotBlank(item.getPromotionCode()) && item.getPromotionCode().equalsIgnoreCase(getRuleCondition().getPromotionCode()) && OrderConstants.OrderItemType.PRODUCT_PROMOTION == item.getType()){
                        if(!getRuleCondition().getbProduct().contains(String.valueOf(item.getLinkId()))){
                            throw new RuleException(-1,"存在非B产品集产品运行该规则，规则code" + getRuleCondition().getPromotionCode());
                        }
                        flag = true;
                        discount = item.getRealPrice()/ item.getPrice();
                        count += item.getQuantity();
                    }
                }
            }
        }
        if(flag){
            if(count % getRuleCondition().getbCount() == 0){
                matchedCount = count / getRuleCondition().getbCount();
            }else{
                throw new RuleException(-1,"优惠产品总金额{}和应该优惠的金额{}不一致");
            }
            return getRuleCondition().getcDiscount() >= discount && matchedCount == matchCount;
        }else{
            return false;
        }
    }

    @Override
    protected int existAmountTypeRuleId(OrderEvent order) throws RuleException {
        long discount = 0;
        int count = 0;
        int matchCount = 0;
        if(CollectionUtils.isNotEmpty(order.getItems())){
            for(IOrderItem item : order.getItems()){
                if(OrderConstants.OrderItemType.PRODUCT_PROMOTION == item.getType()){
                    if(StringUtils.isNotBlank(item.getPromotionCode()) && item.getPromotionCode().equalsIgnoreCase(getRuleCondition().getPromotionCode()) ){
                        if(getRuleCondition().getbProduct().contains(String.valueOf(item.getLinkId()))){
                            discount += item.getRealPrice()/item.getPrice();
                            count += item.getQuantity();
                        }else{
                            throw new RuleException(-1,"存在非B产品集产品运行该规则，规则code" + getRuleCondition().getPromotionCode());
                        }
                    }
                }
            }
        }
        if(count % getRuleCondition().getbCount() !=0){
            throw new RuleException(-1,"优惠产品数量不是"+getRuleCondition().getbCount()+"的整数倍");
        }else{
            matchCount = count / getRuleCondition().getbCount();
        }
        if(discount >= 0 || discount <= getRuleCondition().getbCount()  ){
            return matchCount;
        }else{
            throw new RuleException(-1,"优惠产品总金额{}和应该优惠的金额{}不一致");
        }
    }
}
