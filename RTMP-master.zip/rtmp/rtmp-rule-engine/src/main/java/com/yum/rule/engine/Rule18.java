package com.yum.rule.engine;

import com.yum.common.model.IOrderItem;
import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.core.runtime.Assert;

import java.util.List;

//互斥优惠
public class Rule18 extends BaseRule{

    public Rule18(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    @Override
    public void CheckRule(){
        Assert.isTrue(getRuleCondition().getConflictPromotionMap()!=null,getDesc()+" 互斥优惠code未初始化");
    }


    @Override
    String getDesc() {
        return "互斥优惠";
    }

    @Override
    int getRuleId() {
        return 18;
    }

    @Override
    void matchAFlag(OrderEvent order) throws RuleException { }

    @Override
    public void matchBFlag(OrderEvent order)throws RuleException {
        if(CollectionUtils.isNotEmpty(order.getItems())){
            for(IOrderItem item : order.getItems()){
                if (StringUtils.isNotEmpty(item.getPromotionCode())) {
                    if(getRuleCondition().getConflictPromotionMap().get(item.getPromotionCode()) != null){
                        if(existPromotionCodeInOrder(order,getRuleCondition().getConflictPromotionMap().get(item.getPromotionCode()))){
                            throw new RuleException(-1,"存在互斥优惠");
                        }
                    }
                }
            }
        }
    }


    private boolean existPromotionCodeInOrder(OrderEvent order, List<String> conflictKeyIds) {
        for (IOrderItem item : order.getItems()){
            for(String str : conflictKeyIds){
                if(str.equalsIgnoreCase(item.getPromotionCode()==null?"":item.getPromotionCode())){
                    return true;
                }
            }
        }
        return false;
    }
}
