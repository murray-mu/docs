package com.yum.rule.engine;

import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.BaseCondition;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;
import org.eclipse.core.runtime.Assert;

//整单满A元，减B元
public class Rule5 extends BaseRule {


    public Rule5(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    @Override
    public void CheckRule() {
        super.CheckRule();
        Assert.isTrue(getRuleCondition().getFullMoney()!=null,getDesc()+" A没有初始化");
        Assert.isTrue(getRuleCondition().getTotalDiscount()!=null,getDesc()+ " B元没有初始化");
    }

    @Override
    String getDesc() {
        return ("整单满A元，减B元");
    }

    @Override
    int getRuleId() {
        return 5;
    }

    /**
     * 满了XX元，没有减钱
     */
    @Override
    public void matchAFlag(OrderEvent order) throws RuleException {
        //订单存在互斥的优惠 执行成功
        if(existConflictRule(order)){
            return;
        }
        //整单金额
        long totalPrice = getToTal(order,getRuleCondition());
        boolean condition1 = totalPrice >= getRuleCondition().getFullMoney();
        if(condition1){
            int matchCount = 0;
            if(getRuleCondition().isMultiUse()){
                if(getRuleCondition().getFullMoney() == 0){
                    matchCount = 999;
                }else{
                    matchCount = (int)(totalPrice/getRuleCondition().getFullMoney());
                }
            }else{
                matchCount = 1;
            }
            //存在B元的补贴项 -- 优惠code是这个优惠的code
            if(!existAmountTypeRuleId(order,matchCount)){
                throw new RuleException(-2);
            }
        }

    }

    //享受了这个优惠，但是订单没有满XX元
    @Override
    public void matchBFlag(OrderEvent order) throws RuleException {
        //订单存在与这个优惠互斥的优惠的话 这个就不需要执行了
        if(existConflictRule(order)){
            return ;
        }
        //存在B元的补贴项
        int count = existAmountTypeRuleId(order);
        if(count>0){
            long price = getToTal(order,getRuleCondition());
            if(getRuleCondition().isMultiUse()){
                if(price < getRuleCondition().getTotalDiscount() * count){
                    throw new RuleException(-3);
                }
            }else if(!(price >= getRuleCondition().getFullMoney() && count == 1)){
                throw new RuleException(-3);
            }
        }
    }

}
