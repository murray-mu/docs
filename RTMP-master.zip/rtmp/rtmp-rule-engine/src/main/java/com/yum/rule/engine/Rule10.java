package com.yum.rule.engine;

import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.BaseCondition;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;
import org.apache.commons.collections4.CollectionUtils;
import org.eclipse.core.runtime.Assert;


//买X份A产品,A产品折扣
public class Rule10 extends BaseRule{
    public Rule10(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    @Override
    String getDesc() {
        return "买X份A产品,A产品折扣";
    }

    @Override
    int getRuleId() {
        return 10;
    }

    @Override
    public void CheckRule(){
        super.CheckRule();
        Assert.isTrue(getRuleCondition().getaCount()!=null,getDesc()+" X没有初始化");
        Assert.isTrue(CollectionUtils.isNotEmpty(getRuleCondition().getaProduct()),getDesc()+" A产品列表为空");

    }

    /**
     * 买了X份A产品，没打折
     */
    @Override
    public void matchAFlag(OrderEvent order) throws RuleException {
        if(existConflictRule(order)){
            return ;
        }
        //买了X份A
        int matchedCount = matchedCount(order,getRuleCondition());
        if(matchedCount > 0){
            throw new RuleException(-2);
        }

    }

    //享受了这个优惠，产品没有满x份
    @Override
    public void matchBFlag(OrderEvent order) throws RuleException{
        //订单存在互斥的优惠 执行成功
        if(existConflictRule(order)){
            return ;
        }
        //买了X份A
        if (CollectionUtils.isNotEmpty(getRuleCondition().getaProduct())) {
            int aNum = getRuleCondition().getaCount();
            int count = 0;
            if (getRuleCondition().isMultiUse()) {
                count = findPromotionCodeInOrder(order);
                if(count % aNum != 0){
                    throw new RuleException(-2);
                }
            } else {
                if(count != aNum){
                    throw new RuleException(-2);
                }
            }
        }
    }

}
