package com.yum.rule.engine;


import com.yum.common.constant.OrderConstants;
import com.yum.common.model.IOrderItem;
import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;

//低折扣
public class Rule20 extends BaseRule {

    public Rule20(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    @Override
    String getDesc() {
        return "低折扣";
    }

    @Override
    int getRuleId() {
        return 20;
    }

    /**
     * 买了X份A产品，没有以优惠价XX元购买Y份B产品
     * @param order
     * @return
     */
    @Override
    public void matchAFlag(OrderEvent order) {

    }

    /**
     * 享受了这个优惠（订单里面有相关优惠code），但是没有买X份A产品
     * @param order
     * @return
     */
    @Override
    public void matchBFlag(OrderEvent order) throws RuleException {
            //订单原价 0/1产品总和
            long orginalTotal = getOriginalTotal(order);
            //订单需要支付的金额 是6的项
            long realTotal = getRealTotal(order);
            if(realTotal/orginalTotal < getRuleCondition().getcDiscount()){
                throw new RuleException(-3) ;
            }
    }

    private long getOriginalTotal(OrderEvent order) {
        long sum = 0;
        for(IOrderItem item : order.getIOrderItems()){
            if(OrderConstants.OrderItemType.NO_PROMOTION  == item.getType()|| OrderConstants.OrderItemType.PRODUCT_PROMOTION  == item.getType()){
                sum = item.getQuantity() * item.getRealPrice();
            }
        }
        return sum;
    }

    public long getRealTotal(OrderEvent order){
        long sum = 0;
        for(IOrderItem item : order.getIOrderItems()){
            if(OrderConstants.OrderItemType.PAID_AMOUNT  == item.getType()){
                sum = item.getQuantity() * item.getRealPrice();
            }
        }
        return sum;
    }
}
