package com.yum.rule.engine;


import com.yum.common.constant.OrderConstants;
import com.yum.common.model.IOrderItem;
import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;

//特价菜 折扣/价格
public class Rule19 extends BaseRule {

    public Rule19(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    @Override
    String getDesc() {
        return "特价菜";
    }

    @Override
    int getRuleId() {
        return 19;
    }

    /**
     * 买了X份A产品，没有以优惠价XX元购买Y份B产品
     * @param order
     * @return
     */
    @Override
    public void matchAFlag(OrderEvent order) throws RuleException {

        //订单供多少个符合标准的产品
        int matchedCount = findMatchedProductA(order,getRuleCondition());
        if(matchedCount > 0){
            throw new RuleException( -2);
        }

    }

    private int findMatchedProductA(OrderEvent order, RuleCondition baseConditionParam) {
        int count = 0;
        for(IOrderItem item : order.getIOrderItems()){
            if(baseConditionParam.getaProduct().contains(String.valueOf(item.getLinkId())) && OrderConstants.OrderItemType.NO_PROMOTION ==item.getType()){
                count ++;
            }
        }
        return count;
    }

    @Override
    public void matchBFlag(OrderEvent order) throws RuleException{
        //订单存在与这个优惠互斥的优惠的话 这个就不需要执行了
        if(existConflictRule(order)){
            return ;
        }
        int matchCount = existAmountTypeRuleId(order);
        if(matchCount > 0){
            //订单供多少个符合标准的产品
            int matchedCount = matchedCount(order,getRuleCondition());
           if(matchedCount < matchCount){
               throw new RuleException(-3);
           } ;
        }
    }
}
