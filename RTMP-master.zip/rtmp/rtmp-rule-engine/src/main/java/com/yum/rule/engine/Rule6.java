package com.yum.rule.engine;


import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.BaseCondition;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;
import org.eclipse.core.runtime.Assert;

//整单满A 整单折扣B%
public class Rule6 extends BaseRule{

    public Rule6(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    //初始化后校验
    @Override
    public void CheckRule() {
        Assert.isTrue(getRuleCondition().getFullMoney()!=null,getDesc()+" A没有初始化");
        Assert.isTrue(getRuleCondition().getTotalPercent()!=null,getDesc()+" B没有初始化");
    }

    @Override
    String getDesc() {
        return "整单满A 整单折扣B";
    }

    @Override
    int getRuleId() {
        return 6;
    }

    /**
     * 满A元，没有整单折扣
     * @param order
     * @return
     */
    @Override
    public void matchAFlag(OrderEvent order) throws RuleException {
        //订单存在互斥的优惠 执行成功
        if(existConflictRule(order)){
            return ;
        }
        //整单金额
        long totalPrice = getToTal(order,getRuleCondition());
        boolean condition1 = totalPrice >= getRuleCondition().getFullMoney();
        if(condition1){
            int matchCount = 1;
            //存在B元的补贴项 -- 优惠code是这个优惠的code
            if(!existAmountTypeDiscountRuleId(order,matchCount)){
                throw new RuleException(-2);
            }
        }

    }

    /**
     * 享受了这个优惠（订单里面有相关优惠code），但是没有满A
     * @param order
     * @return
     */
    @Override
    public void matchBFlag(OrderEvent order) throws RuleException {
        //订单存在与这个优惠互斥的优惠的话 这个就不需要执行了
        if(existConflictRule(order)){
            return ;
        }
        if(existAmountTypeDiscountRuleId(order,1)){
            long price = getToTal(order,getRuleCondition());
            if(price < getRuleCondition().getFullMoney()){
                throw  new RuleException(-3);
            }
        }
    }
}
