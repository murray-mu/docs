package com.yum.rule.engine;


import com.yum.common.constant.OrderConstants;
import com.yum.common.model.IOrderItem;
import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.AssertionFailedException;

import java.util.ArrayList;
import java.util.List;

//默认的一些执行方法 比如满xx元,
public abstract class BaseRule {

    public RuleRes execute(OrderEvent order){
        CommonResult resultA = null;
        CommonResult resultB = null;
        try{
            resultA = new CommonResult(getDesc(),getRuleName(),getRuleId(),true,"成功",getPromotionCode());
            CheckRule();
            if(getRuleCondition().getaFlag() == true){
                matchAFlag(order);
            }
        }catch(AssertionFailedException assertionFailedException){
            resultA = new CommonResult(getDesc(),getRuleName(),getRuleId(),false,assertionFailedException.getMessage(),getPromotionCode());
        }catch(RuleException ruleException){
            if(ruleException.getRuleErrorCode() == -2){
                resultA = new CommonResult(getDesc(),getRuleName(),getRuleId(),false, "优惠应享受未享受校验失败",getPromotionCode());
            }else if(ruleException.getRuleErrorCode() == -3){
                resultA = new CommonResult(getDesc(),getRuleName(),getRuleId(),false,"优惠多享受校验失败",getPromotionCode());
            }else{
                resultA = new CommonResult(getDesc(),getRuleName(),getRuleId(),false,ruleException.getRuleErrorMsg(),getPromotionCode());
            }
        }catch(Exception e){
            resultA = new CommonResult(getDesc(),getRuleName(),getRuleId(),false,"未知错误",getPromotionCode());
        }
        try{
            CheckRule();
            resultB = new CommonResult(getDesc(),getRuleName(),getRuleId(),true,"成功",getPromotionCode());
            if(getRuleCondition().getbFlag() == true){
                matchBFlag(order);
            }
        }catch(AssertionFailedException assertionFailedException){
            resultB = new CommonResult(getDesc(),getRuleName(),getRuleId(),false,assertionFailedException.getMessage(),getPromotionCode());
        }catch(RuleException ruleException){
            resultB = new CommonResult(getDesc(),getRuleName(),getRuleId(),false,ruleException.getRuleErrorMsg(),getPromotionCode());
        }catch(Exception e){
            resultB = new CommonResult(getDesc(),getRuleName(),getRuleId(),false,"未知错误",getPromotionCode());
        }
        return new RuleRes(resultA,resultB);
    }

    private RuleCondition ruleCondition;

    public RuleCondition getRuleCondition() {
        return ruleCondition;
    }

    public void setRuleCondition(RuleCondition ruleCondition) {
        this.ruleCondition = ruleCondition;
    }

    public BaseRule(RuleCondition ruleCondition){
        this.ruleCondition = ruleCondition;
    }

    abstract String getDesc();
    abstract int getRuleId();
    abstract void matchAFlag(OrderEvent order) throws RuleException;
    abstract void matchBFlag(OrderEvent order)throws RuleException;
    protected String getPromotionCode(){
        return getRuleCondition().getPromotionCode();
    }
    protected String getRuleName(){ return getRuleCondition().getRuleName(); };

    protected void CheckRule(){
        Assert.isTrue(getRuleCondition()!=null,getDesc()+" 参数对象为空不能初始化");
        Assert.isTrue(getRuleCondition().getaFlag()!=null,getDesc()+" 优惠未享受开关不能为空");
        Assert.isTrue(getRuleCondition().getbFlag()!=null,getDesc()+" 优惠多享受开关不能为空");
    };


    //整单满XX元  需要判断 是否是独立执行&是否允许多次
    protected long getToTal(OrderEvent order,RuleCondition ruleCondition) {
        long sum = 0;
        List<IOrderItem> l = new ArrayList<>();
        for (IOrderItem item : order.getItems()) {
            //优惠本身不计算
            if (StringUtils.isNotBlank(item.getPromotionCode()) && item.getPromotionCode().equals(ruleCondition.getPromotionCode())) {
                continue;
            }
            byte promotionType = item.getType();
            //外送费和买卡不计算
            if (isAmountOrDeliveryType(promotionType) || promotionType == OrderConstants.OrderItemType.PRIME_CARD) {
                continue;
            }
            //剩下餐品 全部算上
            sum += item.getRealPrice() * item.getQuantity();
        }
        return sum;
    }

    protected boolean isDeliveryType(byte promotionType) {
        return promotionType == OrderConstants.OrderItemType.DELIVERY || promotionType == OrderConstants.OrderItemType.FREE_DELIVERY;
    }

    protected boolean isAmountOrDeliveryType(byte promotionType) {
        return isDeliveryType(promotionType) || isAmountType(promotionType);
    }

    protected boolean isAmountType(byte promotionType) {
        return promotionType == OrderConstants.OrderItemType.PAID_AMOUNT || promotionType == OrderConstants.OrderItemType.THIRD_SUBSIDY_AMOUNT
                || promotionType == OrderConstants.OrderItemType.YUM_SUBSIDY_AMOUNT;

    }


    protected boolean existConflictRule(OrderEvent order) {
        if(getRuleCondition().getConflictPromotionMap()!=null && getRuleCondition().getConflictPromotionMap().size()>0){
            List<String> promotionCodeList = getRuleCondition().getConflictPromotionMap().get(getPromotionCode());
            if(CollectionUtils.isNotEmpty(promotionCodeList)){
                for(String code : promotionCodeList){
                    for(IOrderItem item : order.getItems()){
                        if(code.equalsIgnoreCase(item.getPromotionCode())){
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    //订单满减
    protected boolean existAmountTypeRuleId(OrderEvent order , int matchCount) throws RuleException {
        boolean flag = false;
        //满减金额总和
        long discount = 0;
        if(CollectionUtils.isNotEmpty(order.getItems())){
            for(IOrderItem item : order.getItems()){
                //整单减的时候
                if(getRuleCondition().getTotalDiscount()!=null){
                    if(StringUtils.isNotBlank(item.getPromotionCode()) && item.getPromotionCode().equalsIgnoreCase(getPromotionCode()) && OrderConstants.OrderItemType.FIXED_PROMOTION == item.getType()){
                        flag = true;
                        discount += item.getQuantity() * item.getPrice();
                    }
                }
            }
        }
        //任意次数
        if(matchCount == 999){
            return flag && Math.abs(discount)>0;
        }
        return flag && Math.abs(discount) == (getRuleCondition().getTotalDiscount() * matchCount);
    }

    //存在6/7/8的订单项满减次数和code逻辑
    protected boolean existAmountTypeDiscountRuleId(OrderEvent order , int matchCount) {
        boolean flag = false;
        long discount = 0;
        if(CollectionUtils.isNotEmpty(order.getItems())){
            for(IOrderItem item : order.getItems()){
                if(StringUtils.isNotBlank(item.getPromotionCode()) && item.getPromotionCode().equalsIgnoreCase(getRuleCondition().getPromotionCode())){
                    flag = true;
                    discount += item.getQuantity() * item.getPrice();
                }
            }
        }
        return flag && discount == (calculateDisCountAllValue(order,this.getRuleCondition()) * matchCount);
    }

    protected long calculateDisCountAllValue(OrderEvent order,RuleCondition ruleCondition){
        long sum = 0;
        for (IOrderItem orderItem : order.getItems()) {
            if (orderItem.getType() == OrderConstants.OrderItemType.DELIVERY || orderItem.getType() == OrderConstants.OrderItemType.FREE_DELIVERY
                    || orderItem.getType() == OrderConstants.OrderItemType.PAID_AMOUNT || orderItem.getType() == OrderConstants.OrderItemType.THIRD_SUBSIDY_AMOUNT
                    || orderItem.getType() == OrderConstants.OrderItemType.YUM_SUBSIDY_AMOUNT
                    || orderItem.getType() == OrderConstants.OrderItemType.PERCENT_PROMOTION
                    || orderItem.getType() == OrderConstants.OrderItemType.FIXED_PROMOTION || orderItem.getType() == OrderConstants.OrderItemType.PRIME_CARD) {
                continue;
            }
            sum += orderItem.getRealPrice() * orderItem.getQuantity();
        }
        sum = 0 - (sum - sum * ruleCondition.getTotalPercent());
        return sum;
    }

    //存在外送费减免项
    protected boolean existDeliveryFree(OrderEvent order) {
        if(CollectionUtils.isNotEmpty(order.getItems())){
            for(IOrderItem item : order.getItems()){
                byte promotionType = item.getType();
                if(promotionType == OrderConstants.OrderItemType.FREE_DELIVERY){
                    if(StringUtils.isNotBlank(item.getPromotionCode()) && item.getPromotionCode().equalsIgnoreCase(getPromotionCode())){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * @param order 当前订单
     * @return a产品匹配的数量
     */
    public int matchedCount(OrderEvent order,RuleCondition ruleCondition) {
        // 未设置A产品组
        if (CollectionUtils.isEmpty(ruleCondition.getaProduct())) {
            return 0;
        }
        int aNum = ruleCondition.getaCount();
        int count = aNum;
        if (ruleCondition.isMultiUse()) {
            int ret = 0;
            // 若 aNum 为 0 count 也为0 则 while 成为死循环
            if (0 == aNum) {
                return ret;
            }
            for (String linkedId : ruleCondition.getaProduct()) {
                count = consume(order, count,linkedId);
                while (count <= 0) {
                    ret++;
                    count += aNum;
                }
            }
            return ret;
        } else {
            int ret = 0;
            for (String  linkedId : ruleCondition.getaProduct()) {
                count = consume(order, count,linkedId);
                if (count <= 0) {
                    ret++;
                    count += aNum;
                }
            }
            return ret>0?1:0;
        }
    }

    public int consume(OrderEvent order, int count,String linkedId) {
        List<IOrderItem> items = order.getItems();
        for (IOrderItem item : items) {
            if (item.getType() == OrderConstants.OrderItemType.NO_PROMOTION ) {
                if (linkedId.equals(item.getLinkId())) { // 产品id一致
                    count = count - item.getQuantity();
                }
            }
        }
        return count;
    }

    protected int existAmountTypeRuleId(OrderEvent order) throws RuleException {
        long discount = 0;
        if(CollectionUtils.isNotEmpty(order.getItems())){
            for(IOrderItem item : order.getItems()){
                if(OrderConstants.OrderItemType.FIXED_PROMOTION == item.getType()){
                    if(StringUtils.isNotBlank(item.getPromotionCode()) && item.getPromotionCode().equalsIgnoreCase(getPromotionCode())){
                        discount += item.getQuantity() * item.getPrice();
                    }
                }
            }
        }
        discount = Math.abs(discount);
        if(discount > 0 && discount % (getRuleCondition().getTotalDiscount()) == 0){
            return (int)(discount / (getRuleCondition().getTotalDiscount()));
        }
        return 0;
    }

    protected int findPromotionCodeInOrder(OrderEvent order) throws RuleException {
        int discount = 0;
        if(CollectionUtils.isNotEmpty(order.getItems())){
            for(IOrderItem item : order.getItems()){
                if(OrderConstants.OrderItemType.PRODUCT_PROMOTION == item.getType()){
                    if(StringUtils.isNotBlank(item.getPromotionCode()) && item.getPromotionCode().equalsIgnoreCase(getRuleCondition().getPromotionCode())){
                        if(getRuleCondition().getaProduct().contains(String.valueOf(item.getLinkId()))){
                            discount += item.getQuantity() ;
                        }else{
                            throw new RuleException(-1,"");
                        }

                    }
                }
            }
        }
        return discount;
    }

}
