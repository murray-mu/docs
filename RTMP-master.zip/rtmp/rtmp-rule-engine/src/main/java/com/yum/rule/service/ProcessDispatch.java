package com.yum.rule.service;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.Rule;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleRes;
import com.yum.rule.engine.BaseRule;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

/**
 * 规则校验程序入口 传入2个参数 分别是rule的json字符串， 和订单对象
 * @author yangpeng
 */
public class ProcessDispatch {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String PACKAGE_PATH = "com.yum.rule.engine.Rule";

    private static ThreadPoolExecutor poolExecutor;

    private ThreadPoolExecutor getPoolExecutor(){
        if(poolExecutor==null){
            poolExecutor = new ThreadPoolExecutor(
                    25, 50, 10, TimeUnit.SECONDS,
                    new ArrayBlockingQueue<Runnable>(500),
                    new ThreadPoolExecutor.AbortPolicy());
        }
        return poolExecutor;
    }

    /**
     *
     * @param ruleData 传入的规则数据，是多个规则的map
     * @param order 要校验的订单
     * @return 校验结果数据
     */
    public List<RuleRes> execute(String ruleData,OrderEvent order){
        List<Rule> rulesList=JSONObject.parseObject(ruleData,new TypeReference<List<Rule>>(){});
        List<Rule> finalRes = new ArrayList<>();
        ThreadPoolExecutor poolExecutor = getPoolExecutor();
        Future<List<RuleRes>> result = null;
        if(rulesList!=null && rulesList.size()>0){
            RuleCondition condition18 = getRuleCondition18FromRulesList(rulesList);
            rulesList.stream().forEach(rule-> {
                if(rule!=null){
                    rule.getRuleCondition().setConflictPromotionMap(condition18==null?null:condition18.getConflictPromotionMap());
                }
            });
            if(CollectionUtils.isNotEmpty(finalRes)){
                result = poolExecutor.submit(
                        new Callable<List<RuleRes>>() {
                            @Override
                            public List<RuleRes> call() throws Exception {
                               return executeOneRule(finalRes,order);
                            }
                        }
                );
                if(result != null){
                    try{
                        return result.get();
                    }catch ( Exception e){
                        e.printStackTrace();
                    }
                }
                return executeOneRule(finalRes,order);
            }
        }
        return null;
    }

    private static RuleCondition getRuleCondition18FromRulesList(List<Rule> rulesList) {
        RuleCondition ruleCondition18 = null;
        for(Rule rule : rulesList){
            if(rule!=null && 18==rule.getRuleId()){
                ruleCondition18 = rule.getRuleCondition();
                break;
            }
        }
        return ruleCondition18;
    }

    private List<RuleRes> executeOneRule(List<Rule> rules, OrderEvent order){
        List<RuleRes> result = new ArrayList<>();
        try {
            if(CollectionUtils.isNotEmpty(rules)){
                 rules.stream().forEach(rule -> {
                    RuleRes res = null;
                    RuleCondition ruleCondition = rule.getRuleCondition();
                    int ruleId = rule.getRuleId();
                    Class baseConditionClass = ruleCondition.getClass();
                    Class<?> classRule = null;
                    try {
                        classRule = Class.forName(PACKAGE_PATH + ruleId);
                        Constructor<?> cons = classRule.getConstructor(baseConditionClass);
                        BaseRule baseRule = (BaseRule) cons.newInstance(ruleCondition);
                        res = baseRule.execute(order);
                        result.add(res);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        }catch ( Exception e){
            logger.error("failed to execute rule",e);
        }
        return result;
    }




}
