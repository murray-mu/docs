package com.yum.rule.engine;

import com.yum.common.constant.OrderConstants;
import com.yum.common.model.IOrderItem;
import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.core.runtime.Assert;

//买X份A产品，以优惠价XX元购买Y份B产品
public class Rule1 extends BaseRule {

    public Rule1(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    @Override
    public void CheckRule() {
        super.CheckRule();
        Assert.isTrue(getRuleCondition().getaCount()!=null,getDesc()+" X没有初始化");
        Assert.isTrue(CollectionUtils.isNotEmpty(getRuleCondition().getaProduct()),getDesc()+" A产品列表为空");
        Assert.isTrue(getRuleCondition().getbCount()!=null,getDesc()+ " Y未初始化");
        Assert.isTrue(CollectionUtils.isNotEmpty(getRuleCondition().getbProduct()),getDesc()+ " B产品列表为空");
        Assert.isTrue(getRuleCondition().getcValue()!=null,getDesc()+ " XX元没有初始化");
    }

    @Override
    String getDesc() {
        return "买X份A产品，以优惠价XX元购买Y份B产品";
    }

    @Override
    int getRuleId() {
        return 1;
    }

    /**
     * 买了X份A产品，没有以优惠价XX元购买Y份B产品
     * @param order
     * @return
     */
    @Override
    public void matchAFlag(OrderEvent order) throws RuleException {
        //订单存在互斥的优惠 执行成功
        if(existConflictRule(order)){
            return ;
        }
        //订单供多少个符合标准的产品
        int matchedCount = matchedCount(order,getRuleCondition());
        if(matchedCount > 0){
            if(!existAmountTypeRuleId(order,matchedCount)){
                //应享受未享受统一 都是 -2
                throw new RuleException(-2);
            }
        }
    }

    /**
     * 享受了这个优惠（订单里面有相关优惠code），但是没有买X份A产品
     * @param order
     * @return
     */
    @Override
    public void matchBFlag(OrderEvent order) throws RuleException {
        //订单存在与这个优惠互斥的优惠的话 这个就不需要执行了
        if(existConflictRule(order)){
            return;
        }
        int matchCount = existAmountTypeRuleId(order);
        if(matchCount > 0){
            //订单供多少个符合标准的产品
            int matchedCount = matchedCount(order,getRuleCondition());
            if(matchedCount < matchCount) {
                //多享受 都是 -3
                throw new RuleException(-3);
            }
        }
    }

    //xx元买x粉B产品
    @Override
    protected boolean existAmountTypeRuleId(OrderEvent order , int matchCount) throws RuleException {
        boolean flag = false;
        //折扣金额/或者折扣率
        long discount = 0;
        //折扣产品数量
        int count = 0;
        if(CollectionUtils.isNotEmpty(order.getItems())){
            for(IOrderItem item : order.getItems()){
                //xx元买x粉B产品
                if(getRuleCondition().getcValue()!=null && getRuleCondition().getbCount() !=null && CollectionUtils.isNotEmpty(getRuleCondition().getbProduct())){
                    if(StringUtils.isNotBlank(item.getPromotionCode()) && item.getPromotionCode().equalsIgnoreCase(getRuleCondition().getPromotionCode()) && OrderConstants.OrderItemType.PRODUCT_PROMOTION == item.getType() ){
                        if(getRuleCondition().getbProduct().contains(String.valueOf(item.getLinkId()))){
                            flag = true;
                            count += item.getQuantity();
                            discount += item.getQuantity() * item.getPrice();
                        }else{
                            throw new RuleException(-1,"存在非B产品集产品运行该规则");
                        }
                    }
                }
            }
        }
        if(!flag){
            throw new RuleException(-1,"订单中不存在优惠产品");
        }
        if(Math.abs(discount) != (getRuleCondition().getcValue() * matchCount)){
            throw new RuleException(-1,"订单已优惠金额和应优惠金额不一致");
        }
        if(count != getRuleCondition().getbCount() * matchCount){
            throw new RuleException(-1,"优惠产品数量和应优惠数量不一致");
        }
        return true;
    }

    @Override
    protected int existAmountTypeRuleId(OrderEvent order) throws RuleException {
        long discount = 0;
        int count = 0;
        int matchCount = 0;
        if(CollectionUtils.isNotEmpty(order.getItems())){
            for(IOrderItem item : order.getItems()){
                if(OrderConstants.OrderItemType.PRODUCT_PROMOTION == item.getType()){
                    if(StringUtils.isNotBlank(item.getPromotionCode()) && item.getPromotionCode().equalsIgnoreCase(getPromotionCode()) ){
                        if(getRuleCondition().getbProduct().contains(String.valueOf(item.getLinkId()))){
                            discount += item.getQuantity() * item.getPrice();
                            count += item.getQuantity();
                        }else{
                            throw new RuleException(-1,"存在非B产品集产品运行该规则");
                        }
                    }
                }
            }
        }
        if(count % getRuleCondition().getbCount() !=0){
            throw new RuleException(-1,"优惠产品数量不是"+getRuleCondition().getbCount()+"的整数倍");
        }else{
            matchCount = count / getRuleCondition().getbCount();
        }
        //由于存在四舍五入的情况 所以
        discount = Math.abs(discount);
        if(discount >= 0 || discount == getRuleCondition().getcValue() * matchCount  ){
            return matchCount;
        }else{
            throw new RuleException(-1,"优惠产品总金额"+discount+"和应该优惠的金额"+getRuleCondition().getcValue() * matchCount+"不一致");
        }
    }

}
