package com.yum.rule.engine;

import com.yum.common.model.IOrderItem;
import com.yum.common.model.OrderEvent;
import com.yum.common.model.rule.BaseCondition;
import com.yum.common.model.rule.RuleCondition;
import com.yum.common.model.rule.RuleException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.core.runtime.Assert;

//买X分A 整单减B
public class Rule3 extends BaseRule{

    public Rule3(RuleCondition ruleCondition) {
        super(ruleCondition);
    }

    //初始化后校验
    @Override
    public void CheckRule() {
        super.CheckRule();
        Assert.isTrue(getRuleCondition().getaCount()!=null,getDesc()+" X没有初始化");
        Assert.isTrue(CollectionUtils.isNotEmpty(getRuleCondition().getaProduct()),getDesc()+" A产品列表为空");
        Assert.isTrue(getRuleCondition().getTotalDiscount()!=null,getDesc()+ " B元没有初始化");
    }

    @Override
    String getDesc() {
        return "买X分A 整单减B";
    }

    @Override
    int getRuleId() {
        return 3;
    }

    /**
         * 买了X份A产品，没有整单减金额
         * @param order
         * @return
         */
        @Override
        public void matchAFlag(OrderEvent order) throws RuleException {
            //订单存在互斥的优惠 执行成功
            if(existConflictRule(order)){
                return ;
            }
            //订单供多少个符合标准的产品
            int matchedCount = matchedCount(order,getRuleCondition());
            if(matchedCount > 0){
                if(!existAmountTypeRuleId(order,matchedCount)){
                    throw new RuleException(-2);
                }
            }
        }

        /**
         * 享受了这个优惠（订单里面有相关优惠code），但是没有买X份A产品
         * @param order
         * @return
         */
        @Override
        public void matchBFlag(OrderEvent order) throws RuleException{
            //订单存在与这个优惠互斥的优惠的话 这个就不需要执行了
            if(existConflictRule(order)){
                return;
            }
            int matchCount = existAmountTypeRuleId(order);
            if(matchCount > 0){
                //订单供多少个符合标准的产品
                int matchedCount = matchedCount(order,getRuleCondition());
                if(matchedCount < matchCount){
                    throw new RuleException(-3);
                }
            }
    }

    @Override
    public int existAmountTypeRuleId(OrderEvent order){
        long discount = 0;
        if(CollectionUtils.isNotEmpty(order.getItems())){
            for(IOrderItem item : order.getItems()){
                if(StringUtils.isNotBlank(item.getPromotionCode()) && item.getPromotionCode().equalsIgnoreCase(getRuleCondition().getPromotionCode())){
                    discount += item.getQuantity() * item.getPrice();
                }
            }
        }
        if(discount>0 || discount % (getRuleCondition().getTotalDiscount()) == 0){
            return (int)(discount / (getRuleCondition().getTotalDiscount()));
        }
        return 0;
    }
}
