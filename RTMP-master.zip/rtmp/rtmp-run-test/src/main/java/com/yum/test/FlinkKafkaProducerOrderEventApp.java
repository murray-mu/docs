package com.yum.test;

import com.yum.common.model.OrderEvent;
import com.yum.common.utils.ExecutionEnvUtil;
import com.yum.common.utils.GsonUtil;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TimeZone;

/**
 * Desc: Flink 发送数据到 topic
 */
public class FlinkKafkaProducerOrderEventApp {

    public static final Random random = new Random();

    public static void main(String[] args) throws Exception {
        final ParameterTool parameterTool = ExecutionEnvUtil.createParameterTool(args);
        StreamExecutionEnvironment env = ExecutionEnvUtil.prepare(parameterTool);
        env.setParallelism(1);
        env.addSource(new SourceFunction<String>() {
            @Override
            public void run(SourceContext<String> context) throws Exception {

                while (true) {
                    TimeZone tz = TimeZone.getTimeZone("Asia/Shanghai");
                    Instant instant = Instant.ofEpochMilli(System.currentTimeMillis() + tz.getOffset(System.currentTimeMillis()));

//                    String outline = String.format(
//                            "{\"user_id\": \"%s\", \"item_id\":\"%s\", \"category_id\": \"%s\", \"behavior\": \"%s\", \"ts\": \"%s\"}",
//                            random.nextInt(10),
//                            random.nextInt(100),
//                            random.nextInt(1000),
//                            "pv",
//                            instant.toString());

                    Map<String, String> tags = new HashMap<>();
                    tags.put("type","" + (1 + random.nextInt(3)));
                    tags.put("target_id","" + (100 + random.nextInt(4)));
                    OrderEvent order=null;
//                    OrderEvent order = OrderEvent.builder()
//                            .id((long) instant.toEpochMilli())  //商品的 id
//                            .payStatus(101)
//                            .shopName("product" + random.nextInt(10))  //商品 name
//                            .payAmount(random.nextLong() / 10000000000000L) //商品价格（以分为单位）
//                            .buyerName("name"+random.nextInt(1000))
//                            .deliveryStatus(random.nextInt(10))
//                            .receiveStatus(random.nextInt(10))
//                            .timestamp(System.currentTimeMillis())
//                            .reverseStatus(1)
//                            .buyerId((long)random.nextInt(10))
//                            .coupon(random.nextInt(2))
//                            .tags(tags)
//                            .shopId("id"+ random.nextInt(1000)).build();

                    System.out.println("发送数据: " + GsonUtil.toJson(order));
                    String orderData = GsonUtil.toJson(order);
                    String data = "{" +
                            "\"address2\": \"177\"," +
                            "\"bigOrder\": false," +
                            "\"booking\": false," +
                            "\"bookingDate\": null," +
                            "\"bookingType\": 0," +
                            "\"brand\": \"KFC_D\"," +
                            "\"channelId\": \"71\"," +
                            "\"channelName\": \"MWOS_SUPERAPPRN\"," +
                            "\"cityCode\": \"00008\"," +
                            "\"cityName\": \"南京\"," +
                            "\"compris\": true," +
                            "\"coordinate_x\": \"118.741065\"," +
                            "\"coordinate_y\": \"32.057006\"," +
                            "\"deliverTimeOfMap\": 40," +
                            "\"deliveryTime\": 75," +
                            "\"dinnerwareComment\": null," +
                            "\"distance\": 0," +
                            "\"donation\": 0," +
                            "\"houseNumber\": 9999," +
                            "\"iLinkMan\": \"杨帆\"," +
                            "\"iRemark\": \"要餐具。\"," +
                            "\"iTransType\": 2," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"invoiceTitle\": \"\"," +
                            "\"items\": [" +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 0," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": null," +
                            "\"itemDept\": null," +
                            "\"itemGroup\": null," +
                            "\"itemType\": 0," +
                            "\"items\": []," +
                            "\"linkId\": 999901404," +
                            "\"mealDealId\": null," +
                            "\"mealId\": null," +
                            "\"menuId\": \"0\"," +
                            "\"nameCn\": \"外送服务费\"," +
                            "\"nameEn\": \"外送服务费\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"1404\"," +
                            "\"price\": 900," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 0," +
                            "\"promotionCode\": null," +
                            "\"promotionId\": -1," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 1," +
                            "\"realPrice\": 900," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 4" +
                            "}," +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": 0," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 1," +
                            "\"financialClass\": 0," +
                            "\"financialDept\": 0," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": \"604_581568.jpg\"," +
                            "\"itemDept\": 24," +
                            "\"itemGroup\": 2," +
                            "\"itemType\": 0," +
                            "\"items\": [" +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 1," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": \"604_580893.jpg\"," +
                            "\"itemDept\": 10," +
                            "\"itemGroup\": 20001," +
                            "\"itemType\": 11," +
                            "\"items\": []," +
                            "\"linkId\": 100012812," +
                            "\"mealDealId\": null," +
                            "\"mealId\": \"279f99a9-97c0-40b4-a1e7-33150c5023a2\"," +
                            "\"menuId\": null," +
                            "\"nameCn\": \"C新奥尔良烤鸡腿堡S\"," +
                            "\"nameEn\": \"\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"6369\"," +
                            "\"price\": 0," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 0," +
                            "\"promotionCode\": null," +
                            "\"promotionId\": -1," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 1," +
                            "\"realPrice\": 0," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 0" +
                            "}," +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 1," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": \"604_585918.jpg\"," +
                            "\"itemDept\": 10," +
                            "\"itemGroup\": 20002," +
                            "\"itemType\": 11," +
                            "\"items\": []," +
                            "\"linkId\": 26648," +
                            "\"mealDealId\": null," +
                            "\"mealId\": \"279f99a9-97c0-40b4-a1e7-33150c5023a2\"," +
                            "\"menuId\": null," +
                            "\"nameCn\": \"C二块香辣鸡翅\"," +
                            "\"nameEn\": \"\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"6220\"," +
                            "\"price\": 0," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 0," +
                            "\"promotionCode\": null," +
                            "\"promotionId\": -1," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 1," +
                            "\"realPrice\": 0," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 0" +
                            "}," +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 1," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": \"618_623590.jpg\"," +
                            "\"itemDept\": 24," +
                            "\"itemGroup\": 20003," +
                            "\"itemType\": 11," +
                            "\"items\": [" +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 1," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": \"\"," +
                            "\"itemDept\": 0," +
                            "\"itemGroup\": 2000301," +
                            "\"itemType\": 12," +
                            "\"items\": []," +
                            "\"linkId\": 181891," +
                            "\"mealDealId\": null," +
                            "\"mealId\": \"c3332550-d646-4fc1-bf6a-80b4cc8229d9\"," +
                            "\"menuId\": null," +
                            "\"nameCn\": \"加肉\"," +
                            "\"nameEn\": \"Hazelnut Latte\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"24389\"," +
                            "\"price\": 0," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 0," +
                            "\"promotionCode\": null," +
                            "\"promotionId\": -1," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 1," +
                            "\"realPrice\": 0," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 0" +
                            "}," +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 1," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": \"\"," +
                            "\"itemDept\": 0," +
                            "\"itemGroup\": 2000302," +
                            "\"itemType\": 12," +
                            "\"items\": []," +
                            "\"linkId\": 181892," +
                            "\"mealDealId\": null," +
                            "\"mealId\": \"c3332550-d646-4fc1-bf6a-80b4cc8229d9\"," +
                            "\"menuId\": null," +
                            "\"nameCn\": \"加玉米\"," +
                            "\"nameEn\": \"Hazelnut Latte\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"24390\"," +
                            "\"price\": 0," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 0," +
                            "\"promotionCode\": null," +
                            "\"promotionId\": -1," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 1," +
                            "\"realPrice\": 0," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 0" +
                            "}" +
                            "]," +
                            "\"linkId\": 100024013," +
                            "\"mealDealId\": null," +
                            "\"mealId\": \"279f99a9-97c0-40b4-a1e7-33150c5023a2\"," +
                            "\"menuId\": null," +
                            "\"nameCn\": \"DN夜皮蛋瘦肉粥\"," +
                            "\"nameEn\": \"\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"66733\"," +
                            "\"price\": 950," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 0," +
                            "\"promotionCode\": null," +
                            "\"promotionId\": -1," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 1," +
                            "\"realPrice\": 950," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 0" +
                            "}," +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 1," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": \"618_623590.jpg\"," +
                            "\"itemDept\": 24," +
                            "\"itemGroup\": 20003," +
                            "\"itemType\": 11," +
                            "\"items\": [" +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 1," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": \"\"," +
                            "\"itemDept\": 0," +
                            "\"itemGroup\": 2000301," +
                            "\"itemType\": 12," +
                            "\"items\": []," +
                            "\"linkId\": 181890," +
                            "\"mealDealId\": null," +
                            "\"mealId\": \"60b52346-4b08-48c4-86eb-c8b2a79bf4a4\"," +
                            "\"menuId\": null," +
                            "\"nameCn\": \"加火腿\"," +
                            "\"nameEn\": \"Hazelnut Latte\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"24388\"," +
                            "\"price\": 0," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 0," +
                            "\"promotionCode\": null," +
                            "\"promotionId\": -1," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 1," +
                            "\"realPrice\": 0," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 0" +
                            "}," +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 1," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": \"\"," +
                            "\"itemDept\": 0," +
                            "\"itemGroup\": 2000302," +
                            "\"itemType\": 12," +
                            "\"items\": []," +
                            "\"linkId\": 181893," +
                            "\"mealDealId\": null," +
                            "\"mealId\": \"60b52346-4b08-48c4-86eb-c8b2a79bf4a4\"," +
                            "\"menuId\": null," +
                            "\"nameCn\": \"加香肠\"," +
                            "\"nameEn\": \"Hazelnut Latte\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"24391\"," +
                            "\"price\": 0," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 0," +
                            "\"promotionCode\": null," +
                            "\"promotionId\": -1," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 1," +
                            "\"realPrice\": 0," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 0" +
                            "}" +
                            "]," +
                            "\"linkId\": 100024013," +
                            "\"mealDealId\": null," +
                            "\"mealId\": \"279f99a9-97c0-40b4-a1e7-33150c5023a2\"," +
                            "\"menuId\": null," +
                            "\"nameCn\": \"DN夜皮蛋瘦肉粥\"," +
                            "\"nameEn\": \"\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"66733\"," +
                            "\"price\": 950," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 0," +
                            "\"promotionCode\": null," +
                            "\"promotionId\": -1," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 1," +
                            "\"realPrice\": 950," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 0" +
                            "}" +
                            "]," +
                            "\"linkId\": 100015854," +
                            "\"mealDealId\": null," +
                            "\"mealId\": null," +
                            "\"menuId\": \"0\"," +
                            "\"nameCn\": \"DN奥良鸡腿堡辣翅粥S\"," +
                            "\"nameEn\": \"\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"58478\"," +
                            "\"price\": 4650," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 1900," +
                            "\"promotionCode\": null," +
                            "\"promotionId\": -1," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 1," +
                            "\"realPrice\": 4650," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 0" +
                            "}," +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 0," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": null," +
                            "\"itemDept\": null," +
                            "\"itemGroup\": null," +
                            "\"itemType\": 0," +
                            "\"items\": []," +
                            "\"linkId\": null," +
                            "\"mealDealId\": null," +
                            "\"mealId\": null," +
                            "\"menuId\": null," +
                            "\"nameCn\": \"支付宝\"," +
                            "\"nameEn\": \"APINJG1771597400601099173005\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"10002\"," +
                            "\"price\": 5650," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 0," +
                            "\"promotionCode\": null," +
                            "\"promotionId\": -1," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 1," +
                            "\"realPrice\": 5650," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 6" +
                            "}," +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": \"0\"," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 1," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": null," +
                            "\"itemDept\": 0," +
                            "\"itemGroup\": 3," +
                            "\"itemType\": 1," +
                            "\"items\": [" +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 1," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": null," +
                            "\"itemDept\": null," +
                            "\"itemGroup\": 302," +
                            "\"itemType\": 2," +
                            "\"items\": []," +
                            "\"linkId\": 26648," +
                            "\"mealDealId\": null," +
                            "\"mealId\": \"3a6af73b-ce20-49fd-8030-873fc97b0226\"," +
                            "\"menuId\": \"0\"," +
                            "\"nameCn\": \"C二块香辣鸡翅\"," +
                            "\"nameEn\": \"\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"6220\"," +
                            "\"price\": 0," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 0," +
                            "\"promotionCode\": \"ZCJSQY5X5\"," +
                            "\"promotionId\": 21373," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 5," +
                            "\"realPrice\": 0," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 1" +
                            "}," +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 1," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": null," +
                            "\"itemDept\": null," +
                            "\"itemGroup\": 303," +
                            "\"itemType\": 2," +
                            "\"items\": []," +
                            "\"linkId\": 26649," +
                            "\"mealDealId\": null," +
                            "\"mealId\": \"3a6af73b-ce20-49fd-8030-873fc97b0226\"," +
                            "\"menuId\": \"0\"," +
                            "\"nameCn\": \"C二块新奥尔良烤翅\"," +
                            "\"nameEn\": \"\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"6221\"," +
                            "\"price\": 0," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 0," +
                            "\"promotionCode\": \"ZCJSQY5X5\"," +
                            "\"promotionId\": 21373," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 3," +
                            "\"realPrice\": 0," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 1" +
                            "}," +
                            "{" +
                            "\"activityTag\": null," +
                            "\"activityType\": null," +
                            "\"altDesc\": null," +
                            "\"barrelId\": null," +
                            "\"baseId\": null," +
                            "\"baseName\": null," +
                            "\"baseNameEn\": null," +
                            "\"cclassid\": null," +
                            "\"cdSysId\": null," +
                            "\"classId\": null," +
                            "\"couponCode\": null," +
                            "\"eGiftCardPaymentSupport\": 1," +
                            "\"financialClass\": null," +
                            "\"financialDept\": null," +
                            "\"id\": \"1597400562869173017\"," +
                            "\"imageName\": null," +
                            "\"itemDept\": null," +
                            "\"itemGroup\": 304," +
                            "\"itemType\": 2," +
                            "\"items\": []," +
                            "\"linkId\": 100015769," +
                            "\"mealDealId\": null," +
                            "\"mealId\": \"3a6af73b-ce20-49fd-8030-873fc97b0226\"," +
                            "\"menuId\": \"0\"," +
                            "\"nameCn\": \"C百威啤酒\"," +
                            "\"nameEn\": \"\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"37581\"," +
                            "\"price\": 0," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 0," +
                            "\"promotionCode\": \"ZCJSQY5X5\"," +
                            "\"promotionId\": 21373," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 4," +
                            "\"realPrice\": 0," +
                            "\"ruleId\": null," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 1" +
                            "}" +
                            "]," +
                            "\"linkId\": 100021743," +
                            "\"mealDealId\": null," +
                            "\"mealId\": null," +
                            "\"menuId\": \"0\"," +
                            "\"nameCn\": \"十六翅啤酒超级餐\"," +
                            "\"nameEn\": \"\"," +
                            "\"orderId\": \"1597400562869173017\"," +
                            "\"owner\": null," +
                            "\"pmId\": \"64378\"," +
                            "\"price\": 1100," +
                            "\"primeCardName\": null," +
                            "\"promotionAmount\": 1000," +
                            "\"promotionCode\": \"ZCJSQY5X5\"," +
                            "\"promotionId\": 21373," +
                            "\"promotionPercent\": 0.0," +
                            "\"quantity\": 1," +
                            "\"realPrice\": 100," +
                            "\"ruleId\": \"64378\"," +
                            "\"sizeId\": null," +
                            "\"sizeName\": null," +
                            "\"sizeNameEn\": null," +
                            "\"type\": 1" +
                            "}" +
                            "]," +
                            "\"loginPhone\": \"17754047759\"," +
                            "\"marketCode\": \"009\"," +
                            "\"needInvoice\": false," +
                            "\"numberOfItems\": 2," +
                            "\"openId\": null," +
                            "\"orderDate\": 1597400615869," +
                            "\"orderValue\": 5650," +
                            "\"osRemark\": null," +
                            "\"packType\": 0," +
                            "\"payChannel\": \"ALIPAY\"," +
                            "\"phone\": \"17754047759\"," +
                            "\"portalSource\": null," +
                            "\"promiseTime\": 1597405115869," +
                            "\"storeCode\": \"NJG177\"," +
                            "\"streetName\": \"草场门大街(鼓楼区)\"," +
                            "\"termType\": 0," +
                            "\"ticketNo\": null," +
                            "\"transactionNo\": \"APINJG1771597400601099173005\"," +
                            "\"userCode\": \"3735247284723684\"," +
                            "\"userId\": \"11e649d2-9e06-432e-a9ac-ac7b7da2227c_9\"," +
                            "\"userLevel\": null," +
                            "\"webId\": \"superapp\"" +
                            "}";
                    System.out.println(data);
                    context.collect(data);
                    Thread.sleep(200);
                }
            }

            @Override
            public void cancel() {

            }
        })
                .addSink(new FlinkKafkaProducer<>(
                        "kafka-host:9092",
                        "rtmp1",
                        new SimpleStringSchema()
                )).name("flink-connectors-kafka").setParallelism(20);

        env.execute("Order flink kafka connector ");
    }
}
