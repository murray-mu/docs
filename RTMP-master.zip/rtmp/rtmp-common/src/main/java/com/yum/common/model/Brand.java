package com.yum.common.model;

public  enum Brand {
    KFC_D;
}
