package com.yum.common.constant;

/**
 * @author Administrator
 */
public interface OrderConstants {


    /**
     * 订单项类型
     */
    public static interface OrderItemType {

        /**
         * 非优惠,订单项
         */
        public static final byte NO_PROMOTION = 0;
        /**
         * 使用优惠产生的产品
         */
        public static final byte PRODUCT_PROMOTION = 1;
        /**
         * 固定金额优惠
         */
        public static final byte FIXED_PROMOTION = 2;
        /**
         * 百分比优惠
         */
        public static final byte PERCENT_PROMOTION = 3;
        /**
         * 外送费
         */
        public static final byte DELIVERY = 4;
        /**
         * 免外送费
         */
        public static final byte FREE_DELIVERY = 5;

        /**
         * 已付金额
         */
        public static final byte PAID_AMOUNT = 6;

        /**
         * 第三方补贴金额
         */
        public static final byte THIRD_SUBSIDY_AMOUNT = 7;

        /**
         * Yum补贴金额
         */
        public static final byte YUM_SUBSIDY_AMOUNT = 8;

        /**
         * 订单标签
         */
        public static final byte ORDER_LABEL = 9;

        /**
         * Prime买卡
         */
        public static final byte PRIME_CARD = 10;

    }
}
