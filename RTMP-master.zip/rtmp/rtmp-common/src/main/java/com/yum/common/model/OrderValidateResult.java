package com.yum.common.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderValidateResult {

	/**
	 * 校验结果id
	 */
	private String id;

	/**
	 * Rule id
	 */
	private int ruleId;

	/**
	 * 校验结果
	 */
	private boolean validateResult;

	/**
	 * 校验结果描述
	 */
	private String validateResultDesc;
	/**
	 * 规则编码
	 */
	private String ruleCode;
	/**
	 * 订单Id
	 */
	private String orderId;
	/**
	 * 用户手机号
	 */
	private String userPhone;
	/**
	 * 取餐手机号
	 */
	private String takeMealPhone;
	/**
	 * 餐厅
	 */
	private String storeCode;
	/**
	 * city
	 */
	private String city;
	/**
	 * market
	 */
	private String market;
	/**
	 * validateTime
	 */
	private Long validateTime;
	/**
	 * order Time
	 */
	private Long orderTime;
	/**
	 * order channel
	 */
	private String orderChannel;
}
