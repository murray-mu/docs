package com.yum.common.model.rule;

import java.io.Serializable;

public class Rule implements Serializable {
    private RuleCondition ruleCondition;
    private int ruleId;

    public RuleCondition getRuleCondition() {
        return ruleCondition;
    }

    public void setRuleCondition(RuleCondition ruleCondition) {
        this.ruleCondition = ruleCondition;
    }

    public int getRuleId() {
        return ruleId;
    }

    public void setRuleId(int ruleId) {
        this.ruleId = ruleId;
    }
}