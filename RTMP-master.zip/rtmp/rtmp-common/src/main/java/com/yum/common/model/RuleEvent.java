package com.yum.common.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RuleEvent {

	/**
	 * Rule name
	 */
	private String name;

	/**
	 * Rule timestamp
	 */
	private Long timestamp;

	/**
	 * Rule fields
	 */
	private Map<String, Object> fields;

	/**
	 * Rule tags
	 */
	private Map<String, String> tags;
}
