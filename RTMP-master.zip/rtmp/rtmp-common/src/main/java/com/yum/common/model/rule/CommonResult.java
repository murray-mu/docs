package com.yum.common.model.rule;

import java.io.Serializable;

/**
 * 规则执行通用结果集
 */
public class CommonResult implements Serializable {
    private static final long serialVersionUID = -1959171312619707734L;

    public CommonResult(){}

    public CommonResult(String ruleDescription,String ruleName,int ruleId,boolean testResult,String failedReason,String promotionCodde){
        this.testResult = testResult;
        this.ruleName = ruleName;
        this.ruleDescription = ruleDescription;
        this.ruleId = ruleId;
        this.failedReason = failedReason;
        this.promtionCode = promotionCodde;
    }
    //规则描述
    public String ruleDescription;

    public String ruleName;
    //规则的ruleId
    public int ruleId;
    //规则执行结果
    public boolean testResult;
    //规则执行失败原因
    private String failedReason;
    //对应的优惠code
    private String promtionCode;

    public String getRuleDescription() {
        return ruleDescription;
    }

    public void setRuleDescription(String ruleDescription) {
        this.ruleDescription = ruleDescription;
    }

    public int getRuleId() {
        return ruleId;
    }

    public void setRuleId(int ruleId) {
        this.ruleId = ruleId;
    }

    public boolean isTestResult() {
        return testResult;
    }

    public void setTestResult(boolean testResult) {
        this.testResult = testResult;
    }

    public String getFailedReason() {
        return failedReason;
    }

    public void setFailedReason(String failedReason) {
        this.failedReason = failedReason;
    }

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public String getPromtionCode() {
        return promtionCode;
    }

    public void setPromtionCode(String promtionCode) {
        this.promtionCode = promtionCode;
    }
}
