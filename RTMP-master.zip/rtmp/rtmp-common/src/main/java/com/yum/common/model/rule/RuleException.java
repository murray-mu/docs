package com.yum.common.model.rule;

public class RuleException extends Exception {
    private String ruleErrorMsg;
    private int ruleErrorCode;

    public RuleException(int code, String errorMsg ){
        super();
        this.ruleErrorCode = code;
        this.ruleErrorMsg = errorMsg;
    }

    public RuleException(int code){
        super();
        this.ruleErrorCode = code;
    }

    public String getRuleErrorMsg() {
        return ruleErrorMsg;
    }

    public void setRuleErrorMsg(String ruleErrorMsg) {
        this.ruleErrorMsg = ruleErrorMsg;
    }

    public int getRuleErrorCode() {
        return ruleErrorCode;
    }

    public void setRuleErrorCode(int ruleErrorCode) {
        this.ruleErrorCode = ruleErrorCode;
    }
}
