package com.yum.common.model.rule;

import java.io.Serializable;

public class RuleRes implements Serializable {

    private static final long serialVersionUID = -7674658665144768238L;

    public RuleRes(CommonResult resultA, CommonResult resultB){
        this.resultA = resultA;
        this.resultB = resultB;
    }

    private CommonResult resultA;
    private CommonResult resultB;

    public CommonResult getResultA() {
        return resultA;
    }

    public void setResultA(CommonResult resultA) {
        this.resultA = resultA;
    }

    public CommonResult getResultB() {
        return resultB;
    }

    public void setResultB(CommonResult resultB) {
        this.resultB = resultB;
    }
}
