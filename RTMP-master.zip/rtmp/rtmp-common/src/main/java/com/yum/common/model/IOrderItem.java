package com.yum.common.model;

import java.util.List;

public class IOrderItem {
    private String classId;//"classId": null,
    private String couponCode;//"couponCode": null,
    private int eGiftCardPaymentSupport;//"eGiftCardPaymentSupport": 0,
    private Integer financialClass;
    private Integer financialDept;
    private String id;
    private String imageName;
    private Integer itemDept;
    private Integer itemGroup;
    private Integer itemType;
    private List<IOrderItem> items;
    private Integer linkId;
    private String mealId;
    private String menuId;
    private String nameCn;
    private String nameEn;
    private String orderId;
    private String owner;
    private String pmId;
    private long price;
    private String primeCardName;
    private int promotionAmount;
    private String promotionCode;
    private long promotionId;
    private double promotionPercent;
    private int quantity;
    private long realPrice;
    private byte type;

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public List<IOrderItem> getItems() {
        return items;
    }

    public void setItems(List<IOrderItem> items) {
        this.items = items;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public int geteGiftCardPaymentSupport() {
        return eGiftCardPaymentSupport;
    }

    public void seteGiftCardPaymentSupport(int eGiftCardPaymentSupport) {
        this.eGiftCardPaymentSupport = eGiftCardPaymentSupport;
    }

    public Integer getFinancialClass() {
        return financialClass;
    }

    public void setFinancialClass(Integer financialClass) {
        this.financialClass = financialClass;
    }

    public Integer getFinancialDept() {
        return financialDept;
    }

    public void setFinancialDept(Integer financialDept) {
        this.financialDept = financialDept;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public Integer getItemDept() {
        return itemDept;
    }

    public void setItemDept(Integer itemDept) {
        this.itemDept = itemDept;
    }

    public Integer getItemGroup() {
        return itemGroup;
    }

    public void setItemGroup(Integer itemGroup) {
        this.itemGroup = itemGroup;
    }

    public Integer getItemType() {
        return itemType;
    }

    public void setItemType(Integer itemType) {
        this.itemType = itemType;
    }



    public Integer getLinkId() {
        return linkId;
    }

    public void setLinkId(Integer linkId) {
        this.linkId = linkId;
    }

    public String getMealId() {
        return mealId;
    }

    public void setMealId(String mealId) {
        this.mealId = mealId;
    }

    public String getMenuId() {
        return menuId;
    }

    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    public String getNameCn() {
        return nameCn;
    }

    public void setNameCn(String nameCn) {
        this.nameCn = nameCn;
    }

    public String getNameEn() {
        return nameEn;
    }

    public void setNameEn(String nameEn) {
        this.nameEn = nameEn;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getPmId() {
        return pmId;
    }

    public void setPmId(String pmId) {
        this.pmId = pmId;
    }

    public long getPrice() {
        return price;
    }

    public void setPrice(long price) {
        this.price = price;
    }

    public String getPrimeCardName() {
        return primeCardName;
    }

    public void setPrimeCardName(String primeCardName) {
        this.primeCardName = primeCardName;
    }

    public int getPromotionAmount() {
        return promotionAmount;
    }

    public void setPromotionAmount(int promotionAmount) {
        this.promotionAmount = promotionAmount;
    }

    public String getPromotionCode() {
        return promotionCode;
    }

    public void setPromotionCode(String promotionCode) {
        this.promotionCode = promotionCode;
    }

    public long getPromotionId() {
        return promotionId;
    }

    public void setPromotionId(long promotionId) {
        this.promotionId = promotionId;
    }

    public double getPromotionPercent() {
        return promotionPercent;
    }

    public void setPromotionPercent(double promotionPercent) {
        this.promotionPercent = promotionPercent;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public long getRealPrice() {
        return realPrice;
    }

    public void setRealPrice(long realPrice) {
        this.realPrice = realPrice;
    }

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }
}
