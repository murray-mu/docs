package com.yum.common.schemas;

import com.google.gson.Gson;
import com.yum.common.model.RuleEvent;
import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.common.serialization.SerializationSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;

import java.io.IOException;
import java.nio.charset.Charset;

/**
 * Rule Schema ，支持序列化和反序列化
 */
public class RuleSchema implements DeserializationSchema<RuleEvent>, SerializationSchema<RuleEvent> {

    private static final Gson gson = new Gson();

    @Override
    public RuleEvent deserialize(byte[] bytes) throws IOException {
        return gson.fromJson(new String(bytes), RuleEvent.class);
    }

    @Override
    public boolean isEndOfStream(RuleEvent ruleEvent) {
        return false;
    }

    @Override
    public byte[] serialize(RuleEvent ruleEvent) {
        return gson.toJson(ruleEvent).getBytes(Charset.forName("UTF-8"));
    }

    @Override
    public TypeInformation<RuleEvent> getProducedType() {
        return TypeInformation.of(RuleEvent.class);
    }
}
