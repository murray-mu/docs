package com.yum.common.schemas;

import com.google.gson.Gson;
import com.yum.common.model.OrderCheckRes;
import com.yum.common.model.OrderValidateResult;
import com.yum.common.model.RuleEvent;
import com.yum.common.model.rule.RuleRes;
import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.common.serialization.SerializationSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;

import java.io.IOException;
import java.nio.charset.Charset;

/**
 * Rule Schema ，支持序列化和反序列化
 */
public class RuleResSchema implements DeserializationSchema<OrderCheckRes>, SerializationSchema<OrderCheckRes> {

    private static final Gson gson = new Gson();

    @Override
    public OrderCheckRes deserialize(byte[] bytes) throws IOException {
        return gson.fromJson(new String(bytes), OrderCheckRes.class);
    }

    @Override
    public boolean isEndOfStream(OrderCheckRes ruleRes) {
        return false;
    }

    @Override
    public byte[] serialize(OrderCheckRes ruleRes) {
        return gson.toJson(ruleRes).getBytes(Charset.forName("UTF-8"));
    }

    @Override
    public TypeInformation<OrderCheckRes> getProducedType() {
        return TypeInformation.of(OrderCheckRes.class);
    }
}
