package com.yum.common.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import java.util.ArrayList;
import java.util.List;

/**
 * Desc: 单个店铺的订单
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderEvent {
    String address2;

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public boolean isBigOrder() {
        return bigOrder;
    }

    public void setBigOrder(boolean bigOrder) {
        this.bigOrder = bigOrder;
    }

    public boolean isBooking() {
        return booking;
    }

    public void setBooking(boolean booking) {
        this.booking = booking;
    }

    public long getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(long bookingDate) {
        this.bookingDate = bookingDate;
    }

    public int getBookingType() {
        return bookingType;
    }

    public void setBookingType(int bookingType) {
        this.bookingType = bookingType;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public boolean isCompris() {
        return compris;
    }

    public void setCompris(boolean compris) {
        this.compris = compris;
    }

    public String getCoordinate_x() {
        return coordinate_x;
    }

    public void setCoordinate_x(String coordinate_x) {
        this.coordinate_x = coordinate_x;
    }

    public String getCoordinate_y() {
        return coordinate_y;
    }

    public void setCoordinate_y(String coordinate_y) {
        this.coordinate_y = coordinate_y;
    }

    public int getDeliverTimeOfMap() {
        return deliverTimeOfMap;
    }

    public void setDeliverTimeOfMap(int deliverTimeOfMap) {
        this.deliverTimeOfMap = deliverTimeOfMap;
    }

    public int getDeliveryTime() {
        return deliveryTime;
    }

    public void setDeliveryTime(int deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    public String getDinnerwareComment() {
        return dinnerwareComment;
    }

    public void setDinnerwareComment(String dinnerwareComment) {
        this.dinnerwareComment = dinnerwareComment;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public int getDonation() {
        return donation;
    }

    public void setDonation(int donation) {
        this.donation = donation;
    }

    public int getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(int houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getiLinkMan() {
        return iLinkMan;
    }

    public void setiLinkMan(String iLinkMan) {
        this.iLinkMan = iLinkMan;
    }

    public String getiRemark() {
        return iRemark;
    }

    public void setiRemark(String iRemark) {
        this.iRemark = iRemark;
    }

    public int getiTransType() {
        return iTransType;
    }

    public void setiTransType(int iTransType) {
        this.iTransType = iTransType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getInvoiceTitle() {
        return invoiceTitle;
    }

    public void setInvoiceTitle(String invoiceTitle) {
        this.invoiceTitle = invoiceTitle;
    }

    public List<IOrderItem> getItems() {
        return items;
    }

    public void setItems(List<IOrderItem> items) {
        this.items = items;
    }

    public String getLoginPhone() {
        return loginPhone;
    }

    public void setLoginPhone(String loginPhone) {
        this.loginPhone = loginPhone;
    }

    public String getMarketCode() {
        return marketCode;
    }

    public void setMarketCode(String marketCode) {
        this.marketCode = marketCode;
    }

    public boolean isNeedInvoice() {
        return needInvoice;
    }

    public void setNeedInvoice(boolean needInvoice) {
        this.needInvoice = needInvoice;
    }

    public int getNumberOfItems() {
        return numberOfItems;
    }

    public void setNumberOfItems(int numberOfItems) {
        this.numberOfItems = numberOfItems;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public long getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(long orderDate) {
        this.orderDate = orderDate;
    }

    public long getOrderValue() {
        return orderValue;
    }

    public void setOrderValue(long orderValue) {
        this.orderValue = orderValue;
    }

    public String getOsRemark() {
        return osRemark;
    }

    public void setOsRemark(String osRemark) {
        this.osRemark = osRemark;
    }

    public int getPackType() {
        return packType;
    }

    public void setPackType(int packType) {
        this.packType = packType;
    }

    public String getPayChannel() {
        return payChannel;
    }

    public void setPayChannel(String payChannel) {
        this.payChannel = payChannel;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPortalSource() {
        return portalSource;
    }

    public void setPortalSource(String portalSource) {
        this.portalSource = portalSource;
    }

    public long getPromiseTime() {
        return promiseTime;
    }

    public void setPromiseTime(long promiseTime) {
        this.promiseTime = promiseTime;
    }

    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public int getTermType() {
        return termType;
    }

    public void setTermType(int termType) {
        this.termType = termType;
    }

    public String getTicketNo() {
        return ticketNo;
    }

    public void setTicketNo(String ticketNo) {
        this.ticketNo = ticketNo;
    }

    public String getTransactionNo() {
        return transactionNo;
    }

    public void setTransactionNo(String transactionNo) {
        this.transactionNo = transactionNo;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserLevel() {
        return userLevel;
    }

    public void setUserLevel(String userLevel) {
        this.userLevel = userLevel;
    }

    public String getWebId() {
        return webId;
    }

    public void setWebId(String webId) {
        this.webId = webId;
    }

    boolean bigOrder;
    boolean booking;
    long bookingDate;
    int bookingType;
    String brand;
    String channelId;
    String channelName;
    String cityCode;
    String cityName;
    boolean compris;
    String coordinate_x;
    String coordinate_y;
    int deliverTimeOfMap;
    int deliveryTime;
    String  dinnerwareComment;  // "dinnerwareComment": null,
    int distance;
    int donation;
    int houseNumber;
    String iLinkMan;
    String iRemark;
    int iTransType;
    String id;
    String invoiceTitle;
    private List<IOrderItem> items;
    String loginPhone;
    String marketCode;
    boolean needInvoice;
    int numberOfItems;
    String openId;  // "openId": null,
    long orderDate;
    long orderValue;
    String osRemark; // "osRemark": null,
    int packType;
    String payChannel;
    String phone;
    String portalSource;
    long promiseTime;
    String storeCode;
    String streetName;
    int termType;
    String  ticketNo;   // "ticketNo": null,
    String transactionNo;
    String userCode;
    String userId;
    String userLevel; // "userLevel": null,
    String webId;

    public List<IOrderItem> getIOrderItems(){
        if (CollectionUtils.isNotEmpty(getItems())){
            return getItems();
        }else{
            return new ArrayList<IOrderItem>();
        }
    }
}
