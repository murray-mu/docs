package com.yum.common.model.rule;

import java.util.List;
import java.util.Map;

//优惠条件类
public class RuleCondition extends BaseCondition {
    //优惠码
    private String promotionCode;
    /**
     * 规则条件组
     */
    //订单满a元
    private Long fullMoney;

    //订单满足count 个A产品
    private Integer aCount;
    //a产品组
    private List<String> aProduct;
    //a产品百分比
    private Long aPercent;
    //产品互斥 订单有a产品就不能有b，c，d...
    private Map<String,List<String>> conflictProuduct;
    //优惠未享受的逻辑
    private Boolean aFlag;
    //优惠多享受的逻辑
    private Boolean bFlag;
    /**
     * 执行组
     */
    //整单减b元
    private Long totalDiscount;
    //整单打折
    private Long totalPercent;
    //以优惠价XX元购买Y份B产品/以折扣百分比购买Y份B产品
    private Long cDiscount;
    private Long cValue;
    //订单B产品的个数
    private Integer bCount;
    //订单B产品集合
    private List<String> bProduct;
    //是否允许一张订单中多次使用
    private boolean multiUse;
    //是否自动使用
    private boolean autoUse;

    private Map<String,List<String>> conflictPromotionMap;

    public boolean isMultiUse() {
        return multiUse;
    }

    public void setMultiUse(boolean multiUse) {
        this.multiUse = multiUse;
    }

    public String getPromotionCode() {
        return promotionCode;
    }

    public void setPromotionCode(String promotionCode) {
        this.promotionCode = promotionCode;
    }

    public Map<String, List<String>> getConflictProuduct() {
        return conflictProuduct;
    }

    public void setConflictProuduct(Map<String, List<String>> conflictProuduct) {
        this.conflictProuduct = conflictProuduct;
    }

    public Boolean getaFlag() {
        return aFlag;
    }

    public void setaFlag(Boolean aFlag) {
        this.aFlag = aFlag;
    }

    public Boolean getbFlag() {
        return bFlag;
    }

    public void setbFlag(Boolean bFlag) {
        this.bFlag = bFlag;
    }

    public Map<String, List<String>> getConflictPromotionMap() {
        return conflictPromotionMap;
    }

    public void setConflictPromotionMap(Map<String, List<String>> conflictPromotionMap) {
        this.conflictPromotionMap = conflictPromotionMap;
    }

    public Long getFullMoney() {
        return fullMoney;
    }

    public void setFullMoney(Long fullMoney) {
        this.fullMoney = fullMoney;
    }

    public Integer getaCount() {
        return aCount;
    }

    public void setaCount(Integer aCount) {
        this.aCount = aCount;
    }

    public List<String> getaProduct() {
        return aProduct;
    }

    public void setaProduct(List<String> aProduct) {
        this.aProduct = aProduct;
    }

    public Long getTotalDiscount() {
        return totalDiscount;
    }

    public void setTotalDiscount(Long totalDiscount) {
        this.totalDiscount = totalDiscount;
    }

    public Long getTotalPercent() {
        return totalPercent;
    }

    public void setTotalPercent(Long totalPercent) {
        this.totalPercent = totalPercent;
    }

    public Long getcDiscount() {
        return cDiscount;
    }

    public void setcDiscount(Long cDiscount) {
        this.cDiscount = cDiscount;
    }

    public Long getcValue() {
        return cValue;
    }

    public void setcValue(Long cValue) {
        this.cValue = cValue;
    }

    public Integer getbCount() {
        return bCount;
    }

    public void setbCount(Integer bCount) {
        this.bCount = bCount;
    }

    public List<String> getbProduct() {
        return bProduct;
    }

    public void setbProduct(List<String> bProduct) {
        this.bProduct = bProduct;
    }

    public Long getaPercent() {
        return aPercent;
    }

    public void setaPercent(Long aPercent) {
        this.aPercent = aPercent;
    }

    public boolean isAutoUse() {
        return autoUse;
    }

    public void setAutoUse(boolean autoUse) {
        this.autoUse = autoUse;
    }
}
