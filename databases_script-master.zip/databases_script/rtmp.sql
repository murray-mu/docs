-- MySQL dump 10.13  Distrib 5.7.30, for Linux (x86_64)
--
-- Host: localhost    Database: rtmp
-- ------------------------------------------------------
-- Server version	5.7.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alarm_rule`
--

DROP TABLE IF EXISTS `alarm_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarm_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  `type_id` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `target_id` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarm_rule`
--

LOCK TABLES `alarm_rule` WRITE;
/*!40000 ALTER TABLE `alarm_rule` DISABLE KEYS */;
INSERT INTO `alarm_rule` VALUES (1,'1','001','101',0),(2,'1','002','102',0),(3,'2','003','103',0),(4,'3','004','104',0),(5,'4','005','105',0),(6,'5','006','108',0);
/*!40000 ALTER TABLE `alarm_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_check_res`
--

DROP TABLE IF EXISTS `order_check_res`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_check_res` (
  `RES_ID` int(11) NOT NULL,
  `RULE_ID` int(11) DEFAULT NULL COMMENT '如：000001',
  `IS_PASS` tinyint(4) NOT NULL,
  `RES_INFO` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RULE_CODE` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '如：BUY_10001_DISOUNT_12001',
  `ORDER_ID` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_PHONE` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PHONE` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `STORE_CODE` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CITY` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `MARKET` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CHECK_TIME` datetime DEFAULT NULL COMMENT '校验时间',
  `ORDER_TIME` datetime DEFAULT NULL COMMENT '订单时间',
  `CHANNEL_ID` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`RES_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单校验结果';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_check_res`
--

LOCK TABLES `order_check_res` WRITE;
/*!40000 ALTER TABLE `order_check_res` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_check_res` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rule`
--

DROP TABLE IF EXISTS `rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule` (
  `RULE_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '如：000001',
  `RULE_TYPE_ID` int(11) DEFAULT NULL COMMENT '内置规则ID,如 00001',
  `RULE_NAME` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '如：买全家桶送蛋挞',
  `RULE_STATUS` int(11) DEFAULT NULL COMMENT '是否生效 0/1 1生效，其他不生效',
  PRIMARY KEY (`RULE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='<规则>是<规则类型>的某个具体实例，如：“买全家桶送蛋挞”是一个具体校验规则，规则主要包含规则名、规则分类编、是否生效';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule`
--

LOCK TABLES `rule` WRITE;
/*!40000 ALTER TABLE `rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `rule` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER create_rule_para AFTER INSERT ON rule FOR EACH ROW
BEGIN	
	DECLARE p1 int(11);
	DECLARE p2 int(11);
	DECLARE p3 varchar(50);
	DECLARE done BOOLEAN DEFAULT FALSE;
	DECLARE cur CURSOR FOR (SELECT PRAR_ID as p2, PARA_NAME as p3 from rule_type_para where RULE_TYPE_ID = NEW.RULE_TYPE_ID OR RULE_TYPE_ID = 0);
	DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET p3 = null;
	#插入的规则主键
	SET p1 = NEW.RULE_ID;
	#打开游标
	OPEN cur;
	#循环
	read_loop:LOOP
		FETCH cur INTO p2, p3;
		IF p3 IS NULL THEN
			LEAVE read_loop;
		END IF;
		INSERT INTO rule_para(RULE_ID,PRAR_ID,PARA_NAME,PARA_VALUE) values(p1,p2,p3,'');
	END LOOP;
	CLOSE cur;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `rule_base`
--

DROP TABLE IF EXISTS `rule_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_base` (
  `RULE_TYPE_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '内置规则ID,如 00001',
  `RULE_TYPE_NAME` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '如:买{X}份{A}产品，以优惠价{XX}元购买{Y}份{B}产品',
  `RULE_TYPE_CLASS` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '如: CheckImpl6.class',
  `STATUS` tinyint(4) NOT NULL COMMENT '1 可用 其他不可用 ',
  PRIMARY KEY (`RULE_TYPE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='<内置规则>是监控系统内置的、针对每类监控及统计需求进行的规则实现，每种<内置规则>可以扩展为多个<规则>，<内置规则>';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule_base`
--

LOCK TABLES `rule_base` WRITE;
/*!40000 ALTER TABLE `rule_base` DISABLE KEYS */;
INSERT INTO `rule_base` VALUES (1,'买X份A产品，以优惠价XX元购买Y份B产品','1',1),(2,'买X份A产品，以折扣百分比购买Y份B产品','2',1),(3,'买X分A 整单减B','3',1),(4,'整单满X元，以优惠价XX元购买Y份B产品','4',1),(5,'整单满A元，减B元','5',1),(6,'整单满A 整单折扣B%','6',1),(7,'整单满XX元，外送费减','7',1),(8,'买X份A产品,第二份半价','8',1),(9,'买X份A产品，外送费减免','9',1),(10,'买X份A产品,A产品折扣','10',1),(11,'买X份A产品，整单折扣B','11',1),(12,'整单满X元，以优惠价XX元购买Y份B产品','15',1),(13,'整单满A元，以折扣百分比购买Y份B产品','16',1),(14,'产品互斥','17',1),(15,'互斥优惠','18',1),(16,'特价菜','19',1),(17,'低折扣','20',1),(18,'随卡使用权益','21',1);
/*!40000 ALTER TABLE `rule_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rule_para`
--

DROP TABLE IF EXISTS `rule_para`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_para` (
  `RULE_PARA_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '如：000001',
  `RULE_ID` int(11) DEFAULT NULL COMMENT '如：000001',
  `PRAR_ID` int(11) DEFAULT NULL COMMENT '内置规则类型参数ID',
  `PARA_NAME` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '如:anum',
  `PARA_VALUE` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '参数值的类型可包括字符串、数字、日期、逗号分隔字符串等，如\r\n            01\r\n            100021\r\n            2020-12-21\r\n            01，02，03，04，\r\n            ',
  PRIMARY KEY (`RULE_PARA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='<规则参数>是规则中具体的参数值信息，主要包括参数编码、参数值等信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule_para`
--

LOCK TABLES `rule_para` WRITE;
/*!40000 ALTER TABLE `rule_para` DISABLE KEYS */;
/*!40000 ALTER TABLE `rule_para` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rule_type_para`
--

DROP TABLE IF EXISTS `rule_type_para`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_type_para` (
  `PRAR_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '参数ID',
  `RULE_TYPE_ID` int(11) DEFAULT NULL COMMENT '内置规则ID,如 00001',
  `PARA_NAME` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '如:anum',
  `PARA_DESC` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '如：A产品ID',
  `PARA_TYPE` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '参数类型包括：字符串、数字、日期、JSON等',
  `REQUIRED` tinyint(4) DEFAULT NULL COMMENT '1 必须 0 非必须',
  `COMMON` tinyint(4) DEFAULT NULL COMMENT '是否通用，1 是 0 否 ，通用参数为所有规则都使用的参数，不需要在每个内置规则中再维护了，属于公共的内置参数定义',
  PRIMARY KEY (`PRAR_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=288 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='<内置规则参数>是<内置规则>的参数，包括参数名称、参数类型、是否必须';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule_type_para`
--

LOCK TABLES `rule_type_para` WRITE;
/*!40000 ALTER TABLE `rule_type_para` DISABLE KEYS */;
INSERT INTO `rule_type_para` VALUES (1,1,'aCount','A产品数量','String',1,NULL),(2,1,'aProduct','A产品LinkId集合','String',1,NULL),(3,1,'cValue','B产品换购价格','String',1,NULL),(4,1,'bCount','B产品数量','String',1,NULL),(5,1,'bProduct','B产品LinkId集合','String',1,NULL),(6,1,'aFlag','检验本该享受确未享受','String',1,NULL),(7,1,'bFlag','校验不该享受确享受了','String',1,NULL),(8,1,'promotionCode','优惠编码','String',1,NULL),(9,1,'storeCode','在哪些店铺执行优惠','String',0,NULL),(10,1,'districts','街道','String',0,NULL),(11,1,'cities','城市','String',0,NULL),(12,1,'markets','店铺','String',0,NULL),(13,1,'validateFrom','开始日期','String',1,NULL),(14,1,'validateTo','截止日期','String',1,NULL),(15,1,'daysValid','一周中哪天使用','String',0,NULL),(16,1,'multiUse','一个订单中多次使用','String',1,NULL),(17,1,'autoUse','订单自动使用','String',1,NULL),(18,1,'startTime','开始时间','String',0,NULL),(19,1,'endTime','结束时间','String',0,NULL),(20,1,'channelId','渠道','String',0,NULL),(21,2,'aCount','A产品数量','String',1,NULL),(22,2,'aProduct','A产品LinkId集合','String',1,NULL),(23,2,'cPercent','B产品折扣','String',1,NULL),(24,2,'bCount','B产品数量','String',1,NULL),(25,2,'bProduct','B产品LinkId集合','String',1,NULL),(26,2,'aFlag','检验本该享受确未享受','String',1,NULL),(27,2,'bFlag','校验不该享受确享受了','String',1,NULL),(28,2,'promotionCode','优惠编码','String',1,NULL),(29,2,'storeCode','在哪些店铺执行优惠','String',0,NULL),(30,2,'districts','街道','String',0,NULL),(31,2,'cities','城市','String',0,NULL),(32,2,'markets','店铺','String',0,NULL),(33,2,'validateFrom','开始日期','String',1,NULL),(34,2,'validateTo','截止日期','String',1,NULL),(35,2,'daysValid','一周中哪天使用','String',0,NULL),(36,2,'multiUse','一个订单中多次使用','String',1,NULL),(37,2,'autoUse','订单自动使用','String',1,NULL),(38,2,'startTime','开始时间','String',0,NULL),(39,2,'endTime','结束时间','String',0,NULL),(40,2,'channelId','渠道','String',0,NULL),(41,3,'aCount','A产品数量','String',1,NULL),(42,3,'aProduct','A产品LinkId集合','String',1,NULL),(43,3,'totalDiscount','整单减金额','String',1,NULL),(44,3,'aFlag','检验本该享受确未享受','String',1,NULL),(45,3,'bFlag','校验不该享受确享受了','String',1,NULL),(46,3,'promotionCode','优惠编码','String',1,NULL),(47,3,'storeCode','在哪些店铺执行优惠','String',0,NULL),(48,3,'districts','街道','String',0,NULL),(49,3,'cities','城市','String',0,NULL),(50,3,'markets','店铺','String',0,NULL),(51,3,'validateFrom','开始日期','String',1,NULL),(52,3,'validateTo','截止日期','String',1,NULL),(53,3,'daysValid','一周中哪天使用','String',0,NULL),(54,3,'multiUse','一个订单中多次使用','String',1,NULL),(55,3,'autoUse','订单自动使用','String',1,NULL),(56,3,'startTime','开始时间','String',0,NULL),(57,3,'endTime','结束时间','String',0,NULL),(58,3,'channelId','渠道','String',0,NULL),(59,4,'fullMoney','整单满金额','String',1,NULL),(60,4,'cValue','B产品换购价格','String',1,NULL),(61,4,'bCount','B产品数量','String',1,NULL),(62,4,'bProduct','B产品LinkId集合','String',1,NULL),(63,4,'aFlag','检验本该享受确未享受','String',1,NULL),(64,4,'bFlag','校验不该享受确享受了','String',1,NULL),(65,4,'promotionCode','优惠编码','String',1,NULL),(66,4,'storeCode','在哪些店铺执行优惠','String',0,NULL),(67,4,'districts','街道','String',0,NULL),(68,4,'cities','城市','String',0,NULL),(69,4,'markets','店铺','String',0,NULL),(70,4,'validateFrom','开始日期','String',1,NULL),(71,4,'validateTo','截止日期','String',1,NULL),(72,4,'daysValid','一周中哪天使用','String',0,NULL),(73,4,'multiUse','一个订单中多次使用','String',1,NULL),(74,4,'autoUse','订单自动使用','String',1,NULL),(75,4,'startTime','开始时间','String',0,NULL),(76,4,'endTime','结束时间','String',0,NULL),(77,4,'channelId','渠道','String',0,NULL),(78,5,'fullMoney','整单满金额','String',1,NULL),(79,5,'totalDiscount','整单减金额','String',1,NULL),(80,5,'aFlag','检验本该享受确未享受','String',1,NULL),(81,5,'bFlag','校验不该享受确享受了','String',1,NULL),(82,5,'promotionCode','优惠编码','String',1,NULL),(83,5,'storeCode','在哪些店铺执行优惠','String',0,NULL),(84,5,'districts','街道','String',0,NULL),(85,5,'cities','城市','String',0,NULL),(86,5,'markets','店铺','String',0,NULL),(87,5,'validateFrom','开始日期','String',1,NULL),(88,5,'validateTo','截止日期','String',1,NULL),(89,5,'daysValid','一周中哪天使用','String',0,NULL),(90,5,'multiUse','一个订单中多次使用','String',1,NULL),(91,5,'autoUse','订单自动使用','String',1,NULL),(92,5,'startTime','开始时间','String',0,NULL),(93,5,'endTime','结束时间','String',0,NULL),(94,5,'channelId','渠道','String',0,NULL),(95,6,'fullMoney','整单满金额','String',1,NULL),(96,6,'totalPercent','整单百分比','String',1,NULL),(97,6,'aFlag','检验本该享受确未享受','String',1,NULL),(98,6,'bFlag','校验不该享受确享受了','String',1,NULL),(99,6,'promotionCode','优惠编码','String',1,NULL),(100,6,'storeCode','在哪些店铺执行优惠','String',0,NULL),(101,6,'districts','街道','String',0,NULL),(102,6,'cities','城市','String',0,NULL),(103,6,'markets','店铺','String',0,NULL),(104,6,'validateFrom','开始日期','String',1,NULL),(105,6,'validateTo','截止日期','String',1,NULL),(106,6,'daysValid','一周中哪天使用','String',0,NULL),(107,6,'multiUse','一个订单中多次使用','String',1,NULL),(108,6,'autoUse','订单自动使用','String',1,NULL),(109,6,'startTime','开始时间','String',0,NULL),(110,6,'endTime','结束时间','String',0,NULL),(111,6,'channelId','渠道','String',0,NULL),(112,7,'fullMoney','整单满金额','String',1,NULL),(113,7,'aFlag','检验本该享受确未享受','String',1,NULL),(114,7,'bFlag','校验不该享受确享受了','String',1,NULL),(115,7,'promotionCode','优惠编码','String',1,NULL),(116,7,'storeCode','在哪些店铺执行优惠','String',0,NULL),(117,7,'districts','街道','String',0,NULL),(118,7,'cities','城市','String',0,NULL),(119,7,'markets','店铺','String',0,NULL),(120,7,'validateFrom','开始日期','String',1,NULL),(121,7,'validateTo','截止日期','String',1,NULL),(122,7,'daysValid','一周中哪天使用','String',0,NULL),(123,7,'multiUse','一个订单中多次使用','String',1,NULL),(124,7,'autoUse','订单自动使用','String',1,NULL),(125,7,'startTime','开始时间','String',0,NULL),(126,7,'endTime','结束时间','String',0,NULL),(127,7,'channelId','渠道','String',0,NULL),(128,8,'aCount','A产品数量','String',1,NULL),(129,8,'aProduct','A产品LinkId集合','String',1,NULL),(130,8,'aFlag','检验本该享受确未享受','String',1,NULL),(131,8,'bFlag','校验不该享受确享受了','String',1,NULL),(132,8,'promotionCode','优惠编码','String',1,NULL),(133,8,'storeCode','在哪些店铺执行优惠','String',0,NULL),(134,8,'districts','街道','String',0,NULL),(135,8,'cities','城市','String',0,NULL),(136,8,'markets','店铺','String',0,NULL),(137,8,'validateFrom','开始日期','String',1,NULL),(138,8,'validateTo','截止日期','String',1,NULL),(139,8,'daysValid','一周中哪天使用','String',0,NULL),(140,8,'multiUse','一个订单中多次使用','String',1,NULL),(141,8,'autoUse','订单自动使用','String',1,NULL),(142,8,'startTime','开始时间','String',0,NULL),(143,8,'endTime','结束时间','String',0,NULL),(144,8,'channelId','渠道','String',0,NULL),(145,9,'aCount','A产品数量','String',1,NULL),(146,9,'aProduct','A产品LinkId集合','String',1,NULL),(147,9,'aFlag','检验本该享受确未享受','String',1,NULL),(148,9,'bFlag','校验不该享受确享受了','String',1,NULL),(149,9,'promotionCode','优惠编码','String',1,NULL),(150,9,'storeCode','在哪些店铺执行优惠','String',0,NULL),(151,9,'districts','街道','String',0,NULL),(152,9,'cities','城市','String',0,NULL),(153,9,'markets','店铺','String',0,NULL),(154,9,'validateFrom','开始日期','String',1,NULL),(155,9,'validateTo','截止日期','String',1,NULL),(156,9,'daysValid','一周中哪天使用','String',0,NULL),(157,9,'multiUse','一个订单中多次使用','String',1,NULL),(158,9,'autoUse','订单自动使用','String',1,NULL),(159,9,'startTime','开始时间','String',0,NULL),(160,9,'endTime','结束时间','String',0,NULL),(161,9,'channelId','渠道','String',0,NULL),(162,10,'aCount','A产品数量','String',1,NULL),(163,10,'aProduct','A产品LinkId集合','String',1,NULL),(164,10,'aPercent','A产品折扣','String',1,NULL),(165,10,'aFlag','检验本该享受确未享受','String',1,NULL),(166,10,'bFlag','校验不该享受确享受了','String',1,NULL),(167,10,'promotionCode','优惠编码','String',1,NULL),(168,10,'storeCode','在哪些店铺执行优惠','String',0,NULL),(169,10,'districts','街道','String',0,NULL),(170,10,'cities','城市','String',0,NULL),(171,10,'markets','店铺','String',0,NULL),(172,10,'validateFrom','开始日期','String',1,NULL),(173,10,'validateTo','截止日期','String',1,NULL),(174,10,'daysValid','一周中哪天使用','String',0,NULL),(175,10,'multiUse','一个订单中多次使用','String',1,NULL),(176,10,'autoUse','订单自动使用','String',1,NULL),(177,10,'startTime','开始时间','String',0,NULL),(178,10,'endTime','结束时间','String',0,NULL),(179,10,'channelId','渠道','String',0,NULL),(180,11,'aCount','A产品数量','String',1,NULL),(181,11,'aProduct','A产品LinkId集合','String',1,NULL),(182,11,'totalPercent','整单百分比','String',1,NULL),(183,11,'aFlag','检验本该享受确未享受','String',1,NULL),(184,11,'bFlag','校验不该享受确享受了','String',1,NULL),(185,11,'promotionCode','优惠编码','String',1,NULL),(186,11,'storeCode','在哪些店铺执行优惠','String',0,NULL),(187,11,'districts','街道','String',0,NULL),(188,11,'cities','城市','String',0,NULL),(189,11,'markets','店铺','String',0,NULL),(190,11,'validateFrom','开始日期','String',1,NULL),(191,11,'validateTo','截止日期','String',1,NULL),(192,11,'daysValid','一周中哪天使用','String',0,NULL),(193,11,'multiUse','一个订单中多次使用','String',1,NULL),(194,11,'autoUse','订单自动使用','String',1,NULL),(195,11,'startTime','开始时间','String',0,NULL),(196,11,'endTime','结束时间','String',0,NULL),(197,11,'channelId','渠道','String',0,NULL),(198,12,'fullMoney','整单满金额','String',1,NULL),(199,12,'cValue','B产品换购价格','String',1,NULL),(200,12,'bCount','B产品数量','String',1,NULL),(201,12,'bProduct','B产品LinkId集合','String',1,NULL),(202,12,'aFlag','检验本该享受确未享受','String',1,NULL),(203,12,'bFlag','校验不该享受确享受了','String',1,NULL),(204,12,'promotionCode','优惠编码','String',1,NULL),(205,12,'storeCode','在哪些店铺执行优惠','String',0,NULL),(206,12,'districts','街道','String',0,NULL),(207,12,'cities','城市','String',0,NULL),(208,12,'markets','店铺','String',0,NULL),(209,12,'validateFrom','开始日期','String',1,NULL),(210,12,'validateTo','截止日期','String',1,NULL),(211,12,'daysValid','一周中哪天使用','String',0,NULL),(212,12,'multiUse','一个订单中多次使用','String',1,NULL),(213,12,'autoUse','订单自动使用','String',1,NULL),(214,12,'startTime','开始时间','String',0,NULL),(215,12,'endTime','结束时间','String',0,NULL),(216,12,'channelId','渠道','String',0,NULL),(217,13,'fullMoney','整单满金额','String',1,NULL),(218,13,'cPercent','B产品折扣','String',1,NULL),(219,13,'bCount','B产品数量','String',1,NULL),(220,13,'bProduct','B产品LinkId集合','String',1,NULL),(221,13,'aFlag','检验本该享受确未享受','String',1,NULL),(222,13,'bFlag','校验不该享受确享受了','String',1,NULL),(223,13,'promotionCode','优惠编码','String',1,NULL),(224,13,'storeCode','在哪些店铺执行优惠','String',0,NULL),(225,13,'districts','街道','String',0,NULL),(226,13,'cities','城市','String',0,NULL),(227,13,'markets','店铺','String',0,NULL),(228,13,'validateFrom','开始日期','String',1,NULL),(229,13,'validateTo','截止日期','String',1,NULL),(230,13,'daysValid','一周中哪天使用','String',0,NULL),(231,13,'multiUse','一个订单中多次使用','String',1,NULL),(232,13,'autoUse','订单自动使用','String',1,NULL),(233,13,'startTime','开始时间','String',0,NULL),(234,13,'endTime','结束时间','String',0,NULL),(235,13,'channelId','渠道','String',0,NULL),(236,14,'conflictProduct','互斥产品','String',1,NULL),(237,14,'aFlag','检验本该享受确未享受','String',1,NULL),(238,14,'bFlag','校验不该享受确享受了','String',1,NULL),(239,14,'storeCode','在哪些店铺执行优惠','String',0,NULL),(240,14,'districts','街道','String',0,NULL),(241,14,'cities','城市','String',0,NULL),(242,14,'markets','店铺','String',0,NULL),(243,14,'validateFrom','开始日期','String',0,NULL),(244,14,'validateTo','截止日期','String',0,NULL),(245,14,'daysValid','一周中哪天使用','String',0,NULL),(246,14,'startTime','开始时间','String',0,NULL),(247,14,'endTime','结束时间','String',0,NULL),(248,14,'channelId','渠道','String',0,NULL),(249,15,'conflictPromotion','互斥产品','String',1,NULL),(250,15,'aFlag','检验本该享受确未享受','String',1,NULL),(251,15,'bFlag','校验不该享受确享受了','String',1,NULL),(252,15,'storeCode','在哪些店铺执行优惠','String',0,NULL),(253,15,'districts','街道','String',0,NULL),(254,15,'cities','城市','String',0,NULL),(255,15,'markets','店铺','String',0,NULL),(256,15,'validateFrom','开始日期','String',0,NULL),(257,15,'validateTo','截止日期','String',0,NULL),(258,15,'daysValid','一周中哪天使用','String',0,NULL),(259,15,'startTime','开始时间','String',0,NULL),(260,15,'endTime','结束时间','String',0,NULL),(261,15,'channelId','渠道','String',0,NULL),(262,16,'specialProcunt','特价产品','String',1,NULL),(263,16,'aFlag','检验本该享受确未享受','String',1,NULL),(264,16,'bFlag','校验不该享受确享受了','String',1,NULL),(265,16,'storeCode','在哪些店铺执行优惠','String',0,NULL),(266,16,'districts','街道','String',0,NULL),(267,16,'cities','城市','String',0,NULL),(268,16,'markets','店铺','String',0,NULL),(269,16,'validateFrom','开始日期','String',0,NULL),(270,16,'validateTo','截止日期','String',0,NULL),(271,16,'daysValid','一周中哪天使用','String',0,NULL),(272,16,'startTime','开始时间','String',0,NULL),(273,16,'endTime','结束时间','String',0,NULL),(274,16,'channelId','渠道','String',0,NULL),(275,17,'thresholdValue','临界值','String',1,NULL),(276,17,'aFlag','检验本该享受确未享受','String',1,NULL),(277,17,'bFlag','校验不该享受确享受了','String',1,NULL),(278,17,'storeCode','在哪些店铺执行优惠','String',0,NULL),(279,17,'districts','街道','String',0,NULL),(280,17,'cities','城市','String',0,NULL),(281,17,'markets','店铺','String',0,NULL),(282,17,'validateFrom','开始日期','String',0,NULL),(283,17,'validateTo','截止日期','String',0,NULL),(284,17,'daysValid','一周中哪天使用','String',0,NULL),(285,17,'startTime','开始时间','String',0,NULL),(286,17,'endTime','结束时间','String',0,NULL),(287,17,'channelId','渠道','String',0,NULL);
/*!40000 ALTER TABLE `rule_type_para` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-01 15:51:01
