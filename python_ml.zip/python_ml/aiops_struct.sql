-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: 10.67.32.11    Database: aiops
-- ------------------------------------------------------
-- Server version	5.7.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `3sigma_neg`
--

DROP TABLE IF EXISTS `3sigma_neg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `3sigma_neg` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '0',
  `label` int(11) NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '0',
  `ts` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `3sigma_neg_un` (`ts`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=520199 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `anomaly`
--

DROP TABLE IF EXISTS `anomaly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `anomaly` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `view_id` varchar(31) NOT NULL DEFAULT '',
  `view_name` varchar(63) NOT NULL DEFAULT '',
  `attr_id` varchar(31) NOT NULL DEFAULT '',
  `attr_name` varchar(63) NOT NULL DEFAULT '',
  `time` datetime DEFAULT NULL,
  `data_c` text,
  `data_b` text,
  `data_a` text,
  `mark_flag` tinyint(1) NOT NULL DEFAULT '1',
  `anomaly_data` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2429 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dupgd_neg`
--

DROP TABLE IF EXISTS `dupgd_neg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dupgd_neg` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '0',
  `label` int(11) NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '0',
  `ts` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dupgd_neg_un` (`ts`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=512943 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `flux_neg`
--

DROP TABLE IF EXISTS `flux_neg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flux_neg` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '0',
  `label` int(11) NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '0',
  `ts` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `flux_neg_un` (`ts`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=510576 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `missing_neg`
--

DROP TABLE IF EXISTS `missing_neg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `missing_neg` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '0',
  `label` int(11) NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '0',
  `ts` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `missing_neg_un` (`ts`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=291351 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `request` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `saveOnlinePayOrder` int(11) NOT NULL DEFAULT '0',
  `getMenuByStore` int(11) NOT NULL DEFAULT '0',
  `ts` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_un` (`ts`)
) ENGINE=InnoDB AUTO_INCREMENT=27896 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_anomaly`
--

DROP TABLE IF EXISTS `request_anomaly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `request_anomaly` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `view_id` varchar(31) NOT NULL DEFAULT '',
  `view_name` varchar(63) NOT NULL DEFAULT '',
  `attr_id` varchar(31) NOT NULL DEFAULT '',
  `attr_name` varchar(63) NOT NULL DEFAULT '',
  `time` datetime DEFAULT NULL,
  `data_c` text,
  `data_b` text,
  `data_a` text,
  `mark_flag` tinyint(1) NOT NULL DEFAULT '1',
  `anomaly_data` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2295 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `request_sample_dataset`
--

DROP TABLE IF EXISTS `request_sample_dataset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `request_sample_dataset` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `view_id` varchar(31) NOT NULL DEFAULT '',
  `view_name` varchar(63) NOT NULL DEFAULT '',
  `attr_name` varchar(63) NOT NULL DEFAULT '',
  `attr_id` varchar(31) NOT NULL DEFAULT '',
  `source` varchar(31) NOT NULL DEFAULT '',
  `train_or_test` varchar(10) NOT NULL DEFAULT '',
  `positive_or_negative` varchar(20) NOT NULL DEFAULT '',
  `window` int(10) NOT NULL DEFAULT '0',
  `data_time` int(10) DEFAULT NULL,
  `data_c` text,
  `data_b` text,
  `data_a` text,
  `anomaly_id` int(10) DEFAULT NULL,
  `label_neg` int(10) DEFAULT NULL,
  `data_time_neg` int(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `data_time_neg_index` (`data_time_neg`),
  KEY `data_time_index` (`data_time`)
) ENGINE=InnoDB AUTO_INCREMENT=469984 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sample_dataset`
--

DROP TABLE IF EXISTS `sample_dataset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sample_dataset` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `view_id` varchar(31) NOT NULL DEFAULT '',
  `view_name` varchar(63) NOT NULL DEFAULT '',
  `attr_name` varchar(63) NOT NULL DEFAULT '',
  `attr_id` varchar(31) NOT NULL DEFAULT '',
  `source` varchar(31) NOT NULL DEFAULT '',
  `train_or_test` varchar(10) NOT NULL DEFAULT '',
  `positive_or_negative` varchar(20) NOT NULL DEFAULT '',
  `window` int(10) NOT NULL DEFAULT '0',
  `data_time` int(10) DEFAULT NULL,
  `data_c` text,
  `data_b` text,
  `data_a` text,
  `anomaly_id` int(10) DEFAULT NULL,
  `label_neg` int(10) DEFAULT NULL,
  `data_time_neg` int(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `data_time_neg_index` (`data_time_neg`),
  KEY `data_time_index` (`data_time`)
) ENGINE=InnoDB AUTO_INCREMENT=739990 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_conv_rate`
--

DROP TABLE IF EXISTS `t_conv_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_conv_rate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '0',
  `entry` int(11) NOT NULL DEFAULT '0',
  `pay` int(11) NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '0',
  `ts` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`,`ts`)
) ENGINE=InnoDB AUTO_INCREMENT=3430248 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `total_neg`
--

DROP TABLE IF EXISTS `total_neg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `total_neg` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '0',
  `label` int(11) NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '0',
  `ts` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1860109 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `train_task`
--

DROP TABLE IF EXISTS `train_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `train_task` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `task_id` varchar(20) NOT NULL DEFAULT '',
  `sample_num` int(10) NOT NULL DEFAULT '0',
  `postive_sample_num` int(10) NOT NULL DEFAULT '0',
  `negative_sample_num` int(10) NOT NULL DEFAULT '0',
  `window` int(10) NOT NULL DEFAULT '0',
  `model_name` varchar(20) NOT NULL DEFAULT '',
  `source` varchar(255) NOT NULL DEFAULT '',
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_time` timestamp NULL DEFAULT NULL,
  `status` varchar(11) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-18 13:58:08
