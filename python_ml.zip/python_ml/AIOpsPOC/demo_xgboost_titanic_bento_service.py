import xgboost as xgb

import bentoml
from bentoml.frameworks.xgboost import XgboostModelArtifact
from bentoml.adapters import DataframeInput

@bentoml.env(infer_pip_packages=True)
@bentoml.artifacts([XgboostModelArtifact('model_demo')])
class demoTitanicSurvivalPredictionXgBoost(bentoml.BentoService):

    @bentoml.api(input=DataframeInput(), batch=True)
    def predict(self, df):
        # "Pclass": 1, "Age": 30, "Fare": 200, "SibSp": 1, "Parch": 0}
        data = xgb.DMatrix(data=df[['Pclass', 'Age', 'Fare', 'SibSp', 'Parch']])
        return self.artifacts.model_demo.predict(data)

    @bentoml.api(input=DataframeInput(), batch=True)
    def predict_demo(self, df):
        data = xgb.DMatrix(data=df[['Pclass', 'Age', 'Fare', 'SibSp', 'Parch']])
        return self.artifacts.model_demo.predict(data)