data1 = ['1','3.2','2']
data1 = map(eval, data1)
print(len(list(data1)))