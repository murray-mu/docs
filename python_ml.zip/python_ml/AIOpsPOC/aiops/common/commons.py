#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import traceback
from functools import wraps
from aiops.common.errorcodes import *

DEFAULT_WINDOW = 180
INPUT_LEN_ENG_MAX = 32
INPUT_LEN_CH_MAX = 64
INPUT_ITEM_PER_PAGE_MAX = 100
INPUT_LIST_LEN_MAX = 5
VALUE_LEN_MAX = 50000
MARK_POSITIVE = 1
MARK_NEGATIVE = 2

def build_ret_data(ret_code, data=""):
    return {"code": ret_code, "msg": ERR_CODE[ret_code], "data": data}


def exce_service(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            ret_code, ret_data = func(*args, **kwargs)
            return_dict = build_ret_data(ret_code, ret_data)
        except Exception as ex:
            traceback.print_exc()
            return_dict = build_ret_data(THROW_EXP, str(ex))
        return return_dict
    return wrapper
