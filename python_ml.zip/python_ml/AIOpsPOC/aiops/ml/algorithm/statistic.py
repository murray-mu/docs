#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import numpy as np

class Statistic(object):
    def __init__(self, index=3):
        self.index = index
    def predict(self, X):

        if abs(X[-1] - np.mean(X[:-1])) > self.index * np.std(X[:-1]):
            return 0
        return 1
