#!/usr/bin/env python
# -*- coding=utf-8 -*-
import numpy as np
class Ewma(object):
    """
    vt=βvt−1+(1−β)θt β取0.9效果比较好
        其中vt是t时刻的指数加权移动平均值，θt是t时刻的真实值，β是权重，是一个超参数。
    系数 β 越小就说明对过去测量值的权重越低，也就是对当前抽样值的权重越高。
    这个时候移动平均估计值的时效性就越强(其实也就是更加拟合点分布的趋势)。反之，则会越弱
    我们使用 β=0.9 来看看指数移动加权平均的原理是什么?
        v100=0.9v99+0.1θ100
        v99=0.9v98+0.1θ99
        v98=0.9v97+0.1θ98
        ⋯=⋯
        我们将式子一步一步的带入得到最终式子：
        v100=0.1×0.90×θls100+0.1×0.91×θ99+0.1×0.92θ98+⋯+0.1×0.999×θ1

        我们认为，上述操作，实际上是10天的平均结果，因为0.99×0.1非常小了，后续的可以近似为0。
        当β为其他值时，平均的天数可以通过以下公式进行计算
            naverage=1/1−β
    In statistical quality control, the EWMA chart (or exponentially weighted moving average chart)
    is a type of control chart used to monitor either variables or attributes-type data using the monitored business
    or industrial process's entire history of output. While other control charts treat rational subgroups of samples
    individually, the EWMA chart tracks the exponentially-weighted moving average of all prior sample means.

    WIKIPEDIA: https://en.wikipedia.org/wiki/EWMA_chart
    """

    def __init__(self, alpha=0.3, coefficient=3):
        self.alpha = alpha
        self.coefficient = coefficient

    def predict(self, X):
        s = [X[0]]
        for i in range(1, len(X)):
            temp = self.alpha * X[i] + (1 - self.alpha) * s[-1]
            s.append(temp)
        s_avg = np.mean(s)
        sigma = np.sqrt(np.var(X))
        ucl = s_avg + self.coefficient * sigma * np.sqrt(self.alpha / (2 - self.alpha))
        lcl = s_avg - self.coefficient * sigma * np.sqrt(self.alpha / (2 - self.alpha))
        if s[-1] > ucl or s[-1] < lcl:
            return 0
        return 1
