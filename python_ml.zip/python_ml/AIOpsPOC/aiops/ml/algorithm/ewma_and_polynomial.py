#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from aiops.ml.algorithm import ewma
from aiops.ml.algorithm import polynomial_interpolation
from aiops.ml.common.tsd_common import *

class EwmaAndPolynomialInterpolation(object):
    def __init__(self, alpha=0.3, coefficient=3, threshold=0.15, degree=4):
        self.alpha = alpha
        self.coefficient = coefficient
        self.degree = degree
        self.threshold = threshold

    def predict(self, X, window=DEFAULT_WINDOW):
        ewma_obj = ewma.Ewma(self.alpha, self.coefficient)
        ewma_ret = ewma_obj.predict(X)
        if ewma_ret == 1:
            result = 1
        else:
            polynomial_obj = polynomial_interpolation.PolynomialInterpolation(self.threshold, self.degree)
            polynomial_ret = polynomial_obj.predict(X, window)
            result = polynomial_ret
        return result
