#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import aiops.ml.feature.statistical_features
import aiops.ml.feature.classification_features
import aiops.ml.feature.fitting_features

from aiops.ml.common import tsd_common

from aiops.ml.feature import fitting_features
from aiops.ml.feature import classification_features
from aiops.ml.feature import statistical_features

def extract_features(time_series, window):

    if not tsd_common.is_standard_time_series(time_series, window):
        # todo: add your report of this error here...

        return []

    # spilt time_series
    split_time_series = tsd_common.split_time_series(time_series, window)
    # nomalize time_series
    normalized_split_time_series = tsd_common.normalize_time_series(split_time_series)
    max_min_normalized_time_series = tsd_common.normalize_time_series_by_max_min(split_time_series)
    s_features = statistical_features.get_statistical_features(normalized_split_time_series[4])
    f_features = fitting_features.get_fitting_features(normalized_split_time_series)
    c_features = classification_features.get_classification_features(max_min_normalized_time_series)
    # combine features with types
    features = s_features + f_features + c_features
    return features
