#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import numpy as np
from aiops.ml.common.tsd_common import *


def time_series_moving_average(x):

    temp_list = []
    for w in range(1, min(50, DEFAULT_WINDOW), 5):
        temp = np.mean(x[-w:])
        temp_list.append(temp)
    return list(np.array(temp_list) - x[-1])


def time_series_weighted_moving_average(x):
    temp_list = []
    for w in range(1, min(50, DEFAULT_WINDOW), 5):
        w = min(len(x), w)  # avoid the case len(value_list) < w
        coefficient = np.array(range(1, w + 1))
        temp_list.append((np.dot(coefficient, x[-w:])) / float(w * (w + 1) / 2))
    return list(np.array(temp_list) - x[-1])


def time_series_exponential_weighted_moving_average(x):

    temp_list = []
    for j in range(1, 10):
        alpha = j / 10.0
        s = [x[0]]
        for i in range(1, len(x)):
            temp = alpha * x[i] + (1 - alpha) * s[-1]
            s.append(temp)
        temp_list.append(s[-1] - x[-1])
    return temp_list


def time_series_double_exponential_weighted_moving_average(x):

    temp_list = []
    for j1 in range(1, 10, 2):
        for j2 in range(1, 10, 2):
            alpha = j1 / 10.0
            gamma = j2 / 10.0
            s = [x[0]]
            b = [(x[3] - x[0]) / 3]  # s is the smoothing part, b is the trend part
            for i in range(1, len(x)):
                temp1 = alpha * x[i] + (1 - alpha) * (s[-1] + b[-1])
                s.append(temp1)
                temp2 = gamma * (s[-1] - s[-2]) + (1 - gamma) * b[-1]
                b.append(temp2)
            temp_list.append(s[-1] - x[-1])
    return temp_list


def time_series_periodic_features(data_c_left, data_c_right, data_b_left, data_b_right, data_a):

    periodic_features = []
    temp_value = data_c_left[-1] - data_a[-1]
    periodic_features.append(abs(temp_value))
    if temp_value < 0:
        periodic_features.append(-1)
    else:
        periodic_features.append(1)

    temp_value = data_b_left[-1] - data_a[-1]
    periodic_features.append(abs(temp_value))
    if temp_value < 0:
        periodic_features.append(-1)
    else:
        periodic_features.append(1)


    periodic_features.append(min(max(data_c_left) - data_a[-1], 0))
    periodic_features.append(min(max(data_c_right) - data_a[-1], 0))
    periodic_features.append(min(max(data_b_left) - data_a[-1], 0))
    periodic_features.append(min(max(data_b_right) - data_a[-1], 0))
    periodic_features.append(max(min(data_c_left) - data_a[-1], 0))
    periodic_features.append(max(min(data_c_right) - data_a[-1], 0))
    periodic_features.append(max(min(data_b_left) - data_a[-1], 0))
    periodic_features.append(max(min(data_b_right) - data_a[-1], 0))


    for w in range(1, DEFAULT_WINDOW, int(DEFAULT_WINDOW / 6)):
        periodic_features.append(min(max(data_c_left[-w:]) - data_a[-1], 0))
        periodic_features.append(min(max(data_c_right[:w]) - data_a[-1], 0))
        periodic_features.append(min(max(data_b_left[-w:]) - data_a[-1], 0))
        periodic_features.append(min(max(data_b_right[:w]) - data_a[-1], 0))
        periodic_features.append(max(min(data_c_left[-w:]) - data_a[-1], 0))
        periodic_features.append(max(min(data_c_right[:w]) - data_a[-1], 0))
        periodic_features.append(max(min(data_b_left[-w:]) - data_a[-1], 0))
        periodic_features.append(max(min(data_b_right[:w]) - data_a[-1], 0))


    for w in range(1, DEFAULT_WINDOW, int(DEFAULT_WINDOW / 9)):
        temp_value = np.mean(data_c_left[-w:]) - np.mean(data_a[-w:])
        periodic_features.append(abs(temp_value))
        if temp_value < 0:
            periodic_features.append(-1)
        else:
            periodic_features.append(1)

        temp_value = np.mean(data_c_right[:w]) - np.mean(data_a[-w:])
        periodic_features.append(abs(temp_value))
        if temp_value < 0:
            periodic_features.append(-1)
        else:
            periodic_features.append(1)

        temp_value = np.mean(data_b_left[-w:]) - np.mean(data_a[-w:])
        periodic_features.append(abs(temp_value))
        if temp_value < 0:
            periodic_features.append(-1)
        else:
            periodic_features.append(1)

        temp_value = np.mean(data_b_right[:w]) - np.mean(data_a[-w:])
        periodic_features.append(abs(temp_value))
        if temp_value < 0:
            periodic_features.append(-1)
        else:
            periodic_features.append(1)

    step = int(DEFAULT_WINDOW / 6)
    for w in range(1, DEFAULT_WINDOW, step):
        periodic_features.append(min(max(data_a[w - 1:w + step]) - data_a[-1], 0))
        periodic_features.append(max(min(data_a[w - 1:w + step]) - data_a[-1], 0))
    return periodic_features

# todo: add yourself fitting features here...


def get_fitting_features(x_list):
    fitting_features = []
    fitting_features.extend(time_series_moving_average(x_list[4]))
    fitting_features.extend(time_series_weighted_moving_average(x_list[4]))
    fitting_features.extend(time_series_exponential_weighted_moving_average(x_list[4]))
    fitting_features.extend(time_series_double_exponential_weighted_moving_average(x_list[4]))
    fitting_features.extend(time_series_periodic_features(x_list[0], x_list[1], x_list[2], x_list[3], x_list[4]))
    # append yourself fitting features here...

    return fitting_features
