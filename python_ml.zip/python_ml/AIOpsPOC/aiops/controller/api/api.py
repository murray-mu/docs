# -*- coding: utf-8 -*-

from __future__ import unicode_literals
import json
from functools import wraps
from django.shortcuts import render
from django.http import FileResponse
from aiops.controller.render import render_json
from aiops.service.anomaly_service import *
from aiops.service.detect_service import *
from aiops.common.commons import *


def check_post(func):
    @wraps(func)
    def f(request):
        if request.method == "POST":
            return_dict = func(request)
        else:
            return_dict = build_ret_data(NOT_POST)
        return render_json(return_dict)
    return f

@check_post
def search_anomaly(request):
    anomaly_service = AnomalyService()
    return anomaly_service.query_anomaly(request.body)
    # return "hello world"

@check_post
def train(request):
    detect_service = DetectService()
    return detect_service.process_train(json.loads(request.body))

@check_post
def predict_value(request):
    detect_service = DetectService()
    return detect_service.value_predict(json.loads(request.body))