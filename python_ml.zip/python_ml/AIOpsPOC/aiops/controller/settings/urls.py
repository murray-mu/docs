# -*- coding: utf-8 -*-
from django.conf.urls import url
from django.contrib import admin
from aiops.controller.api import api as api_route

urlpatterns = [
    url(r'^SearchAnomaly$', api_route.search_anomaly, name='search_anomaly'),
    url(r'^Train$', api_route.train, name='train'),
    url(r'^PredictValue$', api_route.predict_value, name='predict_value'),
]
