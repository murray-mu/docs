#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import json
from aiops.model.anomaly_op import *

class AnomalyService(object):

    def __init__(self):
        self.__anomaly = AbnormalOperation()

    @exce_service
    def query_anomaly(self, body):
        return self.__anomaly.get_anomaly(json.loads(body))

    @exce_service
    def update_anomaly(self, body):
        return self.__anomaly.update_anomaly(json.loads(body))
