import pandas as pd
import numpy as np
import xgboost as xgb
import bentoml

train = pd.read_csv("../../data/train.csv")
test  = pd.read_csv("../../data/test.csv")
X_y_train = xgb.DMatrix(data=train[['Pclass', 'Age', 'Fare', 'SibSp', 'Parch']], label= train['Survived'])
X_test    = xgb.DMatrix(data=test[['Pclass', 'Age', 'Fare', 'SibSp', 'Parch']])

train[['Pclass', 'Age', 'Fare', 'SibSp', 'Parch', 'Survived']].head()

params = {
    'base_score': np.mean(train['Survived']),
    'eta':  0.1,
    'max_depth': 3,
    'gamma' :3,
    'objective'   :'reg:linear',
    'eval_metric' :'mae'
}
model = xgb.train(params=params,
                  dtrain=X_y_train,
                  num_boost_round=3)


y_test =  model.predict(X_test)
test['pred'] = y_test
test[['Pclass', 'Age', 'Fare', 'SibSp', 'Parch','pred']].iloc[10:].head(2)


# 1) import the custom BentoService defined above
from aiops.controller.api.api import BentoApi

# 2) `pack` it with required artifacts
bentoApi = BentoApi()
bentoApi.pack('model_aiops', model)

# 3) save your BentoSerivce
saved_path = bentoApi.save()

