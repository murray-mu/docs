import xgboost as xgb
import os
import sys
# 指定应用的根目录
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR + "/../")

import bentoml
from bentoml.frameworks.xgboost import XgboostModelArtifact
from bentoml.adapters import DataframeInput
from aiops.ml.algorithm import ewma, polynomial_interpolation, statistic
from aiops.ml.common.tsd_common import *
from aiops.ml.feature import feature_service
from aiops.model import anomaly_op

@bentoml.env(infer_pip_packages=True)
@bentoml.artifacts([XgboostModelArtifact('model_aiops')])
class BentoMlApiService(bentoml.BentoService):
    def __init__(self):
        self.ewma_obj = ewma.Ewma()
        self.polynomial_obj = polynomial_interpolation.PolynomialInterpolation()
        self.statistic_obj = statistic.Statistic()
        self.anomaly_op_obj = anomaly_op.AbnormalOperation()
        bentoml.BentoService.__init__(self)

    @bentoml.api(input=DataframeInput(), batch=True)
    def predict(self, df):
        dataC = df[['dataC']].values
        dataB = df[['dataB']].values
        dataA = df[['dataA']].values
        window = df[['window']].values
        window = int(window[0][0])
        combined_data = dataC + "," + dataB + "," + dataA
        time_series = list(map(eval, combined_data[0][0].split(',')))
        statistic_result = self.statistic_obj.predict(time_series)
        ewma_result = self.ewma_obj.predict(time_series)
        polynomial_result = self.polynomial_obj.predict(time_series, window)

        if statistic_result == 0 or ewma_result == 0 or polynomial_result == 0:
            if is_standard_time_series(time_series, window):
                ts_features = []
                features = [10]
                features.extend(feature_service.extract_features(time_series, window))
                ts_features.append(features)
                res_pred = xgb.DMatrix(np.array(ts_features))
                # bst = xgb.Booster({'nthread': 4})
                xgb_ret = self.artifacts.model_aiops.predict(res_pred)
                if xgb_ret[0] < 0.6:
                    value = 0
                    self.saveAnomalyData(df)
                else:
                    value = 1
                xgb_result = xgb_ret[0]
            else:
                value = 0
                xgb_result = 0
                self.saveAnomalyData(df)
            res_value = value
            prob = xgb_result
        else:
            res_value = 1
            prob = 1
        ret_data = {"result=" + str(res_value) + ",predict=" + str(prob)}
        return ret_data

    def saveAnomalyData(self, df):
        viewId = df[["viewId"]].values
        viewName = df[["viewName"]].values
        attrId = df[["attrId"]].values
        attrName = df[["attrName"]].values
        time = df[["time"]].values
        dataC = df[['dataC']].values
        dataB = df[['dataB']].values
        dataA = df[['dataA']].values
        time_dataA = dataA[0][0].split(',')
        anomaly_params = {
            "view_id": str(viewId[0][0]),
            "view_name": viewName[0][0],
            "attr_id": str(attrId[0][0]),
            "attr_name": attrName[0][0],
            "time": str(time[0][0]),
            "data_c": dataC[0][0],
            "data_b": dataB[0][0],
            "data_a": dataA[0][0],
            "anomaly_data": str(time_dataA[-1])
        }
        self.anomaly_op_obj.insert_anomaly(anomaly_params)
