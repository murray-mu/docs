import xgboost as xgb
import os
import sys
MODEL_PATH = os.path.join(os.path.dirname(__file__), '../ml/model_file/1626230743673_model')
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR + "/../")

bst = xgb.Booster({'nthread': 4})
bst.load_model(MODEL_PATH)

# 1) import the custom BentoService defined above
from aiops.bentoml.bentoml_api_service import BentoMlApiService

# 2) `pack` it with required artifacts
bentoMlApiService = BentoMlApiService()
bentoMlApiService.pack('model_aiops', bst)

# 3) save your bentoMlApiService
saved_path = bentoMlApiService.save()

