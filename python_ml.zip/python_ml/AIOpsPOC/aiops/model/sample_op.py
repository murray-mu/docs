#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import datetime
import uuid
import csv
import codecs
import pymysql
from aiops.model.db_common import database
from aiops.common.commons import *
from aiops.common.errorcodes import *


class SampleOperation(object):

    def __init__(self):
        self.__conn = pymysql.connect(host=database.HOST, user=database.USER, password=database.PASSWD, db=database.DB, port=database.PORT)
        self.__cur = self.__conn.cursor()
        self.__cur.execute("SET NAMES UTF8")

    def __del__(self):
        self.__conn.close()

    def import_sample(self, data):
        params = []
        insert_str = "INSERT INTO sample_dataset(view_id, view_name, attr_name, attr_id, source, train_or_test, positive_or_negative, window, data_time, data_c, data_b, data_a, anomaly_id) values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"
        for row in data:
            params.append([row['viewId'], row['viewName'], row['attrName'], row['attrId'], row['source'], row['trainOrTest'], row['positiveOrNegative'], row['window'], row['dataTime'], row['dataC'], row['dataB'], row['dataA'], row['anomalyId']])
        num = self.__cur.executemany(insert_str, params)
        self.__conn.commit()
        return OP_SUCCESS, num

    def sample_query_all(self, data):
        params = []
        query_str = ""
        params.append(DEFAULT_WINDOW)
        params.append(data['type'])
        params.append(data['beginTime'])
        params.append(data['endTime'])


        if data['trainOrTest'] != "":
            train_str = ""
            for one_source in data['trainOrTest']:
                params.append(one_source)
                train_str += 'train_or_test = %s or '
            query_str += ' and (' + train_str[:-4] + ') '
        if data['positiveOrNegative'] != "":
            params.append(data['positiveOrNegative'])
            query_str += " and positive_or_negative = %s "
        if data['source'] != "":
            source_str = ""
            for one_source in data['source']:
                params.append(one_source)
                source_str += 'source = %s or '
            query_str += ' and (' + source_str[:-4] + ') '

        #command = 'SELECT data_c, data_b, data_a, positive_or_negative FROM sample_dataset WHERE window = %s and attr_id = %s and data_time > %s and data_time < %s ' + query_str
        command = "SELECT data_c, data_b, data_a, positive_or_negative FROM sample_dataset where data_time_neg!=0 and window = 180  and data_time > 1618945320  union all SELECT data_c, data_b, data_a, positive_or_negative FROM sample_dataset where  positive_or_negative='positive' and  data_time_neg=0 and window = 180  and data_time > 1621445320  and data_time <1622766120"
        # length = self.__cur.execute(command, params)
        length = self.__cur.execute(command)
        sample_list = []
        query_res = self.__cur.fetchmany(length)
        for row in query_res:
            sample_list.append({
                "data": row[0] + ',' + row[1] + ',' + row[2],
                "flag": 1 if row[3] == 'positive' else 0
            })
        return sample_list
