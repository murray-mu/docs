#!/usr/bin/env python
# -*- coding: UTF-8 -*-

DB = 'aiops'
USER = 'root'
PASSWD = 'Hitachi@2020'
HOST = '10.67.32.11'
PORT = 3306
