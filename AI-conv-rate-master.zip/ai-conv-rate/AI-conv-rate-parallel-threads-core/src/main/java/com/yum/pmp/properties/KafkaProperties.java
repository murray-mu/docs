package com.yum.pmp.properties;

import lombok.Data;

/**
 * @author root
 */
@Data
public class KafkaProperties {

    /**
     * kafka brokerlist
     */
    private String brokerList;

    /**
     * kafka consumer groupId
     */
    private String groupId;

    /**
     * Kafka topic
     */
    private String topic;


    /**
     * auto offset reset
     */
    private String autoOffsetReset = "latest";


    /**
     *  kafka消费记录的线程数
     */
    private Integer fetcherThreadNum = Runtime.getRuntime().availableProcessors();


    /**
     *  获取数据池的超时毫秒数，也是 offset 提交延迟时间
     */
    private long pollTimeoutMs = 30000;


    /**
     * 异步线程池处理kaifka数据
     */
    private Boolean asyncProcess = true;


    /**
     * 记录线程句柄数量
     */
    private Integer asyncProcessThreadNum;

    /**
     * 消费最大消费队列大小（）
     */
    private Integer maxPollRecord;

    /**
     * 失败重试次数re
     */
    private Integer maxRetryNums;

    private String deserializerClazz;

    /**
     * 默认为 json序列化 true
     */
    private boolean jsonDeserializer = true;


}
