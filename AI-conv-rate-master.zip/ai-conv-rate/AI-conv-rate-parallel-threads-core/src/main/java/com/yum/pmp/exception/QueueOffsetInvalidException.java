package com.yum.pmp.exception;

import org.apache.kafka.clients.consumer.InvalidOffsetException;
import org.apache.kafka.common.TopicPartition;

import java.util.Collections;
import java.util.Set;

/**
 * @author root
 */
public class QueueOffsetInvalidException extends InvalidOffsetException {

    private TopicPartition tp;

    /**
     * will seek to offset
     */
    private long offset;

    public QueueOffsetInvalidException(String message, TopicPartition tp, long offset) {
        super(message);
        this.tp = tp;
        this.offset = offset;
    }

    public long getOffset() {
        return offset;
    }

    public TopicPartition getTp() {
        return tp;
    }

    @Override
    public Set<TopicPartition> partitions() {
        return Collections.singleton(this.tp);
    }
}
