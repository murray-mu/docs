package com.yum.pmp.reject;


import com.yum.pmp.RecordContext;

/**
 * @author root
 */
public interface RejectHandler {

    /**
     * @param recordContext
     * @param <T>
     * @return
     */
    <T> boolean reject(RecordContext<T> recordContext);
}
