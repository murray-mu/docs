package com.yum.pmp;

import java.util.LinkedList;

/**
 *
 * @author root
 */
public class RecordProcessorChain {
    private LinkedList<AbstractRecordProcessor> abstractRecordProcessorList = new LinkedList<>();

    public RecordProcessorChain addProcessor(AbstractRecordProcessor abstractRecordProcessor){
        if(abstractRecordProcessorList.size() > 0){
            abstractRecordProcessorList.getLast().setNextProcessor(abstractRecordProcessor);
        }
        abstractRecordProcessorList.add(abstractRecordProcessor);
        return this;
    }

    public RecordProcessorChain addProcessorFirst(AbstractRecordProcessor abstractRecordProcessor){
        if(abstractRecordProcessorList.size() > 0){
            abstractRecordProcessor.setNextProcessor(abstractRecordProcessorList.getFirst());
        }
        abstractRecordProcessorList.addFirst(abstractRecordProcessor);
        return this;
    }

    public AbstractRecordProcessor firstProcessor() {
        return abstractRecordProcessorList.size() == 0 ? null : abstractRecordProcessorList.getFirst();
    }
}
