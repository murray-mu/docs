package com.yum.pmp.reject;

import com.yum.pmp.RecordContext;
import lombok.extern.slf4j.Slf4j;

/**
 * @author root
 */
@Slf4j
public class DiscardRejectHandler implements RejectHandler {
    @Override
    public <T> boolean reject(RecordContext<T> recordContext) {
        log.info("Retry max times, will discard this record! {}", recordContext);
        recordContext.ack();
        return true;
    }
}
