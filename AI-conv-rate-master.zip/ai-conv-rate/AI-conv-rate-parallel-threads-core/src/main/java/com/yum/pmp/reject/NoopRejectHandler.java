package com.yum.pmp.reject;

import com.yum.pmp.RecordContext;
import lombok.extern.slf4j.Slf4j;

/**
 * @author root
 */
@Slf4j
public class NoopRejectHandler implements RejectHandler {

    @Override
    public <T> boolean reject(RecordContext<T> recordContext) {
        // noop will always retry
        log.info(" {}-{} {} Do noop reject...",
                recordContext.getConsumerRecord().topic(),
                recordContext.getConsumerRecord().partition(),
                recordContext.getConsumerRecord().offset()
        );
        return false;
    }
}
