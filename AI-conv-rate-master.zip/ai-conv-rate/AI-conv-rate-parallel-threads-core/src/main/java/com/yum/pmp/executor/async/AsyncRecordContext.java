package com.yum.pmp.executor.async;

import com.yum.pmp.AbstractRecordContext;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;

/**
 * @author root
 */
@Getter
@Slf4j
public class AsyncRecordContext<T> extends AbstractRecordContext<T> {
    private ConsumerRecord<String, T> consumerRecord;

    private MarkCompactQueue markCompactQueue;

    private boolean isAcked;

    public AsyncRecordContext(ConsumerRecord<String, T> consumerRecord, MarkCompactQueue markCompactQueue) {
        this.consumerRecord = consumerRecord;
        this.markCompactQueue = markCompactQueue;
    }

    @Override
    public void ack() {
        this.isAcked = true;
        markCompactQueue.tigger();
        log.debug("RecordContext ack: {}", this);
    }

    @Override
    public String toString() {
        return "Record: " + this.consumerRecord.topic()
                + "-" + this.consumerRecord.partition()
                + "-" + consumerRecord.offset()
                + " Acked: " + this.isAcked;
    }
}
