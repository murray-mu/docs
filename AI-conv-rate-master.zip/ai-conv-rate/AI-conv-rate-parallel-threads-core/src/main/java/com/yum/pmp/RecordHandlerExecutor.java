package com.yum.pmp;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
/**
 * @author root
 */
public interface RecordHandlerExecutor<T> {
    void submit(ConsumerRecord<String, T> record);

    void commitOffset(KafkaConsumer<String, T> kafkaConsumer);

    /**
     * @return
     */
    String topic();

}
