package com.yum.pmp;

import org.springframework.stereotype.Component;

/**
 * @author root
 */
@Component
public abstract class AbstractRecordProcessor<T>{


    private AbstractRecordProcessor next;

    public abstract void process(RecordContext<T> recordContext);

    /**
     * @return
     */
    public AbstractRecordProcessor nextProcessor() {
        return next;
    }

    public void setNextProcessor(AbstractRecordProcessor next) {
        this.next = next;
    }
}
