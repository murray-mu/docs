package com.yum.pmp;


import org.apache.kafka.clients.consumer.ConsumerRecord;
import java.util.List;
import java.util.Map;

/**
 *包装类, 封装了Consumer对象供提交Offset时使用
 * @author root
 */
public interface RecordContext<T> {

    void putAllProcessVal(List<Map<String, Object>> vals);

    List<Map<String, Object>> getProcessVal();

    ConsumerRecord<String, T> getConsumerRecord();

    void ack();

    boolean isAcked();

    default T value() {
        return getConsumerRecord().value();
    }

    void setHandlerName(String handlerThreadName);

    /**
     *  数据被ack后，清除线程句柄名字
     */
    void clearHandlerName();
}
