package com.yum.pmp.executor.async;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @author root
 */
public class TopicNameThreadFactory implements ThreadFactory {
    private String topicName;
    private static final AtomicLong INCR = new AtomicLong(0);

    public TopicNameThreadFactory(String topicName) {
        this.topicName = topicName;
    }

    @Override
    public Thread newThread(Runnable r) {
        Thread thread = new Thread(r);
        thread.setName(topicName + "-" + INCR.getAndIncrement());
        return thread;
    }
}
