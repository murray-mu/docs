package com.yum.pmp.executor.sync;

import com.yum.pmp.AbstractRecordContext;
import lombok.Getter;
import org.apache.kafka.clients.consumer.ConsumerRecord;

/**
 * @author root
 * @param <T>
 */
@Getter
public class SyncRecordContext<T> extends AbstractRecordContext<T> {
    private ConsumerRecord<String, T> consumerRecord;

    private boolean isAcked;


    public SyncRecordContext(ConsumerRecord<String, T> consumerRecord) {
        this.consumerRecord = consumerRecord;
    }

    @Override
    public void ack() {
        this.isAcked = true;
    }

}
