package com.yum.pmp;


import com.yum.pmp.properties.KafkaProperties;
import com.yum.pmp.reject.DiscardRejectHandler;
import com.yum.pmp.reject.NoopRejectHandler;
import com.yum.pmp.reject.RejectHandler;

/**
 * @author root
 */
public abstract class AbstractRecordHandlerExecutor<T> implements RecordHandlerExecutor<T> {

    protected KafkaProperties kafkaProperties;
    protected RecordProcessorChain recordProcessorChain;
    private RejectHandler rejectHandler;


    public AbstractRecordHandlerExecutor(
            KafkaProperties kafkaProperties,
            RecordProcessorChain recordProcessorChain,
            RejectHandler rejectHandler
    ) {
        this.kafkaProperties = kafkaProperties;
        this.recordProcessorChain = recordProcessorChain;
        this.rejectHandler = rejectHandler;
    }

    public AbstractRecordHandlerExecutor(
            KafkaProperties kafkaProperties,
            RecordProcessorChain recordProcessorChain
    ) {
        this(kafkaProperties,recordProcessorChain,new DiscardRejectHandler());
    }


    @Override
    public String topic() {
        return kafkaProperties.getTopic();
    }


    protected RecordHandler newRecordHandler(RecordContext ctx) {
        return new RecordHandler(
                recordProcessorChain,
                ctx,
                kafkaProperties.getMaxRetryNums(),
                rejectHandler
        );
    }

}
