package com.yum.pmp.reject;

import com.yum.pmp.RecordContext;
import lombok.extern.slf4j.Slf4j;

/**
 * @author root
 */
@Slf4j
public class DefaultRejectHandler implements RejectHandler {
    @Override
    public <T> boolean reject(RecordContext<T> recordContext) {
        log.error("Record retry error! {}", recordContext);
        throw new RuntimeException("Record retry error! " + recordContext);
    }
}
