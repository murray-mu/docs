package com.yum.pmp.executor.sync;

import com.yum.pmp.AbstractRecordHandlerExecutor;
import com.yum.pmp.RecordProcessorChain;
import com.yum.pmp.properties.KafkaProperties;
import com.yum.pmp.reject.RejectHandler;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;

/**
 * @author root
 */
public class SyncRecordHandlerExecutor<T> extends AbstractRecordHandlerExecutor<T> {
    public SyncRecordHandlerExecutor(KafkaProperties kafkaProperties, RecordProcessorChain recordProcessorChain) {
        super(kafkaProperties, recordProcessorChain);
    }

    public SyncRecordHandlerExecutor(KafkaProperties kafkaProperties, RecordProcessorChain recordProcessorChain, RejectHandler rejectHandler) {
        // used to config reject Handler
        super(kafkaProperties, recordProcessorChain, rejectHandler);
    }

    @Override
    public void submit(ConsumerRecord<String, T> record) {
        newRecordHandler(new SyncRecordContext(record)).run();
    }

    @Override
    public void commitOffset(KafkaConsumer<String, T> kafkaConsumer) {
        kafkaConsumer.commitSync();
    }
}
