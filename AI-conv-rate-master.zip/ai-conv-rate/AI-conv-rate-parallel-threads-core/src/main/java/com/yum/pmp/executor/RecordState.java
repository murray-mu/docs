package com.yum.pmp.executor;

/**
 * @author root
 */

public enum RecordState {
    /**
     * 创建
     */
    NEW,
    /**
     * 运行
     */
    RUNNING,
    /**
     * 确认
     */
    ACKED,
    /**
     * 空
     */
    EMPTY;

    public static boolean running(RecordState state){
        return state.equals(RUNNING);
    }
}
