package com.yum.mc.mapper;

import com.yum.mc.entity.ConvRateEntity;
import com.yum.mc.entity.SampleDatasetEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface MenuComputeMapper {

    List<Map<String,String>> selectChannelList(@Param("tenantId") String tenantId);
    List<Map<String,String>> selectSubStoreTypeList_BK(@Param("storeCode") String storeCode);
    List<Map<String,String>> selectSubStoreTypeList(@Param("storeCode") String storeCode);
    List<Map<String,String>> selectKeyPrice(@Param("storeCode") String storeCode);
    List<Map<String,Object>> selectKeyMealDaypart(@Param("storeCode") String storeCode);
    List<Map<String,String>> selectDayPartList(@Param("tenantId") String tenantId);
    List<Map<String,String>> selectGroupRuleList(@Param("tenantId") String tenantId);

    List<Map<String,Object>> selectTestData(@Param("storeCode") String storeCode);

    void insertConvRateData(ConvRateEntity convRateEntity);
    void insertSampleDataset(SampleDatasetEntity sampleDatasetEntity);
    List<Map<String,Object>> selectAllConvertRate(@Param("type") int type);
    List<Map<String,Object>> selectNegative3sigmaConvertRate(@Param("type") int type);
    List<Map<String,Object>> selectNegativeDupgdConvertRate(@Param("type") int type);
    List<Map<String,Object>> selectNegativeFluxConvertRate(@Param("type") int type);
    List<Map<String,Object>> selectNegativeMissingConvertRate(@Param("type") int type);
    List<Map<String,Object>> selectPredictData (ConvRateEntity convRateEntity);
}
