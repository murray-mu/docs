package com.yum.mc.entity;
import lombok.Data;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
@Data
public class ConvRateEntity {
    private int type;
    private int entry;
    private int pay;
    private  double rate;
    private  Date ts;
}
