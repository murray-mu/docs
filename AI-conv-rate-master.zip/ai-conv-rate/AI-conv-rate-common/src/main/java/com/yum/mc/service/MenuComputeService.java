package com.yum.mc.service;

import com.yum.mc.entity.ConvRateEntity;
import com.yum.mc.entity.SampleDatasetEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yum.mc.mapper.*;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class MenuComputeService {

    @Autowired
    private MenuComputeMapper dictsMapper;
    public  List<Map<String, String>> searchStoreMenu(String storeCode){
        return dictsMapper.selectSubStoreTypeList(storeCode);
    }
    public  List<Map<String, Object>> searchKeyMealDaypart(String storeCode){
        return dictsMapper.selectKeyMealDaypart(storeCode);
    }

    public  List<Map<String, Object>> selectTestData(String storeCode){
        return dictsMapper.selectTestData(storeCode);
    }

    public  void insertConvRateData(ConvRateEntity convRateEntity){
         dictsMapper.insertConvRateData(convRateEntity);
    }
    public  void insertSampleDataset(SampleDatasetEntity sampleDatasetEntity){
        dictsMapper.insertSampleDataset(sampleDatasetEntity);
    }

    public  List<Map<String, Object>> selectAllConvertRate(int type){
        return dictsMapper.selectAllConvertRate(type);
    }

    public  List<Map<String, Object>> selectNegative3sigmaConvertRate(int type){
        return dictsMapper.selectNegative3sigmaConvertRate(type);
    }

    public  List<Map<String, Object>> selectNegativeDupgdConvertRate(int type){
        return dictsMapper.selectNegativeDupgdConvertRate(type);
    }

    public  List<Map<String, Object>> selectNegativeFluxConvertRate(int type){
        return dictsMapper.selectNegativeFluxConvertRate(type);
    }

    public  List<Map<String, Object>> selectNegativeMissingConvertRate(int type){
        return dictsMapper.selectNegativeMissingConvertRate(type);
    }

    public  List<Map<String, Object>> selectPredictData(ConvRateEntity convRateEntity){
        return dictsMapper.selectPredictData(convRateEntity);
    }
}
