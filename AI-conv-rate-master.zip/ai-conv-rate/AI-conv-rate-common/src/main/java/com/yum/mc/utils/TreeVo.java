package com.yum.mc.utils;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class TreeVo {
	@ApiModelProperty(value = "id")
	private String id;
	@ApiModelProperty(value = "parentId")
	private String pId;
	@ApiModelProperty(value = "分类名称")
	private String name;
	@ApiModelProperty(value = "状态 0 禁用 1 启用")
	private String status;
	@ApiModelProperty(value = "菜单分类渠道相关信息")
	private Object channelList;
}
