package com.yum.mc.entity;
import lombok.Data;

import java.util.Date;

@Data
public class PredictConvRateEntity {
    private  String viewId;
    private  String viewName;
    private  String  attrId;
    private  String  attrName;
    private  String  taskId;
    private  int  window;
    private  String  time;
    private  String  dataC;
    private  String  dataB;
    private  String  dataA;
}
