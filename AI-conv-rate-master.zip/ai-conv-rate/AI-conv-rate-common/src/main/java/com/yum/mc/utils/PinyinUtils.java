package com.yum.mc.utils;


import cn.hutool.extra.pinyin.PinyinUtil;

/**
 * 汉语转拼音
 */
public class PinyinUtils {


    public static String convertPinyin(String Chinese) {
        return PinyinUtil.getPinyin(Chinese, "");
    }

}
