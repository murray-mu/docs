package com.yum.mc.entity;
import lombok.Data;

import java.util.Date;

@Data


public class SampleDatasetEntity {
    private  String viewId;
    private  String  viewName;
    private  String  attrName;
    private  String  attrId;
    private  String  source;
    private  String  trainOrTest;
    private  String  positiveOrNegative;
    private  int  window;
    private  long  dataTime;
    private  String  dataC;
    private  String  dataB;
    private  String  dataA;
    private  String  anomalyId;
    private  Date  updateDateTime;
    private  int labelNeg;
    private  long dataTimeNeg;
}
