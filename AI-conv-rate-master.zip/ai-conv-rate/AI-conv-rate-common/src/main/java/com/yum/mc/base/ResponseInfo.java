package com.yum.mc.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

/**
 * Response 正常返回数据
 * @author root
 * @param <T>
 */
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseInfo<T> {

    private int status = 200;

    private String message = "success";

    private T data;

    public ResponseInfo() {

    }

    public ResponseInfo(T date) {
        this.data = date;
    }
    
}
