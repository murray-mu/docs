package com.yum.mc.entity;

import lombok.Data;

/**
 * @package_name: com.yum.pmp.entity
 * @class_name: Tenant
 * @author: fsd
 * @date: 2020/11/2
 */
@Data
public class Tenant extends BaseEntity {
    private String tenantId;

    private String tenantName;

    private String parentId;

    private Boolean isBrand;

    private String brandCode;

    private Boolean status;

    private String tableName;

    private String imgPath;

    private String disableReason;

    private String comments;

    private Integer subCount;

    private Integer tenantSort;
}
