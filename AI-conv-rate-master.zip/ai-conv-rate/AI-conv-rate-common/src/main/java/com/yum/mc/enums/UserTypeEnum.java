package com.yum.mc.enums;

/**
 * 用户类型枚举
 *
 * @author root
 */
public enum UserTypeEnum {

    INTERNAL_USER(1, "内部用户"),
    EXTERNAL_USER(2, "外部用户");

    private Integer code;
    private String name;

    private UserTypeEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

}
