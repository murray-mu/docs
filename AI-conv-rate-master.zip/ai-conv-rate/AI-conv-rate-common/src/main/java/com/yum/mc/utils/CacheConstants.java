package com.yum.mc.utils;

import java.util.HashMap;
import java.util.Map;


/**
 * Created by Duyong on 2017/3/17.
 */
public class CacheConstants {

    // 集群相关缓存
    // URGENT
    public static final String URGENT = "URGENT";
    public static final String INCREMENT_URGENT = "INCREMENT_URGENT";
    public static final String PREVIEW                    = "PREVIEW";
    //public static final String CALCULATE_DATE               = "CALCULATE_DATE";
    public static final String PREVIEW_DATE               = "PREVIEW_DATE";
    public static final String CALCULATE_STORES   = "CALCULATE_STORES";
    public static final String PREVIEW_CALL_BACK_URL      = "PREVIEW_CALL_BACK_URL";
    public static final String PREVIEW_CALL_BACK_URL_NULL = "null";

    // 菜单计算增量改造 预设计算步骤

    public static final Map<String,String> calculateStepMap =new HashMap<String, String>() {
        {
            put("cal1", "GEN_BASIC");// 1-Gen基础菜单(basic)
            put("cal2", "GEN_BYSTORE");// 2-Gen到店菜单(byStore)
            put("cal3", "GEN_SOLDOUT");// 3-Gen售罄准备数据
            put("cal4", "GEN_STORE_SCOPE");// 4-Gen范围餐厅映射
            put("cal5", "TRANF_FILE_BASIC");// 5-Transf生成落地文件(basic)
            put("cal6", "TRANF_FILE_BYSTORE");// 6-Transf生成落地文件(byStore)
            put("cal7", "END_NOTIFY_3RD");// 7-End通知下游增量结果
            put("cal8", "END_SEND_ERROR");// 8-End发送错误报告
            put("cal9", "END_CLEAN_FILE");// 9-End清理历史落地文件(byStore)
            put("cal10", "FINAL_CLEAN_CACHE");// 10-Final清理临时缓存
        }
    };


    // 菜单计算增量改造 计算类型
    public static final String CALCULATE_TYPE   = "CALCULATE_TYPE";



    public static final String CALCULATE_LINKIDS   = "CALCULATE_LINKIDS";
    public static final String CALCULATE_STEP   = "CALCULATE_STEP";

    public static final String DEBUG_KEYSET  = "DEBUG_KEYSET";
    public static final String DEBUG_STORESET = "DEBUG_STORESET";
    public static final String DEBUG_SCOPE = "DEBUG_SCOPE";
    public static final String DEBUG_ATTR = "DEBUG_ATTR";

    public static final String GEN_SWITCH_OFF = "F";
    public static final String GEN_BASIC = "GEN_BASIC";
    public static final String GEN_BYSTORE = "GEN_BYSTORE";
    public static final String GEN_SOLDOUT = "GEN_SOLDOUT";
    // public static final String GEN_JSON_FILE = "GEN_JSON_FILE";
    // 菜单计算增量改造
    // 设置每个步骤的缓存，如果值为F就不做对应的计算
    public static final String GEN_STORE_SCOPE = "GEN_STORE_SCOPE";
    public static final String TRANF_FILE_BASIC = "TRANF_FILE_BASIC";
    public static final String TRANF_FILE_BYSTORE = "TRANF_FILE_BYSTORE";
    public static final String END_NOTIFY_3RD = "END_NOTIFY_3RD";
    public static final String END_SEND_ERROR = "END_SEND_ERROR";
    public static final String END_CLEAN_FILE = "END_CLEAN_FILE";
    public static final String FINAL_CLEAN_CACHE = "FINAL_CLEAN_CACHE";


    // 目前还活着的节点
    // public static final String NODES_LIST = "{NODE}NODES_LIST";
    // 节点列表
    public static final String NODES_LIST   = "{NODE}NODES_LIST";
    public static final String NODE_MASTER  = "{NODE}NODE_MASTER";
    public static final String NODE_SLAVE   = "{NODE}NODE_SLAVE";
    public static final String NODE_BLOCKED = "NODE_BLOCKED";
    
    // 任务相关缓存
    public static final String   GROUP_ID_BEGIN     = "BEGIN";
    public static final String   GROUP_ID_CLEAN     = "CLEAN";
    public static final String   GROUP_ID_INIT      = "INIT";
    public static final String   GROUP_ID_INIT2     = "INIT2";
    public static final String   GROUP_ID_REGULAR   = "REGULAR";
    public static final String   GROUP_ID_REGULAR2  = "REGULAR2";
    public static final String   GROUP_ID_REGULAR3  = "REGULAR3";
    public static final String   GROUP_ID_CALCULATE = "CALCULATE";
    public static final String   GROUP_ID_MAP1      = "MAP1";
    public static final String   GROUP_ID_MAP2      = "MAP2";
    public static final String   GROUP_ID_GEN       = "GEN";
    public static final String   GROUP_ID_GEN2      = "GEN2";
    public static final String   GROUP_ID_TRANF     = "TRANF";
    public static final String   GROUP_ID_END       = "END";
    public static final String   GROUP_ID_FINAL       = "FINAL";
    /** 表示菜单计算任务所有的环节 */
    public static final String[] GROUP_ID_ALL       = {
        GROUP_ID_BEGIN,
        GROUP_ID_CLEAN,
        GROUP_ID_INIT, GROUP_ID_INIT2,
        GROUP_ID_REGULAR, GROUP_ID_REGULAR2,GROUP_ID_REGULAR3,
        GROUP_ID_CALCULATE,
        GROUP_ID_MAP1, GROUP_ID_MAP2,
        GROUP_ID_GEN,GROUP_ID_GEN2,
        GROUP_ID_TRANF,
        GROUP_ID_END,GROUP_ID_FINAL
    };
    
    public static final String   PRE_TASK                       = "{TASK}PRE_TASK";
    public static final String   CUR_TASK_GROUP                 = "{TASK}CUR_TASK_GROUP";   // 表示菜单计算任务当前运行的环节
    public static final String   CUR_TASK_COUNT                 = "{TASK}CUR_TASK_COUNT";
    public static final String   FSH_TASK                       = "{TASK}FSH_TASK";
    public static final String   GROUP_LIST                     = "{TASK}GROUP_LIST";
    public static final String   TASK_SLAVE                     = "{TASK}TASK_SLAVE";
    public static final String   TASK_LIST                      = "{TASK}TASK_LIST";
    public static final String   TASK_GROUP_SWITCHING           = "{TASK}TASK_GROUP_SWITCHING";
    public static final String   TASK_START_TIMESTAMP           = "{TASK}TASK_START_TIMESTAMP";
    public static final String   TASK_RUN_SUCCESS_TIMESTAMP     = "{TASK}TASK_RUN_SUCCESS_TIMESTAMP";
    public static final String   TASK_DURATION                  = "{TASK}TASK_DURATION";
    public static final String   TASK_FINISHED_TASKS            = "{TASK}TASK_FINISHED_TASKS";
    public static final String   TASK_FATAL_ERROR               = "{TASK}TASK_FATAL_ERROR";
    public static final String   TASK_RUN_TIME_MAP              = "{TASK}TASK_RUN_TIME_MAP";
    public static final String   TASK_IS_STARTING               = "{TASK}TASK_IS_STARTING"; // 表示是否正在初始化菜单计算任务的 redis 配置以准备启动任务

    public static final String TASK_LAST_RECORD               = "{TASK}TASK_LAST_RECORD";
    public static final String TASK_HISTORY_HASH              = "{TASK}TASK_HISTORY_HASH";

    public static final String TASK_REQUEST_ID                = "{TASK}TASK_REQUEST_ID";       // 菜单预计算操作的 request_id
    public static final String TASK_INVOKER_USER_ID           = "{TASK}TASK_INVOKER_USER_ID";
    public static final String TASK_INVOKER_USER_NAME         = "{TASK}TASK_INVOKER_USER_NAME";
    public static final String TASK_INVOKER_DEFAULT_USER_ID   = "";
    public static final String TASK_INVOKER_DEFAULT_USER_NAME = "自动任务或通过URL直接触发调用";

    // 日期相关缓存
    public static final String CAL_DAYS      = "CAL_DAYS";
    public static final String DAYS          = "DAYS";
    public static final String EXT_DAY       = "EXT_DAY";
    public static final String DATE_COUNT    = "DATE_COUNT";
    public static final String HOLIDAY       = "HOLIDAY";
    public static final String HOLIDAY_COUNT = "HOLIDAY_COUNT";

    // 行政区划相关缓存
    public static final String CMSXZQHS       = "CMSXZQHS";
    public static final String CMSXZQHS_DATA  = "CMSXZQHS_DATA";
    public static final String CMSXZQHS_COUNT = "CMSXZQHS_COUNT";
    public static final String CMSXZQHS_STORE = "{MAPSTORE}CMSXZQHS_STORE";

    // 插件相关缓存
    public static final String PLUGINSOURCES       = "PLUGINSOURCES";
    public static final String PLUGINSOURCES_MAP   = "PLUGINSOURCES_MAP";
    public static final String PLUGINSOURCES_COUNT = "PLUGINSOURCES_COUNT";

    // 营运市场相关缓存
    public static final String OPSMARKETS       = "OPSMARKETS";
    public static final String OPSMARKETS_DATA  = "OPSMARKETS_DATA";
    public static final String OPSMARKETS_COUNT = "OPSMARKETS_COUNT";
    public static final String OPSMARKETS_STORE = "{MAPSTORE}OPSMARKETS_STORE";
    public static final String C_STORE          = "{MAPSTORE}C_STORE";

    // 范围相关缓存
    public static final String SCOPES               = "SCOPES";
    public static final String SCOPES_DATA          = "SCOPES_DATA";
    public static final String SCOPES_COUNT         = "SCOPES_COUNT";
    public static final String SCOPES_GROUP         = "SCOPES_GROUP";
    public static final String SCOPES_GROUP_UNION   = "SCOPES_GROUP_UNION";
    public static final String SCOPE_STORES         = "SCOPE_STORES";
    public static final String SCOPE_STORES_T       = "SCOPE_STORES_T";
    public static final String SCOPE_BRAND          = "SCOPE_BRAND";
    public static final String SCOPES_GROUP_MAPPING = "SCOPES_GROUP_MAPPING";
    public static final String SCOPE_GROUP_STORES   = "{MAPSTORE}SCOPE_GROUP_STORES";
    public static final String SCOPE_GROUP_STORES_T = "{MAPSTORE}SCOPE_GROUP_STORES_T";

    // 门店相关缓存
    public static final String STORES                     = "STORES";
    public static final String STORES_CODE                = "STORES_CODE";
    public static final String STORES_DATA                = "STORES_DATA";
    public static final String STORES_EXTATTRIBUTE_DATA   = "STORES_EXTATTRIBUTE_DATA";
    public static final String STORES_DWBI_DATA           = "STORES_DWBI_DATA";
    public static final String STORES_WITHEFFECT_DATA     = "STORES_WITHEFFECT_DATA";
    public static final String STORES_MKT_DATA            = "STORES_MKT_DATA";
    public static final String STORES_PROPEXPMAPPING_DATA = "STORES_PROPEXPMAPPING_DATA";
    public static final String STORES_COUNT               = "STORES_COUNT";
    public static final String STORES_PRICE_TYPE          = "STORES_PRICE_TYPE";
    public static final String STORES_PRICE_TYPE_NAME     = "STORES_PRICE_TYPE_NAME";
    public static final String STORE_SCOPES               = "STORE_SCOPES";
    public static final String STORE_MENU_ONSALE          = "STORE_MENU_ONSALE";
    public static final String STORE_KEYS                 = "STORE_KEYS";
    public static final String STORE_KEYS_PREVIEW         = "STORE_KEYS_PREVIEW";
//    public static final String STORES_CMS_TYPE            = "STORES_" + CMS_TYPE;
//    public static final String STORES_FILTER_TYPE         = "STORES_" + FILTER_TYPE;
//    public static final String STORES_OPS_MARKET_TYPE     = "STORES_" + OPS_MARKET_TYPE;

    // 产品相关缓存
    public static final String PRODUCTS              = "PRODUCTS";
    public static final String PRODUCTS_DATA         = "PRODUCTS_DATA";
    public static final String PRODUCTS_COUNT        = "PRODUCTS_COUNT";
    public static final String COMBO_DATA            = "COMBO_DATA";
    public static final String COMBO_COUNT           = "COMBO_COUNT";
    public static final String FAVORABLE_DATA        = "FAVORABLE_DATA";
    public static final String FAVORABLE_COUNT       = "FAVORABLE_COUNT";
    public static final String KEYPRICE_DATA         = "KEYPRICE_DATA";
    public static final String KEYPRICE_COUNT        = "KEYPRICE_COUNT";
    public static final String KEYITEMCODE_DATA      = "KEYITEMCODE_DATA";
    public static final String KEYITEMCODE           = "KEYITEMCODE";
    public static final String PRODUCTSTANDARD_COUNT = "PRODUCTSTANDARD_COUNT";
    public static final String HOTLINK_DATA          = "HOTLINK_DATA";
    public static final String WORDLINK_DATA         = "WORDLINK_DATA";
    public static final String SELLPOINTINTIME_DATA  = "SELLPOINTINTIME_DATA";
    public static final String BASIC_ARCHIVES_DATA   = "BASIC_ARCHIVES_DATA";

    // EC版本
    public static final String VERSION_DATA        = "VERSION_DATA";
    public static final String BANNER_MAP          = "BANNER_MAP";
    public static final String ACTIVE_BANNER       = "ACTIVE_BANNER";
    public static final String STORE_BANNERS       = "STORE_BANNERS";
    public static final String HOTLINK_MAP         = "HOTLINK_MAP";
    public static final String WORDLINK_MAP        = "WORDLINK_MAP";
    public static final String DICSELLSCOPE_MAP    = "DICSELLSCOPE_MAP";
    public static final String DICICLASS_MAP       = "DICICLASS_MAP";
    public static final String DICSELLTIME_MAP     = "DICSELLTIME_MAP";
    public static final String KEYPRICE_MAP        = "KEYPRICE_MAP";
    public static final String SELLPOINTINTIME_MAP = "SELLPOINTINTIME_MAP";
    public static final String SELLSPECIALDATEINFO_MAP  = "SELLSPECIALDATEINFO_MAP";
    public static final String BASICARCHIVES_MAP   = "BASICARCHIVES_MAP";
    public static final String STOREDIC_MAP        = "STOREDIC_MAP";
    public static final String GROUPDIC_MAP        = "GROUPDIC_MAP";
    public static final String DICGROUP_MAP        = "DICGROUP_MAP";
    public static final String DAYPART_MAP         = "DAYPART_MAP";
    public static final String DAYPART_MAP_WITH_STORE     = "DAYPART_MAP_WITH_STORE";
    public static final String KEYDAYPART_MAP      = "KEYDAYPART_MAP";
    public static final String KEYCHANNEL_MAP      = "KEYCHANNEL_MAP";
	// MC-1187
    public static final String BRANDCHANNEL_MAP    = "BRANDCHANNEL_MAP";

    // EC菜单
    public static final String ECOMMERCEMENU_DATA = "ECOMMERCEMENU_DATA";
    public static final String ECOMMERCEMENU      = "ECOMMERCEMENU";
    public static final String ECOMMERCEMENU_ALL  = "ECOMMERCEMENU_ALL";
    public static final String ECOMMERCEMENU_ROOT = "ECOMMERCEMENU_ROOT";
    public static final String ECOMMERCEMENU_SUB  = "ECOMMERCEMENU_SUB";

    // 售罄相关
    public static final String ITEM_ID_KEY       = "ITEM_ID_KEY";
    public static final String COMBOCONTENT_KEY  = "COMBOCONTENT_KEY";
    public static final String FAVORABLEINFO_KEY = "FAVORABLEINFO_KEY";
    public static final String KEY_ITEMCODE      = "KEY_ITEMCODE";
    public static final String KEY_CONFIG        = "KEY_CONFIG";
    public static final String KEY_PRODUCT       = "KEY_PRODUCT";

    // 设键相关缓存
    public static final String KEYMAINS                = "KEYMAINS";
    public static final String PHHS_VARIOUS_KEYIDS     = "PHHS_KEYMAINS";
    public static final String KEYMAINS_CODE           = "KEYMAINS_CODE";
    public static final String KEYMAINS_GUID_TO_NUMBER = "KEYMAINS_GUID_TO_NUMBER";
    public static final String KEYMAINS_NUMBER_TO_GUID = "KEYMAINS_NUMBER_TO_GUID";
    public static final String KEY_STORES              = "{MAPSTORE}KEY_STORES";
    public static final String KEY_ACTIVITY_MAPPING    = "KEY_ACTIVITY_MAPPING";

    // 所有设键相关的对应关系，
    public static final String KEYS         = "KEYS";
    public static final String KEY_DATES    = "KEY_DATES";
    public static final String KEY_POPS     = "KEY_POPS";
    public static final String KEY_SCOPES   = "KEY_SCOPES";
    public static final String KEY_CHANNELS = "KEY_CHANNELS";
    public static final String KEY_CHANNELS_CACHE = "KEY_CHANNELS_CACHE";
    public static final String KEY_CHANNELS_PREVIEW = "KEY_CHANNELS_PREVIEW";
    // 渠道
    public static final String KEY_CHANNELS_ALL      = "0";
    public static final String KEY_CHANNELS_DELIVERY = "1";
    public static final String KEY_CHANNELS_PREORDER = "2";
    public static final String KEY_CHANNELS_KIOSK    = "3";

    public static final String KEYMAINS_DATA   = "KEYMAINS_DATA";
    public static final String KEYMAINS_COUNT  = "KEYMAINS_COUNT";
    public static final String KEYCONFIG_COUNT = "KEYCONFIG_COUNT";

    // 活动相关缓存
    public static final String ACTIVITY_DATA             = "ACTIVITY_DATA";
    // public static final String ACTIVITY_INFO_COUNT = "ACTIVITY_INFO_COUNT";
    public static final String ACTIVITYBRAND_DATA        = "ACTIVITYBRAND_DATA";
    public static final String ACTIVITY_POP_DATA         = "ACTIVITY_POP_DATA";
    public static final String ACTIVITY_POP_COUNT        = "ACTIVITY_POP_COUNT";
    public static final String ACTIVITY_POPS             = "ACTIVITY_POPS";
    public static final String ACTIVITY_KEYMAPPING_DATA  = "ACTIVITY_KEYMAPPING_DATA";
    public static final String ACTIVITY_KEYMAPPING_COUNT = "ACTIVITY_KEYMAPPING_COUNT";
    public static final String ACTIVITY_KEYMAPPINGS      = "ACTIVITY_KEYMAPPINGS";

    // 菜单相关缓存
    public static final String UAT_MSG                         = "UAT_MSG";
    public static final String MENU_UAT                        = "MENU_UAT";
    public static final String MENU_EC                         = "MENU_EC";
    public static final String MENUS                           = "MENUS";
    public static final String AVAIBLE_KEYS                    = "AVAIBLE_KEYS";
    public static final String MENU_BY_STORE                   = "MENU_BY_STORE";
    public static final String MENU_BY_STORE_GZIP              = "MENU_BY_STORE_GZIP";
    public static final String MENU_BY_STORE_GZIP_PREVIEW      = "MENU_BY_STORE_GZIP_PREVIEW";
    public static final String CODE_INFO                       = "CODE_INFO";
    public static final String MENU_BASIC_KEYS                 = "MENU_BASIC_KEYS";
    // 菜单计算增量改造 新增缓存key
    public static final String INCREMENT_MENU_BY_STORE_GZIP              = "INCREMENT_MENU_BY_STORE_GZIP";
    public static final String INCREMENT_CODE_INFO                       = "INCREMENT_CODE_INFO";
    public static final String INCREMENT_MENU_BASIC_KEYS                 = "INCREMENT_MENU_BASIC_KEYS";
    public static final String INCREMENT_MENU_BASIC_PRODUCT_LIST         = "INCREMENT_MENU_BASIC_PRODUCT_LIST";

    public static final String MENU_BASIC_KEYS_PREVIEW         = "MENU_BASIC_KEYS_PREVIEW";
    public static final String MENU_BASIC_PRODUCT_LIST         = "MENU_BASIC_PRODUCT_LIST";
    public static final String MENU_BY_STORE_STATISTCS         = "MENU_BY_STORE_STATISTCS";
    public static final String MENU_BY_STORE_STATISTCS_PREVIEW = "MENU_BY_STORE_STATISTCS_PREVIEW";
    public static final String STORE_MENU_ONSALE_STATISTCS     = "STORE_MENU_ONSALE_STATISTCS";

    // 报告相关缓存
    public static final String REPORT = "REPORT_MESSAGE_LIST";

    // 临时从数据库获取的所有数据存放，整理完毕后删除
    public static final String BASICARCHIVES_DATA                = "DATA:BASICARCHIVES";
    public static final String ECOMMERCEMENUCONFIG_DATA          = "DATA:ECOMMERCEMENUCONFIG";
    public static final String PRODUCTSTANDARD_DATA              = "DATA:PRODUCTSTANDARD";
    public static final String ACTIVITYINFO_DATA                 = "DATA:ACTIVITYINFO";
    public static final String ACTIVITYKEYMAPPING_DATA           = "DATA:ACTIVITYKEYMAPPING";
    public static final String ACTIVITYPOPULARIZEINFO_DATA       = "DATA:ACTIVITYPOPULARIZEINFO";
    public static final String BANNER_DATA                       = "DATA:BANNER";
    public static final String COMBOCONTENTINFO_DATA             = "DATA:COMBOCONTENTINFO";
    public static final String COMBOINFO_DATA                    = "DATA:COMBOINFO";
    public static final String DICICLASS_DATA                    = "DATA:DICICLASS";
    public static final String DICSELLSCOPE_DATA                 = "DATA:DICSELLSCOPE";
    public static final String DICSELLTIME_DATA                  = "DATA:DICSELLTIME";
    public static final String DICSELLSPECIALDATEINFO_DATA       = "DATA:DICSELLSPECIALDATEINFO";
    public static final String DICTIONARY_DATA                   = "DATA:DICTIONARY";
    public static final String STOREDAYPARTMEALWITHTEMPLATE_DATA = "DATA:STOREDAYPARTMEALWITHTEMPLATE_DATA";
    public static final String DICTIONARYGROUP_DATA              = "DATA:DICTIONARYGROUP";
    public static final String DICTIONARYGROUPMAPPING_DATA       = "DATA:DICTIONARYGROUPMAPPING";
    public static final String FAVORABLEINFO_DATA                = "DATA:FAVORABLEINFO";
    public static final String KEYCONFIG_DATA                    = "DATA:KEYCONFIG";
    public static final String KEYITEMCODEINFO_DATA              = "DATA:KEYITEMCODEINFO";
    public static final String KEYMAININFO_DATA                  = "DATA:KEYMAININFO";
    public static final String KEYBRAND_DATA                     = "DATA:KEYBRAND";
    public static final String KEYMAININFO_DATA_PREVIEW          = "DATA:KEYMAININFOPREVIEW";
    public static final String KEYOPERATION_DATA                 = "DATA:KEYOPERATION";
    public static final String KEYOPERATIONDETAIL_DATA           = "DATA:KEYOPERATIONDETAIL";
    public static final String KEYPRICEINFO_DATA                 = "DATA:KEYPRICEINFO";
    public static final String KEYEXTATTRIBUTEVALUE_DATA         = "DATA:KEYEXTATTRIBUTEVALUE";
    public static final String KEYEXTATTRIBUTE_DATA              = "DATA:KEYEXTATTRIBUTE";
    public static final String KEYSTANDARDDRINKMAPPING_DATA      = "DATA:KEYSTANDARDDRINKMAPPING";
    public static final String PRODUCTINFO_DATA                  = "DATA:PRODUCTINFO";
    public static final String PRODUCTDOSING_DATA                = "DATA:PRODUCTDOSING";
    public static final String PRODUCTDOSINGDETAIL_DATA          = "DATA:PRODUCTDOSINGDETAIL";
    public static final String PRODUCTSHILEDDATE_DATA            = "DATA:PRODUCTSHILEDDATE";
    public static final String PRODUCTSHILEDTIME_DATA            = "DATA:PRODUCTSHILEDTIME";
    // public static final String SCOPEDETAIL_DATA = "DATA:SCOPEDETAIL";
    public static final String SCOPEINFO_DATA                  = "DATA:SCOPEINFO";
    public static final String SELLPOINTINTIMEINFO_DATA        = "DATA:SELLPOINTINTIMEINFO";
    public static final String SELLSPECIALDATEINFO_DATA        = "DATA:SELLSPECIALDATEINFO";
    public static final String STORECHOSEPLUGINSOURCE_DATA     = "DATA:STORECHOSEPLUGINSOURCE";
    public static final String STOREDWBI_DATA                  = "DATA:STOREDWBI";
    public static final String STOREMENURELATEDMASTERINFO_DATA = "DATA:STOREMENURELATEDMASTERINFO_DATA";
    public static final String STOREMENURELATEDHISTORYEXT_DATA = "DATA:STOREMENURELATEDHISTORYEXT_DATA";
    public static final String STOREEXTATTRIBUTEVALUE_DATA     = "DATA:STOREEXTATTRIBUTEVALUE";
    public static final String STOREHOLIDAYDETAIL_DATA         = "DATA:STOREHOLIDAYDETAIL";
    public static final String STOREINFOWITHEFFECT_DATA        = "DATA:STOREINFOWITHEFFECT";
    public static final String STOREJDEINFO_DATA               = "DATA:STOREJDEINFO";
    public static final String STOREKEYINFO_DATA               = "DATA:STOREKEYINFO";
    public static final String STOREMENUINFO_DATA              = "DATA:STOREMENUINFO";
    public static final String STOREMKTINFO_DATA               = "DATA:STOREMKTINFO";
    public static final String STOREPROPEXPMAPPING_DATA        = "DATA:STOREPROPEXPMAPPING";
    public static final String STOREROUTINEINFO_DATA           = "DATA:STOREROUTINEINFO";
    public static final String STORESCOPEMAPPING_DATA          = "DATA:STORESCOPEMAPPING";
    public static final String VERSIONINFO_DATA                = "DATA:VERSIONINFO";
    public static final String UATVERSIONINFO_DATA             = "DATA:UATVERSIONINFO";
    public static final String WORDHOTLINK_DATA                = "DATA:WORDHOTLINK";
    public static final String VWSTOREBASEINFO_DATA            = "DATA:VWSTOREBASEINFO";
    public static final String VMCKEY_DATA                     = "DATA:VMCKEY";
    public static final String VMCKEYACTIVITYSCOPE_DATA        = "DATA:VMCKEYACTIVITYSCOPE";
    public static final String STORE_BRAND_PHHS_DATA           = "DATA:STOREBRANDPHHS";

    public static final String CAL_BRAND_CODE                  = "CAL_BRAND_CODE";
    //public static final String CAL_URGENT_DAY                  = "CAL_URGENT_DAY";
    public static final String VMCKEYSTANDARDITEMCODEINFO_DATA = "DATA:VMCKEYSTANDARDITEMCODEINFO";

    // MC-1168
    public static final String STORE_BRAND_INFO                = "STORE_BRAND_INFO";
    public static final String CONFIG_STORE                    = "CONFIG_STORE";
    public static final String BRAND_KEYS                      = "BRAND_KEYS";
    public static final String BRAND_KEYS_TEMP_SET                      = "BRAND_KEYS_TEMP_SET";


    // 奶茶项目
    public static final String PRODUCTDOSINGGROUPMAPPING_DATA                = "DATA:PRODUCTDOSINGGROUPMAPPIN";
    public static final String PRODUCTDOSINGGROUPINFO_DATA                   = "DATA:PRODUCTDOSINGGROUPINFO";
    public static final String PRODUCTDOSINGGROUPDETAIL_DATA                 = "DATA:PRODUCTDOSINGGROUPDETAIL";
    public static final String KEYMODIFYGROUPMAPPING_DATA                    ="DATA:KEYMODIFYGROUPMAPPING";
    public static final String KEYMODIFYGROUPINFO_DATA                       ="DATA:KEYMODIFYGROUPINFO";
    public static final String KEYMODIFYGROUPDETAIL_DATA                     ="DATA:KEYMODIFYGROUPDETAIL";

    // MC-1323
    public static final String GEN_SELLOUT_BRANDS                    = "GEN_SELLOUT_BRANDS";

    // 产品配置&mcjob
    // basic/bystore是否发送kafka信息
    public static final String GEN_KAFKA ="N";

    public  static final String MENUS_KEY="MENUS_KEY";

    public  static final String DICTS_KEY="DICTS_KEY";
}