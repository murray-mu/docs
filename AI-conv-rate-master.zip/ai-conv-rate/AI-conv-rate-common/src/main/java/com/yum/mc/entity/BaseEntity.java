package com.yum.mc.entity;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @package_name: com.yum.pmp.entity
 * @class_name: BaseEntity
 * @author: fsd
 * @date: 2020/10/28
 */
@Data
public class BaseEntity {

    private LocalDateTime createDate;

    private String createPerson;

    private LocalDateTime updateDate;

    private String updatePerson;
}
