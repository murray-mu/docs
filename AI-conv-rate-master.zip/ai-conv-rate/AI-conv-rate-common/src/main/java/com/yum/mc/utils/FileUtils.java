package com.yum.mc.utils;

import com.jcraft.jsch.*;

import java.io.*;

/**
* @Description: 文件工具类
* @Param:
* @return:
* @Author: 洪飞
* @Date: 2020-11-05
*/
public class FileUtils {
 private static    String hostName = "10.67.31.99";
    private static   int port = 22;
    private static   String username = "root";
    private static   String password = "123456";
//    private static Connection conn = null ;
    private static Session session;
    public  static void getBasicFile(String url){


    }
    public static void getConnect() {
//         conn = new Connection(hostName, port);
//        try {
//            // 连接到主机
//            conn.connect();
//            // 使用用户名和密码校验
//            boolean isconn = conn.authenticateWithPassword(username, password);
//            if (!isconn) {
//                System.out.println("用户名称或者是密码不正确");
//            } else {
//                System.out.println("服务器连接成功.");
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        JSch jSch = new JSch();
        try {
            session = jSch.getSession(username, hostName, port);
            session.setPassword(password);
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect(30000);
            System.out.println("服务器连接成功.");
        } catch (JSchException e) {
            e.printStackTrace();
        }
    }
//    public static boolean fileExist(String path) {
//        if (conn != null) {
//            Session ss = null;
//            try {
//                ss = conn.openSession();
//                ss.execCommand("ls -l ".concat(path));
//                InputStream is = new StreamGobbler(ss.getStdout());
//                BufferedReader brs = new BufferedReader(new InputStreamReader(is));
//                String line = "";
//                while (true) {
//                    String lineInfo = brs.readLine();
//                    ;
//                    if (lineInfo != null) {
//                        line = line + lineInfo;
//                    } else {
//                        break;
//                    }
//                }
//                brs.close();
//                if (line != null && line.length() > 0 && line.startsWith("-")) {
//                    return true;
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            } finally {
//                // 连接的Session和Connection对象都需要关闭
//                if (ss != null) {
//                    ss.close();
//                }
//            }
//        }
//        return false;
//    }
    public static String readLogFile(String path) {
        StringBuilder sb = new StringBuilder();
//        if (conn != null) {
//            Session ss = null;
//            try {
//                ss = conn.openSession();
//                ss.execCommand("cat ".concat(path));
//                InputStream is = new StreamGobbler(ss.getStdout());
//                BufferedReader brs = new BufferedReader(new InputStreamReader(is));
//                String line;
//                while ((line = brs.readLine()) != null) {
//                        sb.append(line);
//                }
//                brs.close();
//            } catch (Exception e) {
//                e.printStackTrace();
//            } finally {
//                // 连接的Session和Connection对象都需要关闭
//                if (ss != null) {
//                    ss.close();
//                }
//            }
//        }
        if(session != null){
            try {
                ChannelSftp sftp = (ChannelSftp) session.openChannel("sftp");
                InputStream stream = sftp.get(path);
                BufferedReader br = new BufferedReader(new InputStreamReader(stream));
                 String line;
                while ((line = br.readLine()) != null) {
                        sb.append(line);
                }
                br.close();
                stream.close();
            } catch (Exception e){
                e.getMessage();
            }finally {
//                stream.close();
            }
        }
        return sb.toString();
    }
    public  static  void closeConn() {
        if(session != null){
            session.disconnect();
        }

    }

    public static  void writeFile(String content,String path,String fileName){
        if (session != null) {
            Channel channel = null;
            try {
                channel = (Channel) session.openChannel("sftp");
                channel.connect(10000000);
                ChannelSftp sftp = (ChannelSftp) channel;
                try {
                    sftp.cd(path);
                } catch (SftpException e) {
                }
                OutputStream o = null;
                File file = new File(path + "/" + fileName);
                o = sftp.put(file.getName());
//                File(path+"/"+fileName));
                o.write(content.toString().getBytes("UTF-8"));
                o.close();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                session.disconnect();
                channel.disconnect();
            }

        }


    }

}
