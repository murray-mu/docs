package com.yum.mc.enums;

/**
 * 有效、无效枚举
 * @author root
 */
public enum  InvalidEnum {
    INVALID("无效", 0),
    VALID("有效", 1);

    private String name;
    private Integer code;


    InvalidEnum(String name, Integer code) {
        this.name = name;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public Integer getCode() {
        return code;
    }


    public static InvalidEnum match(Integer code){
        for (InvalidEnum item: InvalidEnum.values()) {
            if (item.getCode().equals(code)) {
                return item;
            }
        }
        return null;
    }

}
