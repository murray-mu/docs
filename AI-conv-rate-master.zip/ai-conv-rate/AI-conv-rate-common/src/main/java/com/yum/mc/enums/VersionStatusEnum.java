package com.yum.mc.enums;

/**
 * 版本状态枚举
 * @author root
 *
 */
public enum VersionStatusEnum {

	CREATED(1,"已创建"),
	PUBLISHED(2,"已发布"),
	REVERT(3,"已撤回");
	
	private Integer code;
	private String name;
	
	public static String getNameByCode(Integer code) {
		for(VersionStatusEnum v :VersionStatusEnum.values()) {
			if(v.getCode().intValue() == code) {
				return v.getName();
			}
		}
		return "";
	}
	
	private VersionStatusEnum(Integer code, String name) {
		this.code = code;
		this.name = name;
	}
	
	public Integer getCode() {
		return code;
	}
	public String getName() {
		return name;
	}
	
}
