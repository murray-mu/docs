package com.yum.mc.enums;

/**
 * 版本类型枚举
 * @author root
 *
 */
public enum VersionTypeEnum {

	NOMAL_VERSION("普通版本","version"),
	INCREASE_VERSION("增量版本","inc_ver");
	
	private String name;
	private String code;

	private VersionTypeEnum(String name,String code) {
		this.name = name;
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public String getCode() {
		return code;
	}

}
