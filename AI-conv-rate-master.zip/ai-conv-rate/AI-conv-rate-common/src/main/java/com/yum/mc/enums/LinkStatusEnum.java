package com.yum.mc.enums;

/**
 * 属性状态
 * @author root
 */
public enum LinkStatusEnum {

    NO_CONFIG("未配置", 0),
    CONFIG("已配置",1),
    CLASSIFICATION("已入分类",2),
    version("已入版本", 3);

    private String name;
    private Integer code;


    LinkStatusEnum(String name, Integer code) {
        this.name = name;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public Integer getCode() {
        return code;
    }

    public static LinkStatusEnum match(Integer code){
        for (LinkStatusEnum item: LinkStatusEnum.values()) {
            if (item.getCode().equals(code)) {
                return item;
            }
        }
        return null;
    }
}
