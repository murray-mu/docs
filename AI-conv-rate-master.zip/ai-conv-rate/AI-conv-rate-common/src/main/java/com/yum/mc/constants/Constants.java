package com.yum.mc.constants;

/**
 *
 * 常量共同方法
 * @author liuguodong
 */
public class Constants {

    public static final Integer ZERO = 0;

    public static final Integer ONE = 1;

    public static final Integer TWO = 2;

    public static final String ALL = "ALL";

    /** 图片类型 */
    public static final String IMAGE_TYPE = "image_type";


    /** 分类渠道图片路径 images 目录 */
    public static final String CLASS_IMAGE_PATH_ATTR = "class_images";

    public static final String EXPORT_KEY_MANAGER_CSV_PREFIX = "key_manager";
    public static final String EXPORT_KEY_MANAGER_INIT_EXPORT_CSV_PREFIX = "key_manager_init_export";
    public static final String EXPORT_MENU_CLASS_CSV_PREFIX = "menu_class";
    public static final String EXPORT_MENU_CLASS_KEY_CSV_PREFIX = "menu_class_key";
    public static final String EXPORT_KEY_GROUP_ASSIST_CSV_PREFIX = "key_group_assist";
    public static final String EXPORT_KEY_GROUP_LINK_CSV_PREFIX = "key_group_link";
    public static final String EXPORT_CSV_SUFFIX = ".csv";

    /** 图片路径 images 目录 */
    public static final String FILE_TEMP_PATH = "file_temp";




}
