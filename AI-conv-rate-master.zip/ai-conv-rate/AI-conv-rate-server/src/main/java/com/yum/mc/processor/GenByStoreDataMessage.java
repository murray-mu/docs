package com.yum.mc.processor;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GenByStoreDataMessage {
    // 当前计算品牌
    private String brandCode;
    // 计算租户ID
    private String tenantId;
    // 计算requestid
    private String requestId;
    // bystore信息
    private String data;
    // 餐厅code
    private String storeCode;
    // 计算日期
    private String calDate;
    // message
    private String message;
    // versionCode
    private  String versionCode;
    // calType
    private String calType;
    // cacheKey
    private String cacheKey;
    // genKafkaType
    private String genKafkaType;
}
