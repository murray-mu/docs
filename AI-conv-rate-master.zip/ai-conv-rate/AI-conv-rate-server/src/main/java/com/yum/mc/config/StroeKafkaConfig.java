package com.yum.mc.config;

import com.yum.pmp.RecordProcessorChain;
import com.yum.mc.processor.StoreConsumerProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
/**
 * @author root
 */
@Configuration
public class StroeKafkaConfig {

    @Bean
    RecordProcessorChain recordProcessorChain(){
        return new RecordProcessorChain()
                .addProcessor(new StoreConsumerProcessor());
    }
}
