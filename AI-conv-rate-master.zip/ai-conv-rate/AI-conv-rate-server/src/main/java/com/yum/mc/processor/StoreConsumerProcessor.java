package com.yum.mc.processor;

import cn.hutool.core.date.DateTime;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.yum.mc.common.SampleType;
import com.yum.mc.entity.ConvRateEntity;
import com.yum.mc.entity.PredictConvRateEntity;
import com.yum.mc.entity.SampleDatasetEntity;
import com.yum.mc.service.MenuComputeService;
import com.yum.pmp.RecordContext;
import com.yum.pmp.AbstractRecordProcessor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author root
 */
@Slf4j
@Component
public class StoreConsumerProcessor extends AbstractRecordProcessor<String> {

    public static StoreConsumerProcessor storeConsumerProcessor;
    @Autowired
    public MenuComputeService menuComputeService;

    @Autowired
    KafkaProducer<String, String> producerMsg;

    @Value("${model.server.url}")
    String modelServerUrl;

    String path = "/data/doris_files/";

    // 获取数据的时间段（三个小时）
    int windowSize = 180;

    // 两分钟出一条数据
    int dayNum = 24 * 60 / 2;

    // 前一天数据的位置
    int yesterDayDatePostion  = 0;

    // 最新数据的时间
    long lastDataTime = 0;
    // 使用postconstruct注解，将需要注入的类添加到静态变量中
    @PostConstruct
    public void init() {
        storeConsumerProcessor = this;
        storeConsumerProcessor.menuComputeService = this.menuComputeService;
        storeConsumerProcessor.producerMsg = this.producerMsg;
        storeConsumerProcessor.modelServerUrl = this.modelServerUrl;
    }

    @Override
    public void process(RecordContext<String> recordContext) {

        String convRateData = recordContext.getConsumerRecord().value();
        if( convRateData.equals("") || convRateData == null || convRateData.equals("null") ) {
            return;
        }
        // log.info("consumer {}", JSON.toJSONString(storeCode));
        try {
            // 从kafka中获取数据，存入mysql
            ConvRateEntity convRateDataMap =  JSON.parseObject(convRateData,ConvRateEntity.class);
            storeConsumerProcessor.menuComputeService.insertConvRateData(convRateDataMap);

            int type = convRateDataMap.getType();
            if (!(type == 2 || type == 7 || type == 9)) {
                recordContext.ack();
                return;
            }

            // 获取需要预测的数据集
            List<Map<String, Object>> predictData = storeConsumerProcessor.menuComputeService.selectPredictData(convRateDataMap);
            List<String> rateList = new ArrayList<String>();

            //获取前一周前后361条数据
            String rateDataC = null;
            String rateDataB = null;
            String rateDataA = null;
            List<String> listRateC = new ArrayList<String>();
            List<String> listRateB = new ArrayList<String>();
            List<String> listRateA = new ArrayList<String>();
            for (int i = 0; i < predictData.size(); i++) {
                String rate = predictData.get(i).get("rate").toString();
                if (i < 361) {
                    listRateC.add(rate);
                }else if (i >= 361 && i < 361*2) {
                    listRateB.add(rate);
                }else {
                    listRateA.add(rate);
                }
            }
            rateDataC = String.join(",", listRateC);
            rateDataB = String.join(",", listRateB);
            rateDataA = String.join(",", listRateA);

            sendPredict(rateDataC, rateDataB, rateDataA, type);

            recordContext.ack();
        } catch (Exception e) {
            // recordContext.ack();
            e.printStackTrace();
            log.error("kafka消费MC.bystore生成数据过程发生异常，{}", e.getMessage());
        }
    }

    /**
     * POST---有参测试(对象参数)
     *
     * @date
     */
    public void sendPredict(String dataC, String dataB, String dataA, int type) {

        // 获得Http客户端(可以理解为:你得先有一个浏览器;注意:实际上HttpClient与浏览器是不一样的)
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();

        // 创建Post请求
        HttpPost httpPost = new HttpPost(storeConsumerProcessor.modelServerUrl);
        PredictConvRateEntity preConvRateEntity = new PredictConvRateEntity();
        preConvRateEntity.setViewId("2021");
        preConvRateEntity.setViewName("转化率");
        preConvRateEntity.setAttrId(String.valueOf(type));
        preConvRateEntity.setAttrName("转化率");
        preConvRateEntity.setTaskId("1621851803322");
        preConvRateEntity.setWindow(180);

        Date date = new Date();
        DateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        String dateStr = sdf.format(date);
        preConvRateEntity.setTime(dateStr);
        preConvRateEntity.setDataC(dataC);
        preConvRateEntity.setDataB(dataB);
        preConvRateEntity.setDataA(dataA);
        String jsonString = "[" + JSON.toJSONString(preConvRateEntity) + "]";
        StringEntity entity = new StringEntity(jsonString, "UTF-8");

        // post请求是将参数放在请求体里面传过去的;这里将entity放入post请求体中
        httpPost.setEntity(entity);

        httpPost.setHeader("Content-Type", "application/json;charset=utf8");

        // 响应模型
        CloseableHttpResponse response = null;
        try {
            // 由客户端执行(发送)Post请求
            response = httpClient.execute(httpPost);
            // 从响应模型中获取响应实体
            HttpEntity responseEntity = response.getEntity();

            System.out.println("响应状态为:" + response.getStatusLine());
            if (responseEntity != null) {
                System.out.println("响应内容长度为:" + responseEntity.getContentLength());
                // System.out.println("响应内容为:" + EntityUtils.toString(responseEntity));
                log.info("predict数据：{}", EntityUtils.toString(responseEntity));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                // 释放资源
                if (httpClient != null) {
                    httpClient.close();
                }
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }



    // @Scheduled(cron = "0 0/30 * * *
    // @Scheduled(cron = "1/10 * 0-23 * * ?")
    @Scheduled(cron = "0 12 16 * * ?")
    void startProductSample_new() throws ParseException {
        for (int type = 1; type < 10; type++) {
            makeSambleDataSet(type, SampleType.NEG_3SIGMA);
            makeSambleDataSet(type, SampleType.NEG_FLUX);
            makeSambleDataSet(type, SampleType.NEG_DUPGD);
            makeSambleDataSet(type, SampleType.NEG_MISSING);
        }

        System.out.println("Finish Product Sample Dataset: " + new Date());
    }

    void makeSambleDataSet (int type, SampleType sampleType) throws ParseException {
        List<Map<String, Object>> allConvertRate = null;
        String PositiveOrNegative = null;
        int labelNeg = 0;
        switch (sampleType) {
            case POSITIVE:
                allConvertRate = storeConsumerProcessor.menuComputeService.selectAllConvertRate(type);
                PositiveOrNegative = "positive";
                labelNeg = 0;
                break;
            case NEG_3SIGMA:
                allConvertRate = storeConsumerProcessor.menuComputeService.selectNegative3sigmaConvertRate(type);
                PositiveOrNegative = "negative";
                labelNeg = 1;
                break;
            case NEG_FLUX:
                allConvertRate = storeConsumerProcessor.menuComputeService.selectNegativeFluxConvertRate(type);
                PositiveOrNegative = "negative";
                labelNeg = 4;
                break;
            case NEG_DUPGD:
                allConvertRate = storeConsumerProcessor.menuComputeService.selectNegativeDupgdConvertRate(type);
                PositiveOrNegative = "negative";
                labelNeg = 2;
                break;
            case NEG_MISSING:
                allConvertRate = storeConsumerProcessor.menuComputeService.selectNegativeMissingConvertRate(type);
                PositiveOrNegative = "negative";
                labelNeg = 3;
                break;
            default:
                break;
        }

        if (allConvertRate.size() > 2 * windowSize + 1 ) {
            int count = 0;
            do {
                String rateDataC = null;
                String rateDataB = null;
                String rateDataA = null;
                List<String> listRateC = new ArrayList<String>();
                List<String> listRateB = new ArrayList<String>();
                List<String> listRateA = new ArrayList<String>();

                //获取前一周前后361条数据

                for (int i = count; i < count + 2 * windowSize + 1; i++) {
                    String rate = allConvertRate.get(i).get("rate").toString();
                    listRateC.add(rate);
                }
                rateDataC = String.join(",", listRateC);

                // 获取前一周中间数据的时间
                String rate = allConvertRate.get(count + windowSize + 1).get("ts").toString();
                Date weekDate = getCustomizeDate(rate, 7);
                Date curDate = getCustomizeDate(rate, 8);
                // 获取前一天同一时刻的前后180条数据
                for (int i = dayNum * 6; i < allConvertRate.size(); i ++) {
                    String strDate = allConvertRate.get(i).get("ts").toString();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date yesterdayDate = sdf.parse(strDate);
                    if (weekDate.compareTo(yesterdayDate) > 0) {
                        continue;
                    }else {
                        yesterDayDatePostion = i;
                        if ((allConvertRate.size() - yesterDayDatePostion) < windowSize) {
                            return;
                        }
                        for (int j = i - windowSize; j < i + windowSize + 1; j++) {
                            String rateB = allConvertRate.get(j).get("rate").toString();
                            listRateB.add(rateB);
                        }
                        break;
                    }
                }
                rateDataB = String.join(",", listRateB);
                // 获取当前时刻和之前180条数据
                for (int i = yesterDayDatePostion; i < allConvertRate.size(); i++) {
                    String strDate = allConvertRate.get(i).get("ts").toString();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date date = sdf.parse(strDate);
                    if (curDate.compareTo(date) > 0) {
                        continue;
                    }else {
                        Timestamp ts = Timestamp.valueOf(allConvertRate.get(i).get("ts").toString());
                        lastDataTime = ts.getTime()/1000;
                        for (int j = i - windowSize; j < i + 1; j++) {
                            String rateA = allConvertRate.get(j).get("rate").toString();
                            listRateA.add(rateA);
                        }
                        break;
                    }
                }
                if (listRateA.size() == 0) {
                    return;
                }

                rateDataA = String.join(",", listRateA);
                count += 30;
                SampleDatasetEntity sampleDatasetEntity = new SampleDatasetEntity();
                sampleDatasetEntity.setDataA(rateDataA);
                sampleDatasetEntity.setDataB(rateDataB);
                sampleDatasetEntity.setDataC(rateDataC);
                sampleDatasetEntity.setDataTime(lastDataTime);
                sampleDatasetEntity.setWindow(windowSize);
                sampleDatasetEntity.setPositiveOrNegative(PositiveOrNegative);
                sampleDatasetEntity.setTrainOrTest("train");
                sampleDatasetEntity.setSource("conv_rate");
                sampleDatasetEntity.setAttrId("" + type);
                sampleDatasetEntity.setAttrName("type_" + type);
                sampleDatasetEntity.setViewId("" + lastDataTime);
                sampleDatasetEntity.setViewName("conv_rate_" + lastDataTime);
                sampleDatasetEntity.setAnomalyId(null);
                sampleDatasetEntity.setLabelNeg(labelNeg);
                sampleDatasetEntity.setDataTimeNeg(lastDataTime);
                Date sysDate = new Date();
                sampleDatasetEntity.setUpdateDateTime(sysDate);
                storeConsumerProcessor.menuComputeService.insertSampleDataset(sampleDatasetEntity);
            }
            while (true);
        }
    }

    Date getCustomizeDate(String strData, int days) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date dt = sdf.parse(strData);
        Calendar rightNow = Calendar.getInstance();
        rightNow.setTime(dt);
        rightNow.add(Calendar.DAY_OF_YEAR,days);// 日期加7天
        Date date = rightNow.getTime();
        return  date;
    }
    // @Scheduled(cron = "0/10 * 0-23 * * ?")
    void startProductSample() {

        List<Map<String, Object>> allConvertRate = storeConsumerProcessor.menuComputeService.selectAllConvertRate(3);
        if (allConvertRate.size() > 0 ) {

            int count = 0;
            do {
                if (count + 1440*7 + 181 > 1440*8) {
                    break;
                }
                String rateDataC = null;
                String rateDataB = null;
                String rateDataA = null;
                List<String> listRateC = new ArrayList<String>();
                List<String> listRateB = new ArrayList<String>();
                List<String> listRateA = new ArrayList<String>();
                for (int i=count; i<count+361; i++) {
                    String rate = allConvertRate.get(i).get("rate").toString();
                    listRateC.add(rate);
                }
                rateDataC = String.join(",", listRateC);

                for (int i=count + 1440*6; i<count + 1440*6 + 361; i++) {
                    String rate = allConvertRate.get(i).get("rate").toString();
                    listRateB.add(rate);
                }
                rateDataB = String.join(",", listRateB);

                for (int i=count + 1440*7; i<count + 1440*7 + 181; i++) {
                    String rate = allConvertRate.get(i).get("rate").toString();
                    listRateA.add(rate);
                }
                Timestamp ts = Timestamp.valueOf(allConvertRate.get(count + 1440*7 + 180).get("ts").toString());
                long dataTime = ts.getTime();
                rateDataA = String.join(",", listRateA);
                count += 30;

                SampleDatasetEntity sampleDatasetEntity = new SampleDatasetEntity();
                sampleDatasetEntity.setDataA(rateDataA);
                sampleDatasetEntity.setDataB(rateDataB);
                sampleDatasetEntity.setDataC(rateDataC);
                sampleDatasetEntity.setDataTime(dataTime);
                sampleDatasetEntity.setWindow(180);
                sampleDatasetEntity.setPositiveOrNegative("positive");
                sampleDatasetEntity.setTrainOrTest("train");
                sampleDatasetEntity.setSource("conv_rate");
                sampleDatasetEntity.setAttrId(""+dataTime);
                sampleDatasetEntity.setAttrName("conv_rate_" + dataTime);
                sampleDatasetEntity.setViewId("" + dataTime);
                sampleDatasetEntity.setViewName("conv_rate_"+dataTime);
                sampleDatasetEntity.setAnomalyId(null);
                Date curDate = new Date();
                sampleDatasetEntity.setUpdateDateTime(curDate);

                storeConsumerProcessor.menuComputeService.insertSampleDataset(sampleDatasetEntity);
            }
            while (true);
            System.out.println("Run timerTask：" + new Date());
        }
        System.out.println("Run timerTask：" + new Date());
    }
    long getTime(String timestamp) {
        Date date = Timestamp.valueOf(timestamp);
        long nTime = date.getTime();
        return nTime;
    }

}



//            {"data":{"storeCode":"ABX001","menuList":[{"keyId":"cd3d71fb-9eb5-4401-9537-e875b6daed9a","price":{"20210305":4000,"20210304":4000,"20210306":4000},"standardPrice":{"20210305":4000,"20210304":4000,"20210306":4000},"sellTimes":[],"typeCode":"0|||2"},{"keyId":"49220e84-30b9-4c9f-a698-ec44be1f9013","price":{"20210305":6350,"20210304":6350,"20210306":6350},"standardPrice":{"20210305":6350,"20210304":6350,"20210306":6350},"sellTimes":[{"date":"20210305","timeRanges":["09:30-10:00","10:00-11:00","11:00-14:00","14:00-17:00","17:00-23:00"]},{"date":"20210304","timeRanges":["09:30-10:00","10:00-11:00","11:00-14:00","14:00-17:00","17:00-23:00"]}],"typeCode":"0|||2"}]},"success":true}
//            {
//                "data": {
//                "storeCode": "ABX001",
//                        "menuList": [{
//                                "keyId": "cd3d71fb-9eb5-4401-9537-e875b6daed9a",
//                                "price": {
//                                  "20210305": 4000,
//                                  "20210304": 4000,
//                                  "20210306": 4000
//                    },
//                    "standardPrice": {
//                                  "20210305": 4000,
//                                  "20210304": 4000,
//                                  "20210306": 4000
//                    },
//                    "sellTimes": [],
//                    "typeCode": "0|||2"
//                },
//                {
//                     "keyId": "49220e84-30b9-4c9f-a698-ec44be1f9013",
//                     "price": {
//                              "20210305": 6350,
//                              "20210304": 6350,
//                              "20210306": 6350
//                              },
//                    "standardPrice": {
//                                  "20210305": 6350,
//                                  "20210304": 6350,
//                                  "20210306": 6350
//                    },
//                    "sellTimes": [{
//                                       "date": "20210305",
//                                       "timeRanges": ["09:30-10:00", "10:00-11:00", "11:00-14:00", "14:00-17:00", "17:00-23:00"]
//                                  },
//                                  {
//                                      "date": "20210304",
//                                      "timeRanges": ["09:30-10:00", "10:00-11:00", "11:00-14:00", "14:00-17:00", "17:00-23:00"]
//                    }],
//                    "typeCode": "0|||2"
//                }]
//            },
//                "success": true
//            }