package com.yum.mc.common;

public enum SampleType {
    POSITIVE,
    NEG_3SIGMA,
    NEG_DUPGD,
    NEG_FLUX,
    NEG_MISSING
}
