package com.yum.mc;


import com.yum.pmp.KafkaConsumerThread;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @author root
 */
// @MapperScan("com.yum.mc.mapper")
@SpringBootApplication
@EnableScheduling // 开启定时任务
public class ConvRateBootApplication {

    public static void main(String[] args) throws IOException {
        SpringApplication.run(ConvRateBootApplication.class, args);
        System.in.read();
    }


    /**
     * 启动生产者
     *
     * @param kafkaProperties kafka config for producer
     * @return
     */
//   @Bean
//    CommandLineRunner producer(KafkaProperties kafkaProperties) {
//        return (args) -> {
//            Properties properties = new Properties();
//            properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.getBrokerList());
//            properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
//            properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
//            KafkaProducer<String, String> producer = new KafkaProducer<>(properties);
//            InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("store.txt");
//            int count = 0;
//            String storeCodes = "";
//            try(Scanner scanner = new Scanner(is)) {
//                while (scanner.hasNextLine()) {
//                    count++;
//                    // System.out.println(scanner.nextLine());
//                    String storeCode = scanner.nextLine();
//                    // for (int i=0; i<3; i++) {
//                    storeCodes += storeCode + ",";
//                    //if (count %2 == 0) {
//                        String temp = storeCodes.substring(0,storeCodes.length()-1);
//                        producer.send(
//                                new ProducerRecord<>("mc-menu-compute_new1",
//                                        UUID.randomUUID().toString(),
//                                        //"tenant-" + 0,
//                                        storeCode));
//                        storeCodes = "";
//                    //}
//
//                   // }
//
//                }
//            } catch (Exception e) {
//                // log.error("读取文件数据异常" ,e);
//            }
//
//        };
//    }

    /**
     * 启动Basic消费者线程
     *
     * @param consumerGroups
     * @return
     */
    @Bean
    CommandLineRunner startStore(List<KafkaConsumerThread> consumerGroups) {
        return (args) -> {
            for (KafkaConsumerThread consumerThread : consumerGroups) {
                consumerThread.start();
            }
        };
    }
}





////            for (int i = 0; i < 100; i++) {
////                producer.send(new ProducerRecord<>(
////                        "mc-menu-compute", UUID.randomUUID().toString(), "userName" + i
////                )
////                );
////            }
