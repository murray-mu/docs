package com.yum.mc.service;



import java.io.IOException;
import java.io.Serializable;
import java.util.List;

/**
 * @Author: dingn
 * @Date: 2020/12/23 17:35
 * @Description: 订单使用的 前端通知mq服务
 * 底层service
 */

public interface IEmqHandle extends IBaseService {

    /**
     * 将用户id（clientId） 订阅到 订单上（topic）
     * topic不存在时，自动创建
     * 支持批量用户挂到某一订单上
     * @param userId
     * @param orderId
     */
    void subTopic(List<String> userId, String orderId);

    /**
     * 将用户id（clientId） 从订单上（topic）解除订阅
     * 支持批量用户从某一订单上解除绑定
     * 无换单场景时，应不需要本服务
     * @param userId
     * @param orderId
     */
    void deSubTopic(List<String> userId, String orderId);

    /**
     * 删除订单topic
     * 用于订单结束时，从mq中删除topic
     * @param orderId
     */
    void deleteTopic(String orderId);

    /**
     * 发布通知，对该订单相关的用户进行广播通知
     * 每个 msgType 对应 一个消息格式 msgObject
     * @param topicList
     * @param msg
     */
    void pubMsg(List<String> topicList, String msg) throws IOException;
}
