package com.yum.mc.controller;

import com.alibaba.fastjson.JSON;
import com.yum.mc.service.MenuComputeService;
import com.yum.mc.service.NotifyMsgTypeEnum;
import com.yum.mc.service.impl.EmqHandle;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Api(tags = "aiops: aiops")
@RestController
@RequestMapping("/api")
public class emqxRequestController {

    @Resource
    private EmqHandle emqHandle;

    @Autowired
    public MenuComputeService menuComputeService;


    @ApiOperation("predict")
    @GetMapping("/pubMsg")
    public void pubMsg() throws IOException {
        log.info("pubMsg");
        List<String> topicList = new ArrayList<>();
        topicList.add("orderid111111");
        topicList.add("orderid111112");
        topicList.add("orderid111113");
        emqHandle.pubMsg(topicList,"orderid111111 send message!!!");
    }
}
