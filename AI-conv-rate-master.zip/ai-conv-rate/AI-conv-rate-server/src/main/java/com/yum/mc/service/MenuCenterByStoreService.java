package com.yum.mc.service;

import com.yum.mc.processor.GenByStoreDataMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;


/**
 * @author jiaxin
 * @date 2020年12月15日 14:45:30
 */
@Slf4j
@Service
public class MenuCenterByStoreService {
    /**
     * 消费MC过来的bystore信息
     *
     * @param message
     */
    public Map<String, Object> generateByStoreInfo(GenByStoreDataMessage message) {

        String branCode = message.getBrandCode();
        String storeCode = message.getStoreCode();
        String tenantId = message.getTenantId();
        String calDate = message.getCalDate();
        String requestId = message.getRequestId();
        String versionCode = message.getVersionCode();
        String calType = message.getCalType();
        String cacheKey = message.getCacheKey();
        String genKafkaType = message.getGenKafkaType();

        log.info("store-service:generateByStoreInfo,brandCode={},storeCode={},tenantId={},calDate={}," +
                        "requestId={},versionCode={},calType={},cacheKey={}", branCode, storeCode, tenantId, calDate,
                requestId, versionCode, calType, cacheKey);

        return null;

    }

}
