package com.yum.mc.service.impl;

import com.alibaba.fastjson.JSON;
import com.yum.mc.service.IEmqHandle;
import com.yum.mc.service.MenuComputeService;
import com.yum.mc.service.NotifyMsgTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.Serializable;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Author: Murray Mu
 * @Date: 2020/12/23 17:47
 * @Description: 订单使用的 前端通知mq服务
 * 底层service
 */
@Slf4j
@Component("oEmqHandle")
public class EmqHandle implements IEmqHandle {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    public static EmqHandle emqHandle;
    //使用注解注入
    @Autowired
    private RestTemplate restTemplate;

    @PostConstruct
    public void init() {
        emqHandle = this;
        emqHandle.restTemplate = this.restTemplate;
    }
    /**
     * 将用户id（clientId） 订阅到 订单上（topic）
     * topic不存在时，自动创建
     * 支持批量用户挂到某一订单上
     * @param userListId
     * @param orderId
     */
    @Override
    public void subTopic(List<String> userListId, String orderId){
        log.info("subTopic userId {}, orderId {}", userListId, orderId);
        //URL作为String
        String url = "http://10.67.31.102:18081/api/v4/mqtt/subscribe_batch";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor("admin", "public"));

        List<Map<String,Object>> topicMapList = new ArrayList<>();

        for (String userId:userListId) {
            Map<String,Object> mapParma = new HashMap<>();
            mapParma.put("topic",orderId);
           // mapParma.put("topics",orderId);
            mapParma.put("clientid",userId);
            mapParma.put("qos",Integer.valueOf(0));
            topicMapList.add(mapParma);
        }

        String content = JSON.toJSONString(topicMapList);
        HttpEntity<String> request = new HttpEntity<>(content, headers);
        ResponseEntity<String> res = restTemplate.postForEntity(url, request, String.class);
        String resStr = JSON.toJSONString(res);
        log.info("emqx 返回消息 {}, ", resStr);
    }

    /**
     * 将用户id（clientId） 从订单上（topic）解除订阅
     * 支持批量用户从某一订单上解除绑定
     * 无换单场景时，应不需要本服务
     * @param userListId
     * @param orderId
     */
    @Override
    public void deSubTopic(List<String> userListId, String orderId){
        log.info("deSubTopic userId {}, orderId {}", userListId, orderId);
        //URL作为String
        String url = "http://10.67.31.102:18081/api/v4/mqtt/unsubscribe_batch";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor("admin", "public"));

        List<Map<String,Object>> topicMapList = new ArrayList<>();

        for (String userId:userListId) {
            Map<String,Object> mapParma = new HashMap<>();
            mapParma.put("topic",orderId);
            mapParma.put("clientid",userId);
            topicMapList.add(mapParma);
        }

        String content = JSON.toJSONString(topicMapList);
        HttpEntity<String> request = new HttpEntity<>(content, headers);
        ResponseEntity<String> res = restTemplate.postForEntity(url, request, String.class);
        String resStr = JSON.toJSONString(res);
        log.info("emqx 返回消息 {}, ", resStr);
    }

    /**
     * 删除订单topic
     * 用于订单结束时，从mq中删除topic
     * @param orderId
     */
    @Override
    public void deleteTopic(String orderId){

    }

    /**
     * 发布通知，对该订单相关的用户进行广播通知
     * 每个 msgType 对应 一个消息格式 msgObject
     * @param orderId
     * @param msgTypeEnum
     * @param msgObject
     */

    public void pubMsg1(String userId, String orderId, NotifyMsgTypeEnum msgTypeEnum, String msgObject){
        log.info("msgTypeEnum {}, orderId {}", msgTypeEnum, orderId);
        //URL作为String
        String url = "http://10.67.31.102:18081/api/v4/mqtt/publish";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor("admin", "public"));
        if (msgTypeEnum == msgTypeEnum.NOTIFY_JOIN) {

        }else {

        }

        Map<String,Object> mapParma = new HashMap<>();
        mapParma.put("topic",orderId);
        mapParma.put("clientid",userId);
        mapParma.put("payload",msgObject);
        mapParma.put("encoding","plain");
        mapParma.put("qos",0);

        String content = JSON.toJSONString(mapParma);
        HttpEntity<String> request = new HttpEntity<>(content, headers);
        ResponseEntity<String> res = restTemplate.postForEntity(url, request, String.class);
        String resStr = JSON.toJSONString(res);
        log.info("emqx 返回消息 {}, ", resStr);
    }


    /**
     * 发布通知，对该订单相关的用户进行广播通知
     * 每个 msgType 对应 一个消息格式 msgObject
     * @param topicList
     * @param msg
     */
    @Override
    public void pubMsg(List<String> topicList, String msg) throws IOException {
        log.info("msgTypeEnum {}, orderId {}", topicList, msg);
        
        //URL作为String
        String url = "http://10.67.31.102:18081/api/v4/mqtt/publish";
        String DEFAULT_USER = "admin";
        String DEFAULT_PASS = "public";

        // 创建用户信息
        CredentialsProvider provider = new BasicCredentialsProvider();
        UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(DEFAULT_USER, DEFAULT_PASS);
        provider.setCredentials(AuthScope.ANY, credentials);

        // 创建客户端的时候进行身份验证
        HttpClient client = HttpClientBuilder.create()
                .setDefaultCredentialsProvider(provider)
                .build();

        HttpPost httpPost = new HttpPost(url);
        httpPost.setHeader("Content-Type", "application/json;charset=utf8");

        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");//设置日期格式
        String clientid = df.format(new Date());
        String topics = String.join(",", topicList);

        Map<String,Object> requestMapParma = new HashMap<>();
        requestMapParma.put("topics", topics);
        requestMapParma.put("clientid", clientid);
        requestMapParma.put("payload", msg);

        String requestParma = JSON.toJSONString(requestMapParma);

        StringEntity entity = new StringEntity(requestParma, "UTF-8");

        // post请求是将参数放在请求体里面传过去的;这里将entity放入post请求体中
        httpPost.setEntity(entity);
        HttpResponse response = client.execute(httpPost);
        int statusCode = response.getStatusLine().getStatusCode();

        String resStr = JSON.toJSONString(response);
        log.info("emqx 返回消息 {}, ", resStr);
    }
}
