package com.yum.mc.service;

/**
 * @Author: dingn
 * @Date: 2020/12/23 17:59
 * @Description: 消息通知类型 枚举
 */

public enum NotifyMsgTypeEnum {
    NOTIFY_JOIN("NOTIFY_JOIN", "加入点餐"),
    NOTIFY_ADDDISH("NOTIFY_ADDDISH", "加减菜");

    NotifyMsgTypeEnum(String msgType, String msgDesc) {
        this.msgType = msgType;
        this.msgDesc = msgDesc;
    }

    private String msgType;
    private String msgDesc;

    public String getMsgType() {
        return msgType;
    }
    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }
    public String getMsgDesc() {
        return msgDesc;
    }
    public void setMsgDesc(String msgDesc) {
        this.msgDesc = msgDesc;
    }
}
