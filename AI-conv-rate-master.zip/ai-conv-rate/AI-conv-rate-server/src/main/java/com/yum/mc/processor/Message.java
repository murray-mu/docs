package com.yum.mc.processor;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author root
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Message {
    String brandCode;
    String cacheKey;
    String calDate;
    String calType;
    String message;
    String requestId;
    String storeCode;
    String tenantId;
    String versionCode;

}
