package com.yum.mc.service;


public interface IBaseService {
}
