package com.yum.pmp.kafka.mcqueue.spring.boot.autoconfigure;

import com.yum.pmp.KafkaConsumerThread;
import com.yum.pmp.RecordHandlerExecutor;
import com.yum.pmp.RecordProcessorChain;
import com.yum.pmp.executor.async.AsyncRecordHandlerExecutor;
import com.yum.pmp.executor.sync.SyncRecordHandlerExecutor;
import com.yum.pmp.properties.KafkaProperties;
import com.yum.pmp.reject.DiscardRejectHandler;
import com.yum.pmp.reject.NoopRejectHandler;
import com.yum.pmp.reject.RejectHandler;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.enterprise.inject.spi.ProducerFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * @author root
 */
@Configuration
@ConditionalOnBean(RecordProcessorChain.class)
public class McQueueKafkaAutoConfigure {

    @Bean
    @ConditionalOnMissingBean
    @ConfigurationProperties("mcqueue.kafka")
    KafkaProperties kafkaProperties() {
        return new KafkaProperties();
    }

    @Bean
    @ConditionalOnMissingBean
    public RejectHandler rejectHandler() {
        return new DiscardRejectHandler();
    }

    @Bean
    @ConditionalOnMissingBean
    public RecordHandlerExecutor executor(KafkaProperties kafkaProperties, RecordProcessorChain recordProcessorChain) {
        if (kafkaProperties.getAsyncProcess()) {
            return new AsyncRecordHandlerExecutor(kafkaProperties, recordProcessorChain);
        } else {
            return new SyncRecordHandlerExecutor(kafkaProperties, recordProcessorChain);
        }
    }

    @Bean
    @ConditionalOnMissingBean
    public List<KafkaConsumerThread> consumerThreadList(KafkaProperties kafkaProperties, RecordHandlerExecutor executor, BuildProperties buildProperties) {
        int threadNum = kafkaProperties.getFetcherThreadNum();
        List<KafkaConsumerThread> fetcherList = new ArrayList<>();
        for (int i = 0; i < threadNum; i++) {
            fetcherList.add(new KafkaConsumerThread<>(executor, kafkaProperties, buildProperties.getName()));
        }
        return fetcherList;
    }

    @Bean
    public KafkaProducer<String, String> producerMsg() {
        KafkaProperties kafkaProperties = kafkaProperties();
        Properties props = new Properties();
        props.setProperty("bootstrap.servers", kafkaProperties.getBrokerList());
        props.setProperty("group.id", kafkaProperties.getGroupId());
        props.setProperty("auto.offset.reset", kafkaProperties.getAutoOffsetReset());
        props.setProperty("enable.auto.commit", Boolean.toString(false));
        props.setProperty("max.poll.records", String.valueOf(kafkaProperties.getMaxPollRecord()));
        props.setProperty("value.deserializer.json.class", kafkaProperties.getDeserializerClazz());
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        KafkaProducer<String, String> producer = new KafkaProducer<>(props);
        return producer;
    }
}
